from libs.PipeLine import ScopedTiming
from libs.Utils import *
import ulab.numpy as np
from media.display import *
from media.media import *
import gc
import _thread
import sys
import time
import os
import image

from libs.Public import *
from utils import import_module, sensor, k230_flag, uart_process

DISPLAY_WIDTH = 544
DISPLAY_HEIGHT = 368

rgb888p_size = [640, 360]
display_size = [544, 368]
cur_state = 0


def face_registration_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    FaceRegistration = import_module('/sdcard/libs/Program/AI/face_registration').FaceRegistration
    # 人脸检测模型路径
    face_det_kmodel_path="/sdcard/examples/kmodel/face_detection_320.kmodel"
    # 人脸注册模型路径
    face_reg_kmodel_path="/sdcard/examples/kmodel/face_recognition.kmodel"
    # 其它参数
    anchors_path="/sdcard/examples/utils/prior_data_320.bin"
    database_dir="/sdcard/data/face_db/"
    database_img_dir="/sdcard/data/face_img/"
    face_det_input_size=[320,320]
    face_reg_input_size=[112,112]
    confidence_threshold=0.5
    nms_threshold=0.2
    anchor_len=4200
    det_dim=4
    anchors = np.fromfile(anchors_path, dtype=np.float)
    anchors = anchors.reshape((anchor_len,det_dim))
    max_register_face = 100              #数据库最多人脸个数
    feature_num = 128                    #人脸识别特征维度
    flag = True

    fr=FaceRegistration(face_det_kmodel_path,face_reg_kmodel_path,det_input_size=face_det_input_size,reg_input_size=face_reg_input_size,database_dir=database_dir,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold)
    try:
        img_show = sensor.snapshot(chn = CAM_CHN_ID_0)
        img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
        # 获取图像列表
        img_list = os.listdir(database_img_dir)
        for img_file in img_list:
            #本地读取一张图像
            full_img_file = database_img_dir + img_file
            print(full_img_file)
            img = image.Image(full_img_file)
            img.compress_for_ide()
            # 转rgb888的chw格式
            rgb888p_img_ndarry = fr.image2rgb888array(img)
            # 人脸注册
            fr.run(rgb888p_img_ndarry,img_file)
            gc.collect()
            Display.show_image(img_show, 0, 0, Display.LAYER_OSD1)
    except Exception as e:
        print(e)
        img_show.clear()
        img_show.draw_string_advanced(130, 155, 16, "人脸注册失败！", color=(255, 255, 0, 0))
        img_show.draw_string_advanced(130, 175, 16, "{}".format(e), color=(255, 255, 0, 0))
        Display.show_image(img_show, 0, 0, Display.LAYER_OSD1)
        flag = False
    finally:
        if flag:
            img_show.clear()
            img_show.draw_string_advanced(135, 150, 32, "人脸注册成功", color=(255, 0, 255, 0))
            Display.show_image(img_show, 0, 0, Display.LAYER_OSD1)
        fr.face_det.deinit()
        fr.face_reg.deinit()



def face_recognition_thread():
    # 注意：执行人脸识别任务之前，需要先执行人脸注册任务进行人脸身份注册生成feature数据库
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    display_size=[DISPLAY_WIDTH,DISPLAY_HEIGHT]
    FaceRecognition = import_module('/sdcard/libs/Program/AI/face_recognition').FaceRecognition
     # 人脸检测模型路径
    face_det_kmodel_path="/sdcard/examples/kmodel/face_detection_320.kmodel"
    # 人脸识别模型路径
    face_reg_kmodel_path="/sdcard/examples/kmodel/face_recognition.kmodel"
    # 其它参数
    anchors_path="/sdcard/examples/utils/prior_data_320.bin"
    database_dir ="/sdcard/data/face_db/"
    face_det_input_size=[320,320]
    face_reg_input_size=[112,112]
    confidence_threshold=0.5
    nms_threshold=0.2
    anchor_len=4200
    det_dim=4
    anchors = np.fromfile(anchors_path, dtype=np.float)
    anchors = anchors.reshape((anchor_len,det_dim))
    face_recognition_threshold = 0.8        # 人脸识别阈值

    fr=FaceRecognition(face_det_kmodel_path,face_reg_kmodel_path,det_input_size=face_det_input_size,reg_input_size=face_reg_input_size,database_dir=database_dir,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,face_recognition_threshold=face_recognition_threshold,rgb888p_size=rgb888p_size,display_size=display_size)
    time_cnt = time.ticks_ms()
    try:
        while True:
            time.sleep_ms(20)
            if cur_state==FACE_RECOGNITION_MODE:
                img_show = sensor.snapshot(chn = CAM_CHN_ID_0)
                img = sensor.snapshot(chn = CAM_CHN_ID_2)
                img_np = img.to_numpy_ref()
                det_boxes,recg_res=fr.run(img_np)          # 推理当前帧
                fr.draw_result(img_show,det_boxes,recg_res)   # 绘制推理结果
                if (len(recg_res)) > 0:
                    s = recg_res[0]
                    result = fr.str_to_dict(s)        
                    print(result)
                    if(result.get("id") == -1):
                        uart_process.AI_Uart_CMD(cmd=FACE_RECOGNITION_MODE, cmd_type=0x01, cmd_data=[0xff]) 
                    else:
                        id = int(result.get("id"))
                        max_score = int(result.get("score") * 100)
                        uart_process.AI_Uart_CMD(cmd=FACE_RECOGNITION_MODE, cmd_type=0x01, cmd_data=[id,max_score]) 
                
                if time.ticks_ms() - time_cnt > 500:
                    time_cnt = time.ticks_ms()
                    uart_process.AI_Uart_CMD(cmd=FACE_RECOGNITION_MODE, cmd_type=0x01, cmd_data=[0xff]) 

                Display.show_image(img_show, 0, 0, Display.LAYER_OSD1)
                gc.collect()
            else:
                break
    except Exception as e:
        print(e)
    finally:
        fr.face_det.deinit()
        fr.face_reg.deinit()
        gc.collect()







def face_det_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    FaceDetectionApp = import_module('/sdcard/libs/Program/AI/face_detection').FaceDetectionApp
    # 设置模型路径和其他参数
    kmodel_path = "/sdcard/examples/kmodel/face_detection_320.kmodel"
    # 其它参数
    confidence_threshold=0.6
    nms_threshold=0.2
    anchor_len=4200
    det_dim=4
    anchors_path="/sdcard/examples/utils/prior_data_320.bin"
    anchors=np.fromfile(anchors_path, dtype=np.float)
    anchors=anchors.reshape((anchor_len, det_dim))
    face_det=FaceDetectionApp(kmodel_path, model_input_size=[320, 320], anchors=anchors, confidence_threshold=confidence_threshold, nms_threshold=nms_threshold, rgb888p_size=rgb888p_size, display_size=display_size, debug_mode=0)
    face_det.config_preprocess()  # 配置预处理
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(20)
        if cur_state==FACE_DETECTION_MODE:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            res = face_det.run(img_np)         # 推理当前帧
            # k230_flag["res"]=res
            # print(len(res))
            if(len(res)>0):
                uart_process.AI_Uart_CMD(cmd=FACE_DETECTION_MODE, cmd_type=0x01, cmd_data=[len(res)]) #人脸数量
            elif time.ticks_ms() - time_cnt > 200:
                time_cnt = time.ticks_ms()
                uart_process.AI_Uart_CMD(cmd=FACE_DETECTION_MODE, cmd_type=0x01, cmd_data=[0xff]) #人脸数量

            face_det.draw_result(img_0, res)   # 绘制结果
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)
            gc.collect()
        else:
            break
    face_det.deinit()
    gc.collect()

def face_landmark_det_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    FaceLandMark = import_module('/sdcard/libs/Program/AI/face_landmark').FaceLandMark
    # 人脸检测模型路径
    face_det_kmodel_path = "/sdcard/examples/kmodel/face_detection_320.kmodel"
    # 人脸关键标志模型路径
    face_landmark_kmodel_path = "/sdcard/examples/kmodel/face_landmark.kmodel"
    # 其它参数
    anchors_path = "/sdcard/examples/utils/prior_data_320.bin"
    
    face_det_input_size = [320,320]
    face_landmark_input_size = [192,192]
    confidence_threshold = 0.5
    nms_threshold = 0.2
    anchor_len = 4200
    det_dim = 4
    anchors = np.fromfile(anchors_path, dtype=np.float)
    anchors = anchors.reshape((anchor_len,det_dim))
    flm = FaceLandMark(face_det_kmodel_path,face_landmark_kmodel_path,det_input_size=face_det_input_size,landmark_input_size=face_landmark_input_size,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,rgb888p_size=rgb888p_size,display_size=display_size)
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(10)
        if cur_state==FACE_LANDMARK:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0) # 获取当前帧
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            det_boxes,landmark_res=flm.run(img_np)         # 推理当前帧
            # print(det_boxes,landmark_res)               # 打印结果
            # if time.ticks_ms() - time_cnt > 200:
            #     uart_process.AI_Uart_CMD(cmd=FACE_LANDMARK, cmd_type=0x01, cmd_data=[0xff]) 
            # flm.facial_expression(det_boxes,landmark_res,0)  # 眨眼计数
            # flm.facial_expression(det_boxes,landmark_res,1)  # 表情推理
            flm.draw_result(img_0,det_boxes,landmark_res)  # 绘制推理结果
            # img_0.draw_string_advanced(5, 205, 16, str(gc.mem_free())+"bytes", color=(255, 128, 255, 0))
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)  # 展示推理效果
            gc.collect()
        else:
            break
    flm.deinit()
    gc.collect()
    

def face_landmark_mouth_blink_counter_det_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    FaceLandMark = import_module('/sdcard/libs/Program/AI/face_landmark').FaceLandMark
    face_det_kmodel_path = "/sdcard/examples/kmodel/face_detection_320.kmodel"
    face_landmark_kmodel_path = "/sdcard/examples/kmodel/face_landmark.kmodel"
    anchors_path = "/sdcard/examples/utils/prior_data_320.bin"
    face_det_input_size = [320,320]
    face_landmark_input_size = [192,192]
    confidence_threshold = 0.6
    nms_threshold = 0.2
    anchor_len = 4200
    det_dim = 4
    anchors = np.fromfile(anchors_path, dtype=np.float)
    anchors = anchors.reshape((anchor_len,det_dim))
    flm = FaceLandMark(face_det_kmodel_path,face_landmark_kmodel_path,det_input_size=face_det_input_size,landmark_input_size=face_landmark_input_size,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,rgb888p_size=rgb888p_size,display_size=display_size)
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(10)
        if cur_state==FACE_LANDMARK_LIVING_BODY:
            if time.ticks_ms() - time_cnt > 8000 or (flm.blink_counter_sum>9 and flm.mouth_open_counter_sum>9):
                time_cnt = time.ticks_ms()
                flm.blink_counter_sum = 0
                flm.mouth_open_counter_sum = 0
                uart_process.AI_Uart_CMD(cmd=FACE_LANDMARK_LIVING_BODY, cmd_type=0x01, cmd_data=[0,0]) 
   
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0) 
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            det_boxes,landmark_res=flm.run(img_np)         
            flm.facial_expression(det_boxes,landmark_res,0)  # 眨眼计数
            uart_process.AI_Uart_CMD(cmd=FACE_LANDMARK_LIVING_BODY, cmd_type=0x01, cmd_data=[flm.blink_counter_sum,flm.mouth_open_counter_sum]) 
            
            flm.draw_result(img_0,det_boxes,landmark_res)  # 绘制推理结果
            img_0.draw_string_advanced(5, 70, 16, "blink:{} mouth_open:{}".format(flm.blink_counter_sum,flm.mouth_open_counter_sum), color=(255, 128, 255, 0))
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)  # 展示推理效果
            gc.collect()
        else:
            break
    flm.deinit()
    gc.collect()



def face_landmark_expression_det_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    FaceLandMark = import_module('/sdcard/libs/Program/AI/face_landmark').FaceLandMark
    face_det_kmodel_path = "/sdcard/examples/kmodel/face_detection_320.kmodel"
    face_landmark_kmodel_path = "/sdcard/examples/kmodel/face_landmark.kmodel"
    anchors_path = "/sdcard/examples/utils/prior_data_320.bin"
    face_det_input_size = [320,320]
    face_landmark_input_size = [192,192]
    confidence_threshold = 0.6
    nms_threshold = 0.2
    anchor_len = 4200
    det_dim = 4
    anchors = np.fromfile(anchors_path, dtype=np.float)
    anchors = anchors.reshape((anchor_len,det_dim))
    flm = FaceLandMark(face_det_kmodel_path,face_landmark_kmodel_path,det_input_size=face_det_input_size,landmark_input_size=face_landmark_input_size,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,rgb888p_size=rgb888p_size,display_size=display_size)
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(20)
        if cur_state==FACE_LANDMARK_EXPRESSION:
            if time.ticks_ms() - time_cnt > 1000:
                time_cnt = time.ticks_ms()
                flm.expression = 0
                uart_process.AI_Uart_CMD(cmd=FACE_LANDMARK_EXPRESSION, cmd_type=0x01, cmd_data=[0xff]) 
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0) # 获取当前帧
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            det_boxes,landmark_res=flm.run(img_np)         # 推理当前帧
            flm.facial_expression(det_boxes,landmark_res,1)  # 表情推理
            uart_process.AI_Uart_CMD(cmd=FACE_LANDMARK_EXPRESSION, cmd_type=0x01, cmd_data=[flm.expression]) 

            flm.draw_result(img_0,det_boxes,landmark_res)  # 绘制推理结果
            img_0.draw_string_advanced(5, 70, 16, "{}".format(FACE_LANDMARK_EXPRESSION_ZH[flm.expression]), color=(255, 128, 255, 0))
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)  # 展示推理效果
            gc.collect()
        else:
            break
    flm.deinit()
    gc.collect() 

def yolov8_det_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    ObjectDetectionApp = import_module('/sdcard/libs/Program/AI/object_detect_yolov8n').ObjectDetectionApp
    kmodel_path = "/sdcard/examples/kmodel/yolov8n_224.kmodel"
    labels = YOLO80_ZH
    confidence_threshold = 0.5
    nms_threshold = 0.4
    ob_det = ObjectDetectionApp(kmodel_path,labels=labels,model_input_size=[224,224],max_boxes_num=50,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,rgb888p_size=rgb888p_size,display_size=display_size,debug_mode=0)
    ob_det.config_preprocess()
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(20)
        if cur_state==OBJECT_RECOGNIZATION_MODE:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            det_res = ob_det.run(img_np)
            ob_det.draw_result(img_0, det_res)
            print(det_res)
            if(len(det_res)==3 and len(det_res[0])>0):
                obj_num = len(det_res)
                id = int(det_res[1][0])
                max_score = int(det_res[2][0] * 100) 
             
                uart_process.AI_Uart_CMD(cmd=OBJECT_RECOGNIZATION_MODE, cmd_type=0x01, cmd_data=[id,max_score,obj_num]) 

            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)
            gc.collect()
        else:
            break
    ob_det.deinit()
    gc.collect()
    
    
def hand_detection_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    HandDetectionApp = import_module('/sdcard/libs/Program/AI/hand_detection').HandDetectionApp
    kmodel_path = "/sdcard/examples/kmodel/hand_det.kmodel"
    # 其它参数设置
    confidence_threshold = 0.3
    nms_threshold = 0.5
    labels = ["手掌"]
    anchors = [26,27, 53,52, 75,71, 80,99, 106,82, 99,134, 140,113, 161,172, 245,276]   #anchor设置

    # 初始化自定义手掌检测实例
    hand_det=HandDetectionApp(kmodel_path,model_input_size=[512,512],labels=labels,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,nms_option=False,strides=[8,16,32],rgb888p_size=rgb888p_size,display_size=display_size,debug_mode=0)
    hand_det.config_preprocess()
    
    while True:
        time.sleep_ms(20)
        if cur_state==HAND_DETECTION:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            res = hand_det.run(img_np)                   # 推理当前帧
            flag = hand_det.draw_result(img_0,res)            # 绘制结果到PipeLine的osd图像
            # print(flag)
            if(flag):
                uart_process.AI_Uart_CMD(cmd=HAND_DETECTION, cmd_type=0x01, cmd_data=[0xee])
            else:
                uart_process.AI_Uart_CMD(cmd=HAND_DETECTION, cmd_type=0x01, cmd_data=[0xff])

            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)
            gc.collect()
        else:
            break
    hand_det.deinit()                              
    gc.collect()


def hand_recognition_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    HandRecognition = import_module('/sdcard/libs/Program/AI/hand_recognition').HandRecognition
    # 手掌检测模型路径
    hand_det_kmodel_path="/sdcard/examples/kmodel/hand_det.kmodel"
    # 手势识别模型路径
    hand_rec_kmodel_path="/sdcard/examples/kmodel/hand_reco.kmodel"
    # 其它参数
    anchors_path="/sdcard/examples/utils/prior_data_320.bin"
    hand_det_input_size=[512,512]
    hand_rec_input_size=[224,224]
    confidence_threshold=0.3
    nms_threshold=0.5
    labels=["gun","other","yeah","five"]
    anchors = [26,27, 53,52, 75,71, 80,99, 106,82, 99,134, 140,113, 161,172, 245,276]

    hr=HandRecognition(hand_det_kmodel_path,hand_rec_kmodel_path,det_input_size=hand_det_input_size,kp_input_size=hand_rec_input_size,labels=labels,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,nms_option=False,strides=[8,16,32],rgb888p_size=rgb888p_size,display_size=display_size)
    while True:
        time.sleep_ms(10)
        if cur_state==HAND_RECOGNIZATION_MODE:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()                              # 获取当前帧
            hand_det_res,hand_rec_res=hr.run(img_np)           # 推理当前帧
            hr.draw_result(img_0,hand_det_res,hand_rec_res)    # 绘制推理结果
            # print(hand_det_res,hand_rec_res)
            # img_0.draw_string_advanced( 5, 205, 16, str(gc.mem_free())+"bytes", color=(255, 128, 255, 0))
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)                              # 展示推理结果
            gc.collect()
        else:
            break

    hr.hand_det.deinit()
    hr.hand_rec.deinit()
    gc.collect()


def hand_keypoint_class_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    HandKeyPointClass = import_module('/sdcard/libs/Program/AI/hand_keypoint_class').HandKeyPointClass
    # 手掌检测模型路径
    hand_det_kmodel_path="/sdcard/examples/kmodel/hand_det.kmodel"
    # 手掌关键点模型路径
    hand_kp_kmodel_path="/sdcard/examples/kmodel/handkp_det.kmodel"
    # 其他参数
    anchors_path="/sdcard/examples/utils/prior_data_320.bin"
    hand_det_input_size=[512,512]
    hand_kp_input_size=[256,256]
    confidence_threshold=0.3
    nms_threshold=0.5
    labels=["手"]
    anchors=[26,27, 53,52, 75,71, 80,99, 106,82, 99,134, 140,113, 161,172, 245,276]

    hkc=HandKeyPointClass(hand_det_kmodel_path,hand_kp_kmodel_path,det_input_size=hand_det_input_size,kp_input_size=hand_kp_input_size,labels=labels,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,nms_option=False,strides=[8,16,32],rgb888p_size=rgb888p_size,display_size=display_size)
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(20)
        if cur_state==HAND_KEYPOINT_CLASS:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()                         # 获取当前帧
            det_boxes,gesture_res=hkc.run(img_np)          # 推理当前帧
            # print(gesture_res)
            if(len(gesture_res)>0):
                print(gesture_res[0])
                print(gesture_res[0][-1])
                id = gesture_res[0][-1]
                if(id != None):
                    uart_process.AI_Uart_CMD(cmd=HAND_KEYPOINT_CLASS, cmd_type=0x01, cmd_data=[id]) #手势id索引
            elif time.ticks_ms() - time_cnt > 200:
                uart_process.AI_Uart_CMD(cmd=HAND_KEYPOINT_CLASS, cmd_type=0x01, cmd_data=[0xff]) #手势id索引

            
            hkc.draw_result(img_0,det_boxes,gesture_res)   
            # img_0.draw_string_advanced( 5, 205, 16, str(gc.mem_free())+"bytes", color=(255, 128, 255, 0))
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)    
            gc.collect()
        else:
            break
    hkc.hand_det.deinit()
    hkc.hand_kp.deinit()
    gc.collect()



def falldown_detect_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    FallDetectionApp = import_module('/sdcard/libs/Program/AI/falldown_detect').FallDetectionApp
    kmodel_path = "/sdcard/examples/kmodel/yolov5n-falldown.kmodel"
    confidence_threshold=0.6
    nms_threshold = 0.45
    labels = ["跌倒","未跌倒"]  # 模型输出类别名称
    anchors = [10, 13, 16, 30, 33, 23, 30, 61, 62, 45, 59, 119, 116, 90, 156, 198, 373, 326]  # anchor设置

    # 初始化自定义跌倒检测实例
    fall_det = FallDetectionApp(kmodel_path, model_input_size=[640, 640], labels=labels, anchors=anchors, confidence_threshold=confidence_threshold, nms_threshold=nms_threshold, nms_option=False, strides=[8,16,32], rgb888p_size=rgb888p_size, display_size=display_size, debug_mode=0)
    fall_det.config_preprocess()
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(20)
        if cur_state==FALL_DETECTION:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()            # 获取当前帧数据
            res = fall_det.run(img_np)                     # 推理当前帧
            if(len(res) > 0):
                id = res[0][0]
                confidence = int(round(res[0][1],3)*100)
                uart_process.AI_Uart_CMD(cmd=FALL_DETECTION, cmd_type=0x01, cmd_data=[id,confidence]) #id索引
            elif time.ticks_ms() - time_cnt > 200:
                time_cnt = time.ticks_ms()
                uart_process.AI_Uart_CMD(cmd=FALL_DETECTION, cmd_type=0x01, cmd_data=[0xff]) 

            fall_det.draw_result(img_0, res)               # 绘制结果到PipeLine的osd图像
            # img_0.draw_string_advanced( 5, 205, 16, str(gc.mem_free())+"bytes", color=(255, 128, 255, 0))
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)                              # 显示当前的绘制结果
            gc.collect()    
        else:
            break

    fall_det.deinit()
    gc.collect()                               

  
def licence_det_rec_det_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    LicenceRec = import_module('/sdcard/libs/Program/AI/licence_det_rec').LicenceRec
    # 车牌检测模型路径
    licence_det_kmodel_path="/sdcard/examples/kmodel/LPD_640.kmodel"
    # 车牌识别模型路径
    licence_rec_kmodel_path="/sdcard/examples/kmodel/licence_reco.kmodel"
    # 其它参数
    licence_det_input_size=[640,640]
    licence_rec_input_size=[220,32]
    confidence_threshold=0.3
    nms_threshold=0.2

    lr=LicenceRec(licence_det_kmodel_path,licence_rec_kmodel_path,det_input_size=licence_det_input_size,rec_input_size=licence_rec_input_size,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,rgb888p_size=rgb888p_size,display_size=display_size)
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(20)
        if cur_state==LICENSE_PLATE_RECOGNITION:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            det_res,rec_res=lr.run(img_np)         # 推理当前帧
            rec_zh = lr.draw_result(img_0,det_res,rec_res)  # 绘制当前帧推理结果
            print(det_res,rec_res)
            print(rec_zh)
            if(rec_zh):
                uart_process.AI_Uart_CMD_String(cmd=LICENSE_PLATE_RECOGNITION, cmd_type=0x01, str_buf=rec_zh) 
            elif time.ticks_ms() - time_cnt > 200:
                time_cnt = time.ticks_ms()
                uart_process.AI_Uart_CMD(cmd=LICENSE_PLATE_RECOGNITION, cmd_type=0x01, cmd_data=[0xff]) 

            # img_0.draw_string_advanced(5, 205, 16, str(gc.mem_free())+"bytes", color=(255, 128, 255, 0))
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)
            gc.collect()
        else:
            break
    lr.licence_det.deinit()
    lr.licence_rec.deinit()
    gc.collect()

def find_qrcodes_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    try:
        time_cnt = time.ticks_ms()
        while True:
            time.sleep_ms(20)
            if cur_state==QRCODE_MODE:
                img = sensor.snapshot(chn = CAM_CHN_ID_0)
                img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            
                img_2 = img.to_rgb565(copy=True)
                for code in img_2.find_qrcodes():
                    rect = code.rect()
                    img.draw_rectangle([v for v in rect], color=(255, 0, 0), thickness = 5)
                    img.draw_string_advanced(rect[0], rect[1], 32, code.payload())
                    uart_process.AI_Uart_CMD_String(cmd=QRCODE_MODE, cmd_type=0x01, str_buf=str(code.payload())) 
                    # print(code)
                    print(code.payload())
                
                if time.ticks_ms() - time_cnt > 500:
                    time_cnt = time.ticks_ms()
                    uart_process.AI_Uart_CMD(cmd=QRCODE_MODE, cmd_type=0x01, cmd_data=[0xff]) 
                
                img = img.to_rgb888(copy=True)
                Display.show_image(img, 0, 0, Display.LAYER_OSD1)    
                gc.collect()
            else:
                break
        del img
        gc.collect()

    except Exception as e:
        print(e)

def find_barcodes_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    barcode_name = import_module('/sdcard/libs/Program/Codes/find_barcodes').barcode_name
    try:
        time_cnt = time.ticks_ms()
        while True:
            time.sleep_ms(20)
            if cur_state==BARCODE_MODE:
                img = sensor.snapshot(chn = CAM_CHN_ID_0)
                img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
                # img = img_2.to_grayscale(copy=False)
                img_2 = img.to_rgb565(copy=True)
                
                for code in img_2.find_barcodes():
                    img.draw_rectangle([v for v in code.rect()], color=(255, 0, 0))
                    # print_args = (barcode_name(code), code.payload(), (180 * code.rotation()) / math.pi, code.quality(), fps.fps())
                    # print("Barcode %s, Payload \"%s\", rotation %f (degrees), quality %d, FPS %f" % print_args)
                    uart_process.AI_Uart_CMD_String(cmd=BARCODE_MODE, cmd_type=0x01, str_buf=str([barcode_name(code), code.payload()]))
                    print([barcode_name(code), code.payload()])
                
                if time.ticks_ms() - time_cnt > 500:
                    time_cnt = time.ticks_ms()
                    uart_process.AI_Uart_CMD(cmd=BARCODE_MODE, cmd_type=0x01, cmd_data=[0xff]) 
                
                img = img.to_rgb888(copy=True)
                Display.show_image(img, 0, 0, Display.LAYER_OSD1)    
                gc.collect()
            else:
                break
        del img
        gc.collect()

    except Exception as e:
        uart_process.AI_Uart_CMD(cmd=BARCODE_MODE, cmd_type=0x01, cmd_data=[0xff]) 
        print(e)


def canny_find_edges_thread():
    '''
    边缘检测
    推荐使用320x240以下分辨率，分辨率过大会导致帧率下降。
    '''
    while True:
        time.sleep_ms(10)
        if cur_state==CANNY_FIND_EDGES:
            img = sensor.snapshot(chn = CAM_CHN_ID_0)
            img = img.to_grayscale(copy=True)
            #使用 Canny 边缘检测器
            img.find_edges(image.EDGE_CANNY, threshold=(50, 80))
            # 也可以使用简单快速边缘检测，效果一般，配置如下
            #img.find_edges(image.EDGE_SIMPLE, threshold=(100, 255))
            # img.draw_string_advanced(5, 205, 16, str(gc.mem_free())+"bytes", color=(255, 128, 255, 0))
            #显示图片，仅用于LCD居中方式显示
            Display.show_image(img, round((544-sensor.width())/2),round((368-sensor.height())/2), Display.LAYER_OSD1)
            gc.collect()
        else:
            break
    del img
    gc.collect()

def person_detection_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    PersonDetectionApp = import_module('/sdcard/libs/Program/AI/person_detection').PersonDetectionApp
    kmodel_path="/sdcard/examples/kmodel/person_detect_yolov5n.kmodel"
    # 其它参数设置
    confidence_threshold=0.5
    nms_threshold=0.6
    labels=["人体"]
    anchors=[10, 13, 16, 30, 33, 23, 30, 61, 62, 45, 59, 119, 116, 90, 156, 198, 373, 326]
    # 初始化自定义人体检测实例
    person_det=PersonDetectionApp(kmodel_path,model_input_size=[640,640],labels=labels,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,nms_option=False,strides=[8,16,32],rgb888p_size=rgb888p_size,display_size=display_size,debug_mode=0)
    person_det.config_preprocess()
    
    while True:
        time.sleep_ms(20)
        if cur_state==PERSON_DETECTION:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            # 推理当前帧
            res = person_det.run(img_np)
            # print(res)
            # 绘制结果到PipeLine的osd图像
            flag = person_det.draw_result(img_0,res)
            if(flag):
                uart_process.AI_Uart_CMD(cmd=PERSON_DETECTION, cmd_type=0x01, cmd_data=[0xee])
            else:
                uart_process.AI_Uart_CMD(cmd=PERSON_DETECTION, cmd_type=0x01, cmd_data=[0xff])
        
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)  
            gc.collect()
        else:
            break
    person_det.deinit()
    gc.collect()


def person_keypoint_detect_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    PersonKeyPointApp = import_module('/sdcard/libs/Program/AI/person_keypoint_detect').PersonKeyPointApp
    kmodel_path="/sdcard/examples/kmodel/yolov8n-pose.kmodel"
    # 其它参数设置
    confidence_threshold=0.5
    nms_threshold=0.5
    # 初始化自定义人体关键点检测实例
    person_kp=PersonKeyPointApp(kmodel_path,model_input_size=[320,320],confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,rgb888p_size=rgb888p_size,display_size=display_size,debug_mode=0)
    person_kp.config_preprocess()
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(20)
        if cur_state==PERSON_KEYPOINT_DETECT:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
            # 推理当前帧
            res=person_kp.run(img_np)
            # is_fallen = person_kp.detect_pos_fall(img_0,res)
            pose_flag = person_kp.detect_pose_all(res)
            print(pose_flag)
            img_0.draw_string_advanced(5, 70, 16, "{}".format(pose_flag), color=(255, 128, 255, 0))

            # if(len(res[0])>0):
            #     uart_process.AI_Uart_CMD(cmd=PERSON_KEYPOINT_DETECT, cmd_type=0x01, cmd_data=[is_fallen]) 
            # elif time.ticks_ms() - time_cnt > 200:
            #     uart_process.AI_Uart_CMD(cmd=PERSON_KEYPOINT_DETECT, cmd_type=0x01, cmd_data=[0xff]) 
            print('='*10)
            person_kp.draw_result(img_0,res)
            # 显示当前的绘制结果
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)  
            gc.collect()
        else:
            break

    person_kp.deinit()
    gc.collect()
    

def person_keypoint_detect_plus_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    PersonKeyPointApp = import_module('/sdcard/libs/Program/AI/person_keypoint_detect').PersonKeyPointApp
    kmodel_path="/sdcard/examples/kmodel/yolov8n-pose.kmodel"
    # 其它参数设置
    confidence_threshold=0.45
    nms_threshold=0.5
    # 初始化自定义人体关键点检测实例
    person_kp=PersonKeyPointApp(kmodel_path,model_input_size=[320,320],confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,rgb888p_size=rgb888p_size,display_size=display_size,debug_mode=0)
    person_kp.config_preprocess()
    time_cnt = time.ticks_ms()
    while True:
        time.sleep_ms(20)
        if cur_state==PERSON_KEYPOINT_DETECT_PLUS:
            img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
            img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            img_np = img_2.to_numpy_ref()
  
            res=person_kp.run(img_np)
            pose_flag = person_kp.detect_pose_all(res)
            print(pose_flag)

            if(pose_flag >= 0):
                img_0.draw_string_advanced(5, 70, 16, "id:{}".format(pose_flag), color=(255, 128, 255, 0))
                uart_process.AI_Uart_CMD(cmd=PERSON_KEYPOINT_DETECT_PLUS, cmd_type=0x01, cmd_data=[pose_flag]) 
            elif time.ticks_ms() - time_cnt > 300:
                img_0.draw_string_advanced(5, 70, 16, "id:None".format(pose_flag), color=(0, 255, 0, 0))
                uart_process.AI_Uart_CMD(cmd=PERSON_KEYPOINT_DETECT_PLUS, cmd_type=0x01, cmd_data=[0xff]) 
            print('='*10)
            person_kp.draw_result(img_0,res)
            Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)  
            gc.collect()
        else:
            break

    person_kp.deinit()
    gc.collect()


def dynamic_gesture_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    DynamicGesture = import_module('/sdcard/libs/Program/AI/dynamic_gesture').DynamicGesture 
    # 手掌检测模型路径
    hand_det_kmodel_path="/sdcard/examples/kmodel/hand_det.kmodel"
    # 手部关键点模型路径
    hand_kp_kmodel_path="/sdcard/examples/kmodel/handkp_det.kmodel"
    # 动态手势识别模型路径
    gesture_kmodel_path="/sdcard/examples/kmodel/gesture.kmodel"
    # 其他参数
    hand_det_input_size=[512,512]
    hand_kp_input_size=[256,256]
    gesture_input_size=[224,224]
    confidence_threshold=0.2
    nms_threshold=0.5
    labels=["hand"]
    anchors = [26,27, 53,52, 75,71, 80,99, 106,82, 99,134, 140,113, 161,172, 245,276]
    Gesture_id = {0:None,1:None,2:0,3:1,4:3,5:2}

    # 自定义动态手势识别任务实例
    dg=DynamicGesture(hand_det_kmodel_path,hand_kp_kmodel_path,gesture_kmodel_path,det_input_size=hand_det_input_size,kp_input_size=hand_kp_input_size,gesture_input_size=gesture_input_size,labels=labels,anchors=anchors,confidence_threshold=confidence_threshold,nms_threshold=nms_threshold,nms_option=False,strides=[8,16,32],rgb888p_size=rgb888p_size,display_size=display_size)
    try:
        while True:
            time.sleep_ms(20)
            if cur_state==DYNAMIC_GESTURE:
                img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
                img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
                img_np = img_2.to_numpy_ref()
                output1,output2=dg.run(img_np)  
                # print(dg.cur_state)
                id = Gesture_id.get(dg.cur_state)
                if(id==None):
                    uart_process.AI_Uart_CMD(cmd=DYNAMIC_GESTURE, cmd_type=0x01, cmd_data=[0xff])
                else:
                    uart_process.AI_Uart_CMD(cmd=DYNAMIC_GESTURE, cmd_type=0x01, cmd_data=[id])
                # print(output1,output2) 
                print('='*10)
                dg.draw_result(img_0,output1,output2) 
                Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)  
                gc.collect()
            else:
                break
        dg.hand_det.deinit()
        dg.hand_kp.deinit()
        dg.dg.deinit()
        gc.collect()
    except Exception as e:
        print(e)


def self_learning_thread():
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    SelfLearningApp = import_module('/sdcard/libs/Program/AI/self_learning').SelfLearningApp
    kmodel_path="/sdcard/examples/kmodel/recognition.kmodel"
    labels=["id0","id1","id2"]

    top_k=3
    threshold=0.5
    rgb888p_size=[1280,720]
    model_input_size=[224,224]
    # 初始化自学习实例
    sl=SelfLearningApp(kmodel_path=kmodel_path,model_input_size=model_input_size,labels=labels,top_k=top_k,threshold=threshold,rgb888p_size=rgb888p_size,display_size=display_size,debug_mode=0)
    sl.config_preprocess()
    try:
        while True:
            time.sleep_ms(20)
            if cur_state==SELF_LEARNING_CLASSIFIER_MODE:
                img_0 = sensor.snapshot(chn = CAM_CHN_ID_0)
                img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
                img_np = img_2.to_numpy_ref()
                res=sl.run(img_np) # 推理当前帧
                sl.draw_result(img_0,res) 
                # print(res)  # 打印结果
                Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)  
                gc.collect()
            else:
                break
    except Exception as e:
        print(e)


def color_count_thread(cur_mode=0):
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process

    ColorObjectCount = import_module('/sdcard/libs/Program/Image/ColorObjectCounting').ColorObjectCount
    color_count = ColorObjectCount(color=cur_mode)
    time_cnt = time.ticks_ms()
    try:
        while True:
            time.sleep_ms(20)
            if cur_state==COLOR_OBJECT_COUNT_MODE:
                img = sensor.snapshot(chn = CAM_CHN_ID_0)
                img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            
                img_2 = img.to_rgb565(copy=True)
                res=color_count.recognize(img_2,img)
                
                if isinstance(res, int):
                    uart_process.AI_Uart_CMD(cmd=COLOR_OBJECT_COUNT_MODE, cmd_type=0x01, cmd_data=[res]) 
                elif time.ticks_ms() - time_cnt > 500:
                    time_cnt = time.ticks_ms()
                    uart_process.AI_Uart_CMD(cmd=COLOR_OBJECT_COUNT_MODE, cmd_type=0x01, cmd_data=[0xff]) 
                img = img.to_rgb888(copy=True)
                Display.show_image(img, 0, 0, Display.LAYER_OSD1)    
                gc.collect()
            else:
                break
    except Exception as e:
        print(e)




def lab_color_count_thread(color):
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process

    ColorObjectCount = import_module('/sdcard/libs/Program/Image/ColorObjectCounting').LABColorObjectCount
    color_count = ColorObjectCount(color=color)
    time_cnt = time.ticks_ms()
    try:
        while True:
            time.sleep_ms(20)
            if cur_state==COLOR_OBJECT_COUNT_MODE:
                img = sensor.snapshot(chn = CAM_CHN_ID_0)
                img_2 = sensor.snapshot(chn = CAM_CHN_ID_2)
            
                img_2 = img.to_rgb565(copy=True)
                res=color_count.recognize(img_2,img)
                
                if isinstance(res, int):
                    uart_process.AI_Uart_CMD(cmd=COLOR_OBJECT_COUNT_MODE, cmd_type=0x01, cmd_data=[res]) 
                elif time.ticks_ms() - time_cnt > 500:
                    time_cnt = time.ticks_ms()
                    uart_process.AI_Uart_CMD(cmd=COLOR_OBJECT_COUNT_MODE, cmd_type=0x01, cmd_data=[0xff]) 
                img = img.to_rgb888(copy=True)
                Display.show_image(img, 0, 0, Display.LAYER_OSD1)    
                gc.collect()
            else:
                break
    except Exception as e:
        print(e)


def classify_kmodel_thread(komodel_path, num):
    from libs.YOLO import YOLO11
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    kmodel_path = komodel_path
    labels = [i for i in range(0, num)] # ["apple","banana","orange"]
    labels = [str(x) for x in labels]  # 遍历并转换每个元素
    confidence_threshold = 0.6
    model_input_size = [320,320]
    # 初始化YOLO11实例
    yolo=YOLO11(task_type="classify",mode="video",kmodel_path=kmodel_path,labels=labels,rgb888p_size=rgb888p_size,model_input_size=model_input_size,display_size=display_size,conf_thresh=confidence_threshold,debug_mode=0)
    yolo.config_preprocess()
    try:
        time_cnt = time.ticks_ms()
        while True:
            time.sleep_ms(50)
            if cur_state==CLASSIFY_MODEL_MODE:
                img_show = sensor.snapshot(chn = CAM_CHN_ID_0)
                img = sensor.snapshot(chn = CAM_CHN_ID_2)
               
                img_np = img.to_numpy_ref()
                # 逐帧推理
                res=yolo.run(img_np)
                yolo.draw_result(res,img_show)

                print(res)
                if type(res) is tuple:
                    if (type(res[0]) is int) and (type(res[1]) is float):
                        print("整数")
                        if(res[0]<0):
                            uart_process.AI_Uart_CMD(cmd=CLASSIFY_MODEL_MODE, cmd_type=0x01, cmd_data=[0xff]) 
                        else:
                            id = int(res[0])
                            score = int(res[1] * 100)
                            uart_process.AI_Uart_CMD(cmd=CLASSIFY_MODEL_MODE, cmd_type=0x01, cmd_data=[id,score]) 
           
                   
                
                if time.ticks_ms() - time_cnt > 500:
                    time_cnt = time.ticks_ms()
                    uart_process.AI_Uart_CMD(cmd=CLASSIFY_MODEL_MODE, cmd_type=0x01, cmd_data=[0xff]) 
               

                Display.show_image(img_show, 0, 0, Display.LAYER_OSD1)    
                gc.collect()
            else:
                break
    except Exception as e:
        print(e)
    finally:
        yolo.deinit()



def detect_kmodel_thread(komodel_path, num):
    from libs.YOLO import YOLO11
    global rgb888p_size,display_size,cur_state,k230_flag,uart_process
    kmodel_path = komodel_path
    labels = [i for i in range(0, num)] # ["apple","banana","orange"]
    labels = [str(x) for x in labels]  # 遍历并转换每个元素
    confidence_threshold = 0.6
    model_input_size = [320,320]
    # 初始化YOLO11实例
    yolo=YOLO11(task_type="detect",mode="video",kmodel_path=kmodel_path,labels=labels,rgb888p_size=rgb888p_size,model_input_size=model_input_size,display_size=display_size,conf_thresh=confidence_threshold,debug_mode=0)
    yolo.config_preprocess()
    try:
        time_cnt = time.ticks_ms()
        while True:
            time.sleep_ms(30)
            if cur_state==DETECT_MODEL_MODE:
                img_show = sensor.snapshot(chn = CAM_CHN_ID_0)
                img = sensor.snapshot(chn = CAM_CHN_ID_2)
               
                img_np = img.to_numpy_ref()
                # 逐帧推理
                res=yolo.run(img_np)
                yolo.draw_result(res,img_show)

                print(res)
                if len(res) > 0: 
                    if(len(res[0])==6):
                        # print('111')
                        id = int(res[0][5])
                        score = int(res[0][4] * 100)
                        uart_process.AI_Uart_CMD(cmd=DETECT_MODEL_MODE, cmd_type=0x01, cmd_data=[id,score])                          
                    else:
                        uart_process.AI_Uart_CMD(cmd=DETECT_MODEL_MODE, cmd_type=0x01, cmd_data=[0xff]) 

                if time.ticks_ms() - time_cnt > 500:
                    time_cnt = time.ticks_ms()
                    uart_process.AI_Uart_CMD(cmd=DETECT_MODEL_MODE, cmd_type=0x01, cmd_data=[0xff]) 
               

                Display.show_image(img_show, 0, 0, Display.LAYER_OSD1)    
                gc.collect()
            else:
                break
    except Exception as e:
        print(e)
    finally:
        yolo.deinit()

def display_camera_thread():
    while True:
        time.sleep(0.05)
        if cur_state != -1: break
        img_0=sensor.snapshot(chn=CAM_CHN_ID_0)
        Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)



def run(num=0, args={}):
    global cur_state
    run_sleep_ms = 300
    if cur_state == num:
        return
    
    print(cur_state,num,args)
    print("===run_mode===")

    if(cur_state==PERSON_KEYPOINT_DETECT or cur_state==FACE_RECOGNITION_MODE):
        run_sleep_ms = 800
    
    cur_state = num
    time.sleep_ms(run_sleep_ms)
    gc.collect()
    
    if cur_state == -1: _thread.start_new_thread(display_camera_thread,())
    if cur_state == FACE_DETECTION_MODE: _thread.start_new_thread(face_det_thread,())
    elif cur_state == FACE_REG_MODE: _thread.start_new_thread(face_registration_thread,())
    elif cur_state == FACE_RECOGNITION_MODE: _thread.start_new_thread(face_recognition_thread,())
    elif cur_state == OBJECT_RECOGNIZATION_MODE: _thread.start_new_thread(yolov8_det_thread,())
    elif cur_state == HAND_DETECTION: _thread.start_new_thread(hand_detection_thread,())
    elif cur_state == HAND_RECOGNIZATION_MODE: _thread.start_new_thread(hand_recognition_thread,())
    elif cur_state == QRCODE_MODE: _thread.start_new_thread(find_qrcodes_thread,())
    elif cur_state == BARCODE_MODE: _thread.start_new_thread(find_barcodes_thread,())
    elif cur_state == CANNY_FIND_EDGES: _thread.start_new_thread(canny_find_edges_thread,())
    elif cur_state == FALL_DETECTION: _thread.start_new_thread(falldown_detect_thread,())
    elif cur_state == LICENSE_PLATE_RECOGNITION: _thread.start_new_thread(licence_det_rec_det_thread,())
    elif cur_state == PERSON_DETECTION: _thread.start_new_thread(person_detection_thread,())
    elif cur_state == HAND_KEYPOINT_CLASS: _thread.start_new_thread(hand_keypoint_class_thread,())
    elif cur_state == PERSON_KEYPOINT_DETECT: _thread.start_new_thread(person_keypoint_detect_thread,())
    elif cur_state == PERSON_KEYPOINT_DETECT_PLUS: _thread.start_new_thread(person_keypoint_detect_plus_thread,())
    elif cur_state == DYNAMIC_GESTURE: _thread.start_new_thread(dynamic_gesture_thread,())
    elif cur_state == FACE_LANDMARK: _thread.start_new_thread(face_landmark_det_thread,())
    elif cur_state == FACE_LANDMARK_LIVING_BODY: _thread.start_new_thread(face_landmark_mouth_blink_counter_det_thread,())
    elif cur_state == FACE_LANDMARK_EXPRESSION: _thread.start_new_thread(face_landmark_expression_det_thread,())
    elif cur_state == SELF_LEARNING_CLASSIFIER_MODE: _thread.start_new_thread(self_learning_thread,())
    elif cur_state == COLOR_OBJECT_COUNT_MODE:
        try:
            cur_mode = args["model_dict"]["cur_mode"]
            _thread.start_new_thread(color_count_thread,(cur_mode,))
        except Exception as e:
            print(e)
    elif cur_state == CLASSIFY_MODEL_MODE:
        try:
            komodel_path = args["model_dict"]["classify_komodel_path"]
            _num = args["model_dict"]["classify_num"]
            # komodel_path = "/data/classify.kmodel"
            # _num = 3
            _thread.start_new_thread(classify_kmodel_thread,(komodel_path,_num))
        except Exception as e:
            print(e)
    elif cur_state == DETECT_MODEL_MODE:
        try:
            komodel_path = args["model_dict"]["detect_komodel_path"]
            _num = args["model_dict"]["detect_num"]
            print(komodel_path,_num)
            _thread.start_new_thread(detect_kmodel_thread,(komodel_path,_num))
        except Exception as e:
            print(e)
        
      
   

