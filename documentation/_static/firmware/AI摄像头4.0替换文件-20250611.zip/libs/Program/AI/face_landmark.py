from libs.PipeLine import ScopedTiming
from libs.AIBase import AIBase
from libs.AI2D import Ai2d
from media.media import *
# from time import *
import nncase_runtime as nn
import ulab.numpy as np
import time
import image
import aidemo
import random
import gc
import sys
import math

rgb888p_size = [640, 360]
display_size = [544, 368]

# 阈值配置
EAR_THRESHOLD = 0.22    # 眨眼阈值
MAR_THRESHOLD = 0.32     # 张嘴阈值
SIMLE_THRESHOLD = 1.5  # 微笑阈值

EAR_OPEN_THRESH = 0.28      # 眼睛纵横比阈值（正常约0.2-0.25）
BROW_RAISE_THRESH = -8 # 眉毛抬高阈值（像素差）
ANGER_THRESHOLD = 0.2  # 阈值
CORNER_ANGLE_THRESH = 1.0 # 嘴角角度

CONSECUTIVE_FRAMES = 2  # 连续帧数

# 人脸关键点不同部位关键点列表
# _dict_kp_seq = [
#     [43, 44, 45, 47, 46, 50, 51, 49, 48],              # left_eyebrow 左眉 0
#     [97, 98, 99, 100, 101, 105, 104, 103, 102],        # right_eyebrow  1
#     [35, 36, 33, 37, 39, 42, 40, 41],                  # left_eye 左眼 2
#     [89, 90, 87, 91, 93, 96, 94, 95],                  # right_eye 3
#     [34, 88],                                          # pupil 瞳孔  4
#     [72, 73, 74, 86],                                  # bridge_nose  鼻梁 5
#     [77, 78, 79, 80, 85, 84, 83],                      # wing_nose  鼻翼 6
#     [52, 55, 56, 53, 59, 58, 61, 68, 67, 71, 63, 64],  # out_lip 外唇 7 【0-11】
#     [65, 54, 60, 57, 69, 70, 62, 66],                  # in_lip  内唇 8
#     [1, 9, 10, 11, 12, 13, 14, 15, 16, 2, 3, 4, 5, 6, 7, 8, 0, 24, 23, 22, 21, 20, 19, 18, 32, 31, 30, 29, 28, 27, 26, 25, 17]  # basin 外轮廓  9
# ]


def get_face_width(basin):
    basin = np.asarray(basin)
    face_width = np.linalg.norm(basin[1] - basin[31])
    
    return face_width


def angle_between_lines(line1_points, line2_points):
    """
    计算两条直线的夹角（单位：度）
    
    参数：
        line1_points: 直线1的两个点，格式为 [[x1, y1], [x2, y2]]
        line2_points: 直线2的两个点，格式为 [[x3, y3], [x4, y4]]
    
    返回：
        两直线的夹角（0°~90°）
    """
    # NumPy数组
    p1, p2 = line1_points
    p3, p4 = line2_points
    
    # 计算方向向量
    v1 = p2 - p1
    v2 = p4 - p3
    
    # 计算点积和模长
    dot_product = np.dot(v1, v2)
    norm_v1 = np.linalg.norm(v1)
    norm_v2 = np.linalg.norm(v2)
    
    # 处理零向量（无效直线）
    if norm_v1 == 0 or norm_v2 == 0:
        raise ValueError("直线不能重合点")
    
    # 计算余弦值（取绝对值确保角度在0~90°）
    cos_theta = math.fabs(dot_product) / (norm_v1 * norm_v2)
    cos_theta = max(0.0, min(1.0, cos_theta))  # 手动clip
    
    # 计算角度（弧度转角度）
    # theta_rad = np.arccos(cos_theta)
    # theta_deg = np.degrees(theta_rad)
    theta_deg = math.degrees(cos_theta)
    
    return theta_deg


def eye_aspect_ratio(eye_points):
    """计算眼睛纵横比"""
    # print(type(eye_points))
    eye_points = np.asarray(eye_points)
    # print(type(eye_points))
    # 上眼睑和下眼睑的垂直距离（取多组点平均）
    v1 = np.linalg.norm(eye_points[1] - eye_points[7])
    v2 = np.linalg.norm(eye_points[2] - eye_points[6])
    v3 = np.linalg.norm(eye_points[3] - eye_points[5])
    
    # 水平宽度（取两端点）
    h = np.linalg.norm(eye_points[0] - eye_points[4])
    return (v1 + v2 + v3) / (4.0 * h)

def mouth_aspect_ratio(mouth_outer, mouth_inner):
    """计算嘴巴纵横比"""
    mouth_outer = np.asarray(mouth_outer)
    mouth_inner = np.asarray(mouth_inner)
    # 外轮廓高度（上唇到下唇）
    v_outer = np.linalg.norm(mouth_outer[3] - mouth_outer[9])
    # 内轮廓高度（张开的程度）
    v_inner = np.linalg.norm(mouth_inner[2] - mouth_inner[6])
    # 外轮廓宽度
    h = np.linalg.norm(mouth_outer[0] - mouth_outer[6])
    return (v_outer + v_inner) / (2.0 * h)

def brow_raise_degree(brow_points, eye_points):
    """
    计算眉毛中点与上眼睑的垂直距离（值越大表示越惊讶）
    """
    brow_points = np.asarray(brow_points)
    eye_points = np.asarray(eye_points)
    # 计算眉毛中点（取中间3点平均）
    brow_center = np.mean(brow_points[1:4], axis=0)
    
    # 计算上眼睑中点（取上眼睑3点平均）
    upper_eye_center = np.mean(eye_points[1:4], axis=0)
    
    # 垂直距离（考虑图像坐标系y轴向下）
    return brow_center[1] - upper_eye_center[1]  # 值越小表示眉毛越高


def mouth_corner_angle(mouth_outer, mouth_inner):
    mouth_outer = np.asarray(mouth_outer)
    mouth_inner = np.asarray(mouth_inner)
    """计算嘴角连线与水平面的角度（微笑时角度>0） 嘴角上扬"""
    left_corner = mouth_outer[0]  # 左嘴角
    right_corner = mouth_outer[6] # 右嘴角
    # 上唇到下唇中点
    # mouth_center = (mouth_outer[3] + mouth_outer[9])/2
    # 内唇中点
    mouth_center = (mouth_inner[2] + mouth_inner[6])/2
    # print(angle_between_lines((left_corner,mouth_center),(right_corner,mouth_center)))
    # print('angle_between_lines')
     # 计算嘴角上扬程度
    delta_y = -((left_corner[1] + right_corner[1]) / 2) + mouth_center[1]

    # 计算嘴角连线角度
    angle = np.arctan2(-(right_corner[1] - left_corner[1]), right_corner[0] - left_corner[0]) * 180 / np.pi  + 1
  
    # dy = left_corner[1] - right_corner[1] 
    # dx = left_corner[0] - right_corner[0]
    # angle = np.degrees(np.arctan2(-dy, dx))
    
    # print('mouth_corner_angle:{},{}'.format(delta_y,angle))
    return delta_y,angle

def detect_smile(mouth_outer,mouth_inner,basin): 
    smile = False
    face_width = get_face_width(basin)
    delta_y,angle = mouth_corner_angle(mouth_outer,mouth_inner)
    mar = mouth_aspect_ratio(mouth_outer, mouth_inner)
    mouth_outer = np.asarray(mouth_outer)
    """通过嘴巴外轮廓宽度与高度的比值判断微笑"""
    # 计算嘴巴宽度（左右嘴角点距离）
    width = np.linalg.norm(mouth_outer[0] - mouth_outer[6])
    # 计算嘴巴高度（上下唇中点距离）
    height = np.linalg.norm(mouth_outer[3] - mouth_outer[9])
    ratio = width / (height + 1e-5)  # 防止除以0

    # print('detect_smile:{}'.format(angle))
    # print('smile ratio:{}'.format(ratio))
     # 判断嘴角是否上扬
    if delta_y/face_width > 0 and angle > CORNER_ANGLE_THRESH and mar < (MAR_THRESHOLD - 0.02):
        print("微笑")
        smile = True
    else:
        print("嘴角未上扬")
        smile = False
        
    # smile = ratio > SIMLE_THRESHOLD and angle > CORNER_ANGLE_THRESH   # 嘴角角度阈值（度）
    return smile  # 阈值需实验调整

def detect_anger(left_eyebrow, right_eyebrow, mouth_outer, basin):
    """通过眉毛内聚和嘴巴宽度判断生气"""
    anger = False
    left_eyebrow = np.asarray(left_eyebrow)
    right_eyebrow = np.asarray(right_eyebrow)
    mouth_outer = np.asarray(mouth_outer)
    
    face_width = get_face_width(basin)
   
    # 眉毛内侧点距离
    inner_brow_dist = np.linalg.norm(left_eyebrow[4] - right_eyebrow[0])/face_width
    # 嘴巴宽度
    mouth_width = np.linalg.norm(mouth_outer[0] - mouth_outer[6])/face_width

    # print('detect_anger:{},{},{}'.format(face_width, inner_brow_dist, mouth_width))
    if (inner_brow_dist < 0.2) and (mouth_width < 0.25):  # 阈值需调整
        print("生气")
        anger = True
    return anger

def detect_sadness(mouth_outer,mouth_inner,basin):
    sadness = False
    """通过嘴角和下唇中点位置判断 伤心"""
    face_width = get_face_width(basin)
    delta_y,angle = mouth_corner_angle(mouth_outer,mouth_inner)   # 嘴角倾斜角度
    mar = mouth_aspect_ratio(mouth_outer, mouth_inner)
    mouth_outer = np.asarray(mouth_outer)
  
    left_corner = mouth_outer[0]   # 左嘴角 
    right_corner = mouth_outer[6]  # 右嘴角 
    lower_lip_center = mouth_outer[3]  # 下唇中点（索引53）
    
    # 嘴角到下巴的垂直距离（下拉时距离减小）
    mouth_height = np.linalg.norm(lower_lip_center - (left_corner + right_corner)/2)/face_width
    delta_y = delta_y/face_width
    
    # print('detect_sadness:{},{},{}'.format(delta_y, mouth_height, angle))
    if delta_y/face_width < 0.2 and angle < 0.1 and mouth_height < 2 and mar < (MAR_THRESHOLD - 0.1):
        print("伤心")
        sadness = True
    else:
        sadness = False
        print("未伤心")
    
    return sadness


def detect_surprise(left_brow,right_brow,left_eye,right_eye,mouth_outer,mouth_inner):
    surprise = False
    # 计算特征值
    brow_raise_left = brow_raise_degree(left_brow, left_eye)
    brow_raise_right = brow_raise_degree(right_brow, right_eye)
    brow_raise_avg = (brow_raise_left + brow_raise_right) / 2
    
    ear_left = eye_aspect_ratio(left_eye)
    ear_right = eye_aspect_ratio(right_eye)
    ear_avg = (ear_left + ear_right) / 2
    
    mar = mouth_aspect_ratio(mouth_outer, mouth_inner)
    print('detect_surprise:{},{},{}'.format(brow_raise_avg, ear_avg, mar))

    # 综合判断
    surprise = (
        brow_raise_avg < BROW_RAISE_THRESH and 
        ear_avg > EAR_OPEN_THRESH and 
        mar > MAR_THRESHOLD
    )
    
    if surprise:
        print('surprise')
        surprise = True
         
    return surprise

# 自定义人脸检测任务类
class FaceDetApp(AIBase):
    def __init__(self,kmodel_path,model_input_size,anchors,confidence_threshold=0.25,nms_threshold=0.3,rgb888p_size=[1280,720],display_size=[1920,1080],debug_mode=0):
        super().__init__(kmodel_path,model_input_size,rgb888p_size,debug_mode)
        # kmodel路径
        self.kmodel_path=kmodel_path
        # 检测模型输入分辨率
        self.model_input_size=model_input_size
        # 置信度阈值
        self.confidence_threshold=confidence_threshold
        # nms阈值
        self.nms_threshold=nms_threshold
        # 检测任务锚框
        self.anchors=anchors
        # sensor给到AI的图像分辨率，宽16字节对齐
        self.rgb888p_size=[ALIGN_UP(rgb888p_size[0],16),rgb888p_size[1]]
        # 视频输出VO分辨率，宽16字节对齐
        self.display_size=[ALIGN_UP(display_size[0],16),display_size[1]]
        # debug模式
        self.debug_mode=debug_mode
        # 实例化Ai2d，用于实现模型预处理
        self.ai2d=Ai2d(debug_mode)
        # 设置Ai2d的输入输出格式和类型
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT,nn.ai2d_format.NCHW_FMT,np.uint8, np.uint8)

    # 配置预处理操作，这里使用了pad和resize，Ai2d支持crop/shift/pad/resize/affine，具体代码请打开/sdcard/libs/AI2D.py查看
    def config_preprocess(self,input_image_size=None):
        with ScopedTiming("set preprocess config",self.debug_mode > 0):
            # 初始化ai2d预处理配置，默认为sensor给到AI的尺寸，可以通过设置input_image_size自行修改输入尺寸
            ai2d_input_size=input_image_size if input_image_size else self.rgb888p_size
            # 设置padding预处理
            self.ai2d.pad(self.get_pad_param(), 0, [104,117,123])
            # 设置resize预处理
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            # 构建预处理流程,参数为预处理输入tensor的shape和预处理输出的tensor的shape
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],[1,3,self.model_input_size[1],self.model_input_size[0]])

    # 自定义后处理，results是模型输出的array列表，这里使用了aidemo的face_det_post_process列表
    def postprocess(self,results):
        with ScopedTiming("postprocess",self.debug_mode > 0):
            res = aidemo.face_det_post_process(self.confidence_threshold,self.nms_threshold,self.model_input_size[0],self.anchors,self.rgb888p_size,results)
            if len(res)==0:
                return res
            else:
                return res[0]

    # 计算padding参数
    def get_pad_param(self):
        dst_w = self.model_input_size[0]
        dst_h = self.model_input_size[1]
        # 计算最小的缩放比例，等比例缩放
        ratio_w = dst_w / self.rgb888p_size[0]
        ratio_h = dst_h / self.rgb888p_size[1]
        if ratio_w < ratio_h:
            ratio = ratio_w
        else:
            ratio = ratio_h
        new_w = (int)(ratio * self.rgb888p_size[0])
        new_h = (int)(ratio * self.rgb888p_size[1])
        dw = (dst_w - new_w) / 2
        dh = (dst_h - new_h) / 2
        top = (int)(round(0))
        bottom = (int)(round(dh * 2 + 0.1))
        left = (int)(round(0))
        right = (int)(round(dw * 2 - 0.1))
        return [0,0,0,0,top, bottom, left, right]

# 自定义人脸关键点任务类
class FaceLandMarkApp(AIBase):
    def __init__(self,kmodel_path,model_input_size,rgb888p_size=[1920,1080],display_size=[1920,1080],debug_mode=0):
        super().__init__(kmodel_path,model_input_size,rgb888p_size,debug_mode)
        # kmodel路径
        self.kmodel_path=kmodel_path
        # 关键点模型输入分辨率
        self.model_input_size=model_input_size
        # sensor给到AI的图像分辨率，宽16字节对齐
        self.rgb888p_size=[ALIGN_UP(rgb888p_size[0],16),rgb888p_size[1]]
        # 视频输出VO分辨率，宽16字节对齐
        self.display_size=[ALIGN_UP(display_size[0],16),display_size[1]]
        # debug模式
        self.debug_mode=debug_mode
        # 目标矩阵
        self.matrix_dst=None
        self.ai2d=Ai2d(debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT,nn.ai2d_format.NCHW_FMT,np.uint8, np.uint8)

    # 配置预处理操作，这里使用了affine，Ai2d支持crop/shift/pad/resize/affine，具体代码请打开/sdcard/libs/AI2D.py查看
    def config_preprocess(self,det,input_image_size=None):
        with ScopedTiming("set preprocess config",self.debug_mode > 0):
            # 初始化ai2d预处理配置，默认为sensor给到AI的尺寸，可以通过设置input_image_size自行修改输入尺寸
            ai2d_input_size=input_image_size if input_image_size else self.rgb888p_size
            # 计算目标矩阵，并获取仿射变换矩阵
            self.matrix_dst = self.get_affine_matrix(det)
            affine_matrix = [self.matrix_dst[0][0],self.matrix_dst[0][1],self.matrix_dst[0][2],
                             self.matrix_dst[1][0],self.matrix_dst[1][1],self.matrix_dst[1][2]]
            # 设置仿射变换预处理
            self.ai2d.affine(nn.interp_method.cv2_bilinear,0, 0, 127, 1,affine_matrix)
            # 构建预处理流程,参数为预处理输入tensor的shape和预处理输出的tensor的shape
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],[1,3,self.model_input_size[1],self.model_input_size[0]])

    # 自定义后处理，results是模型输出的array列表，这里使用了aidemo库的invert_affine_transform接口
    def postprocess(self,results):
        with ScopedTiming("postprocess",self.debug_mode > 0):
            pred=results[0]
            # （1）将人脸关键点输出变换模型输入
            half_input_len = self.model_input_size[0] // 2
            pred = pred.flatten()
            for i in range(len(pred)):
                pred[i] += (pred[i] + 1) * half_input_len
            # （2）获取仿射矩阵的逆矩阵
            matrix_dst_inv = aidemo.invert_affine_transform(self.matrix_dst)
            matrix_dst_inv = matrix_dst_inv.flatten()
            # （3）对每个关键点进行逆变换
            half_out_len = len(pred) // 2
            for kp_id in range(half_out_len):
                old_x = pred[kp_id * 2]
                old_y = pred[kp_id * 2 + 1]
                # 逆变换公式
                new_x = old_x * matrix_dst_inv[0] + old_y * matrix_dst_inv[1] + matrix_dst_inv[2]
                new_y = old_x * matrix_dst_inv[3] + old_y * matrix_dst_inv[4] + matrix_dst_inv[5]
                pred[kp_id * 2] = new_x
                pred[kp_id * 2 + 1] = new_y
            return pred

    def get_affine_matrix(self,bbox):
        # 获取仿射矩阵，用于将边界框映射到模型输入空间
        with ScopedTiming("get_affine_matrix", self.debug_mode > 1):
            # 从边界框提取坐标和尺寸
            x1, y1, w, h = map(lambda x: int(round(x, 0)), bbox[:4])
            # 计算缩放比例，使得边界框映射到模型输入空间的一部分
            scale_ratio = (self.model_input_size[0]) / (max(w, h) * 1.5)
            # 计算边界框中心点在模型输入空间的坐标
            cx = (x1 + w / 2) * scale_ratio
            cy = (y1 + h / 2) * scale_ratio
            # 计算模型输入空间的一半长度
            half_input_len = self.model_input_size[0] / 2
            # 创建仿射矩阵并进行设置
            matrix_dst = np.zeros((2, 3), dtype=np.float)
            matrix_dst[0, 0] = scale_ratio
            matrix_dst[0, 1] = 0
            matrix_dst[0, 2] = half_input_len - cx
            matrix_dst[1, 0] = 0
            matrix_dst[1, 1] = scale_ratio
            matrix_dst[1, 2] = half_input_len - cy
            return matrix_dst

# 人脸标志解析
class FaceLandMark:
    def __init__(self,face_det_kmodel,face_landmark_kmodel,det_input_size,landmark_input_size,anchors,confidence_threshold=0.25,nms_threshold=0.3,rgb888p_size=[1920,1080],display_size=[1920,1080],debug_mode=0):
        # 人脸检测模型路径
        self.face_det_kmodel=face_det_kmodel
        # 人脸标志解析模型路径
        self.face_landmark_kmodel=face_landmark_kmodel
        # 人脸检测模型输入分辨率
        self.det_input_size=det_input_size
        # 人脸标志解析模型输入分辨率
        self.landmark_input_size=landmark_input_size
        # anchors
        self.anchors=anchors
        # 置信度阈值
        self.confidence_threshold=confidence_threshold
        # nms阈值
        self.nms_threshold=nms_threshold
        # sensor给到AI的图像分辨率，宽16字节对齐
        self.rgb888p_size=[ALIGN_UP(rgb888p_size[0],16),rgb888p_size[1]]
        # 视频输出VO分辨率，宽16字节对齐
        self.display_size=[ALIGN_UP(display_size[0],16),display_size[1]]
      
        # debug_mode模式
        self.debug_mode=debug_mode

        # 人脸关键点不同部位关键点列表
        self.dict_kp_seq = [
            [43, 44, 45, 47, 46, 50, 51, 49, 48],              # left_eyebrow 左眉
            [97, 98, 99, 100, 101, 105, 104, 103, 102],        # right_eyebrow 
            [35, 36, 33, 37, 39, 42, 40, 41],                  # left_eye 眼
            [89, 90, 87, 91, 93, 96, 94, 95],                  # right_eye
            [34, 88],                                          # pupil 瞳孔 
            [72, 73, 74, 86],                                  # bridge_nose  鼻梁
            [77, 78, 79, 80, 85, 84, 83],                      # wing_nose  鼻翼
            [52, 55, 56, 53, 59, 58, 61, 68, 67, 71, 63, 64],  # out_lip 外唇
            [65, 54, 60, 57, 69, 70, 62, 66],                  # in_lip  内唇
            [1, 9, 10, 11, 12, 13, 14, 15, 16, 2, 3, 4, 5, 6, 7, 8, 0, 24, 23, 22, 21, 20, 19, 18, 32, 31, 30, 29, 28, 27, 26, 25, 17]  # basin
        ]

        # 人脸关键点不同部位（顺序同dict_kp_seq）颜色配置，argb
        self.color_list_for_osd_kp = [
            (255, 0, 255, 0),
            (255, 0, 255, 0),
            (255, 255, 0, 255),
            (255, 255, 0, 255),
            (255, 255, 0, 0),
            (255, 255, 170, 0),
            (255, 255, 255, 0),
            (255, 0, 255, 255),
            (255, 255, 220, 50),
            (255, 30, 30, 255)
        ]
        # 人脸检测实例
        self.face_det=FaceDetApp(self.face_det_kmodel,model_input_size=self.det_input_size,anchors=self.anchors,confidence_threshold=self.confidence_threshold,nms_threshold=self.nms_threshold,rgb888p_size=self.rgb888p_size,display_size=self.display_size,debug_mode=0)
        # 人脸标志解析实例
        self.face_landmark=FaceLandMarkApp(self.face_landmark_kmodel,model_input_size=self.landmark_input_size,rgb888p_size=self.rgb888p_size,display_size=self.display_size)
        # 配置人脸检测的预处理
        self.face_det.config_preprocess()
        
        # 计数器
        self.blink_counter = 0
        self.mouth_open_counter = 0
        self.blink_counter_sum = 0
        self.mouth_open_counter_sum = 0
        #
        self.expression = 0 

    # run函数
    def run(self,input_np):
        # 执行人脸检测
        det_boxes=self.face_det.run(input_np)
        landmark_res=[]
        for det_box in det_boxes:
            # 对每一个检测到的人脸解析关键部位
            self.face_landmark.config_preprocess(det_box)
            res=self.face_landmark.run(input_np)
            landmark_res.append(res)
        return det_boxes,landmark_res


    # 绘制人脸解析效果
    def draw_result(self,osd_img,dets,landmark_res):
        draw_img = image.Image(self.display_size[0], self.display_size[1], image.RGB888)
        if dets:
            osd_img.copy_to(draw_img)
            draw_img_np = draw_img.to_numpy_ref()
            # draw_img_np = np.zeros((self.display_size[1],self.display_size[0],4),dtype=np.uint8)
            # draw_img = image.Image(self.display_size[0], self.display_size[1], image.ARGB8888, alloc=image.ALLOC_REF,data = draw_img_np)
            # draw_img.replace(draw_img, hmirror=False, vflip=True)
            # draw_img = draw_img.to_rgb888()
            for pred in landmark_res:
                # （1）获取单个人脸框对应的人脸关键点
                # print(len(landmark_res))
                # print('1'*10)
                for sub_part_index in range(len(self.dict_kp_seq)):
                    # （2）构建人脸某个区域关键点集
                    sub_part = self.dict_kp_seq[sub_part_index]
                    face_sub_part_point_set = []
                    for kp_index in range(len(sub_part)):
                        real_kp_index = sub_part[kp_index]
                        x, y = pred[real_kp_index * 2], pred[real_kp_index * 2 + 1]
                        x = int(x * self.display_size[0] // self.rgb888p_size[0])
                        y = int(y * self.display_size[1] // self.rgb888p_size[1])
                        face_sub_part_point_set.append((x, y))
                    

                    # （3）画人脸不同区域的轮廓
                    if sub_part_index in (9, 6):
                        color = np.array(self.color_list_for_osd_kp[sub_part_index],dtype = np.uint8)
                        face_sub_part_point_set = np.array(face_sub_part_point_set)
                        aidemo.polylines(draw_img_np, face_sub_part_point_set,False,color,5,8,0)
                    elif sub_part_index == 4: # 瞳孔
                        color = self.color_list_for_osd_kp[sub_part_index]
                        for kp in face_sub_part_point_set:
                            x,y = kp[0],kp[1]
                            draw_img.draw_circle(x, y, 2, color, 1)
                    else:
                        color = np.array(self.color_list_for_osd_kp[sub_part_index],dtype = np.uint8)
                        face_sub_part_point_set = np.array(face_sub_part_point_set)
                        aidemo.contours(draw_img_np, face_sub_part_point_set,-1,color,2,8)
            # pl.osd_img.copy_from(draw_img)
            osd_img.copy_from(draw_img)
    

    def mouth_blink_counter(self,left_eye,right_eye,mouth_outer,mouth_inner):
        # 计算EAR和MAR
        left_ear = eye_aspect_ratio(left_eye)
        right_ear = eye_aspect_ratio(right_eye)
        ear_avg = (left_ear + right_ear) / 2.0
        mar = mouth_aspect_ratio(mouth_outer, mouth_inner)

        # 眨眼检测
        if ear_avg < EAR_THRESHOLD:
            self.blink_counter += 1
            if self.blink_counter >= CONSECUTIVE_FRAMES:
                print("Blink Detected")
                self.blink_counter_sum += 1
                self.blink_counter = 0
        else:
            self.blink_counter = 0

        # 张嘴检测
        # print("mar {}".format(mar))
        if mar > MAR_THRESHOLD:
            self.mouth_open_counter += 1
            if self.mouth_open_counter >= CONSECUTIVE_FRAMES:
                print("Mouth Open")
                self.mouth_open_counter_sum += 1
                self.mouth_open_counter = 0
        else:
            self.mouth_open_counter = 0
            
        print("blink_counter_sum: {} ,mouth_open_counter_sum: {}".format(self.blink_counter_sum,self.mouth_open_counter_sum))
        return self.blink_counter,self.mouth_open_counter
            
    def facial_expression(self,dets,landmark_res,mode):
        left_eyebrow = []  # left_eyebrow 
        right_eyebrow = []  # right_eyebrow 
        left_eye = []
        right_eye = []
        mouth_outer = []
        mouth_inner = []
        basin = []
        if dets:
            for pred in landmark_res:
                # （1）获取单个人脸框对应的人脸关键点
                for sub_part_index in range(len(self.dict_kp_seq)):
                    # （2）构建人脸某个区域关键点集
                    sub_part = self.dict_kp_seq[sub_part_index]
                    face_sub_part_point_set = []
                    for kp_index in range(len(sub_part)):
                        real_kp_index = sub_part[kp_index]
                        x, y = pred[real_kp_index * 2], pred[real_kp_index * 2 + 1]
                        x = int(x * self.display_size[0] // self.rgb888p_size[0])
                        y = int(y * self.display_size[1] // self.rgb888p_size[1])
                        face_sub_part_point_set.append((x, y))
                    
                    # （3）人脸不同区域的轮廓
                    if sub_part_index == 0: # 左眉毛
                        left_eyebrow = face_sub_part_point_set
                    elif sub_part_index == 1: # 右眉毛
                        right_eyebrow = face_sub_part_point_set
                    elif sub_part_index == 2: # 左眼
                        left_eye = face_sub_part_point_set
                    elif sub_part_index == 3: # 右眼
                        right_eye = face_sub_part_point_set
                    elif sub_part_index == 4: # 瞳孔
                        for kp in face_sub_part_point_set:
                            # print(kp)
                            pass
                    elif sub_part_index == 7: # 外唇
                        mouth_outer = face_sub_part_point_set
                    elif sub_part_index == 8: # 内唇
                        mouth_inner = face_sub_part_point_set
                    elif sub_part_index == 9: 
                        basin = face_sub_part_point_set
                  
                if(mode == 0):            
                    if(len(left_eye)==8 and len(right_eye)==8 and len(mouth_inner)==8 and len(mouth_outer)==12):  
                        self.mouth_blink_counter(left_eye,right_eye,mouth_outer,mouth_inner)
                elif(mode == 1):       
                    if(len(left_eyebrow)==9 and len(right_eyebrow)==9 and len(left_eye)==8 and len(right_eye)==8 and len(mouth_inner)==8 and len(mouth_outer)==12 and len(basin)==33):
                        smile = detect_smile(mouth_outer,mouth_inner,basin)
                        sadness = detect_sadness(mouth_outer,mouth_inner,basin)
                        anger = detect_anger(left_eyebrow,right_eyebrow,mouth_outer,basin)
                        surprise = detect_surprise(left_eyebrow,right_eyebrow,left_eye,right_eye,mouth_outer,mouth_inner)
                        if(smile and not sadness):
                            self.expression = 1  # 开心微笑
                        elif(not smile and sadness):
                            self.expression = 2  # 伤心
                        elif(surprise):
                            self.expression = 3  # 惊讶
                        elif(anger):
                            self.expression = 4  # 生气
                        else:
                            self.expression = 0
                     

                        print('===facial_expression===')  
    
        
    def deinit(self):
        self.face_det.deinit()
        self.face_landmark.deinit()
        gc.collect()
        time.sleep_ms(50)
