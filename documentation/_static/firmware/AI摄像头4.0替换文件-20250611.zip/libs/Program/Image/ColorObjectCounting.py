'''
实验名称：物体计数
'''
import time, os, sys
from media.sensor import * #导入sensor模块，使用摄像头相关接口
from media.display import * #导入display模块，使用display相关接口
from media.media import * #导入media模块，使用meida相关接口



class ColorObjectCount():
    def __init__(self,color=0):
        self.thresholds_list = [[30, 100, 15, 127, 15, 127], # 红色阈值
                                [30, 100, -88, -8, 25, 100], # 绿色阈值
                                [0, 40, 0, 90, -128, -20]] # 蓝色阈值
        self.thresholds = self.thresholds_list[color] # 阈值
        self.cur_mode = color
        self.cur_mode_color = ["红色","绿色","蓝色"]

    def recognize(self,img,show_img):
        blobs = img.find_blobs([self.thresholds],pixels_threshold=500)

        if blobs: #画框显示
            for b in blobs:
                tmp=show_img.draw_rectangle(b[0:4])
                tmp=show_img.draw_cross(b[5], b[6])

        #显示计算信息
        show_img.draw_string_advanced(110, 10, 20, '{}块数量:'.format(self.cur_mode_color[self.cur_mode])+str(len(blobs)), color = (0, 255, 0))
        return len(blobs)



class LABColorObjectCount():
    def __init__(self,color=[30, 100, 15, 127, 15, 127]):
        self.thresholds_list = [[30, 100, 15, 127, 15, 127], # 红色阈值
                                [30, 100, -88, -8, 25, 100], # 绿色阈值
                                [0, 40, 0, 90, -128, -20]] # 蓝色阈值
        self.thresholds = self.thresholds_list[color] # 阈值
        self.cur_mode = color
        # self.cur_mode_color = ["红色","绿色","蓝色"]

    def recognize(self,img,show_img):
        blobs = img.find_blobs([self.thresholds],pixels_threshold=500)

        if blobs: #画框显示
            for b in blobs:
                tmp=show_img.draw_rectangle(b[0:4])
                tmp=show_img.draw_cross(b[5], b[6])

        #显示计算信息
        show_img.draw_string_advanced(110, 10, 20, '颜色块数量:'.format(str(len(blobs))), color = (0, 255, 0))
        return len(blobs)

