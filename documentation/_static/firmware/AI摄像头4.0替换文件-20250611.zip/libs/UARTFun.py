import time
import gc
import sys
import _thread
import machine
from machine import UART
# from libs.Board import LED
from libs.Public import *
from ui.utils import *

class K230UartProcess(object):  
    def __init__(self):
        global uart, k230_flag
        print('K230 UartProcess init')
        uart = UART(UART.UART1, baudrate=1152000, bits=UART.EIGHTBITS, parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
        k230_flag = K230Flag()
      
        self.uart = uart
        time.sleep(0.1)
        '''sensor config'''
        # self.framesize=[]
        # self.pixformat=sensor.RGB565
        self.w=544
        self.h=368
        
        k230_flag['middle_cb'] = self.middle_cb
        
        # 开始串口监听程序
        time.sleep(0.1)
        _thread.start_new_thread(self.uart_listen,())
    
    def middle_cb(self):
        global k230_flag
        print('middle_cb')
        k230_flag["key_middle_status"] = True
        

    def CheckCode(self, tmp):
        ''' 校验和 取低8位'''
        sum = 0
        for i in range(len(tmp)):
            sum += tmp[i]
        return sum & 0xFF    

    def AI_Uart_CMD(self, cmd=0, cmd_type=0, cmd_data=[0, 0, 0, 0, 0, 0]):
        global k230_flag
        data_type=0x01
        check_sum = 0
        CMD_TEMP = [0xBB, 0xAA, data_type, cmd, cmd_type]
        CMD_TEMP.extend(cmd_data)
        for i in range(6-len(cmd_data)):
            CMD_TEMP.append(0)
        for i in range(len(CMD_TEMP)):
            check_sum = check_sum+CMD_TEMP[i]
        
        CMD_TEMP.append(check_sum & 0xFF)
        # self.print_x16(CMD_TEMP)
        # print(CMD_TEMP)
        self.uart.write(bytes(CMD_TEMP))
        del CMD_TEMP
        gc.collect()

        
    def AI_Uart_CMD_String(self, cmd=0x00, cmd_type=0x00, cmd_data=[0x00], str_buf=''):
        global k230_flag
        CMD = [0xBB, 0xAA, 0x02, cmd, cmd_type]
        CMD.extend(cmd_data)
        for i in range(15-len(cmd_data)):
            CMD.append(0)
    
        str_temp = bytes(str_buf, 'utf-8')
        str_len = len(str_temp)

        CMD = bytes(CMD) + bytes([str_len]) + str_temp + bytes([0xAB])
        self.uart.write(CMD)   
        gc.collect()
        # self.print_x16(CMD)
  
    def print_x16(self,date):
        for i in range(len(date)):
            print('{:2x}'.format(date[i]),end=' ')
        print('')

    def wait_mpython_init(self): 
        global k230_flag
        while True:
            gc.collect()
            time.sleep_ms(20)
            if(self.uart.any()):
                head=self.uart.read(2)
                if(head and head[0]==0xAA and head[1]==0xBB):
                    cmd_type = self.uart.read(1)
                    if(cmd_type[0]==0x01):
                        res=self.uart.read(9)
              
                        if(res and res[0]==0x01 and res[1]==0xFF):
                            k230_flag["sensor_mode"] = True
                        
                            self.AI_Uart_CMD(0x01,0x01,0xFF)
                            time.sleep_ms(100)
                            # print(k230_flag)
                            print('==init end==')
                            break
                else:
                    print(head)
                    print('wait_mpython_init error')
                    gc.collect()

    def uart_handle(self):
        global k230_flag
        CMD_TEMP = []
        checksum = 0
        if(self.uart.any()):
            head = self.uart.read(2)
            if(head and head[0] == 0xAA and head[1]==0xBB):
                CMD_TEMP.extend([0xAA,0xBB])
                time.sleep_ms(1)
                cmd_type = self.uart.read(1)
                if(cmd_type==None or len(cmd_type)==0):
                    print('@')
                    return
                CMD_TEMP.append(cmd_type[0])
                if(CMD_TEMP[2]==0x01):
                    time.sleep_ms(1)
                    res = self.uart.read(11)
                    if(res==None or len(res)!=11):
                        print(res)
                        print('#')
                        return
                    for i in range(11):
                        CMD_TEMP.append(res[i])                  
                    checksum = self.CheckCode(CMD_TEMP[:13])
                    if(res and checksum == CMD_TEMP[13]):
                        self.process_cmd(CMD_TEMP)
         
                elif(CMD_TEMP[2]==0x02):
                    time.sleep_ms(1)
                    res = self.uart.read(6)
                    if(res==None or len(res)!=6):
                        print('&')
                        return
                    time.sleep_ms(2)
                    str_len = res[5]
                    str_temp = self.uart.read(str_len)
                    if(str_temp==None or len(str_temp)!=str_len):
                        print('&&')
                        return
                    time.sleep_ms(1)
                    checksum  = self.uart.read(1)
                    if(checksum==None or len(checksum)!=1):
                        print('&&&')
                        return
                    for i in range(6):
                        CMD_TEMP.append(res[i]) 
                    for i in range(str_len):
                        CMD_TEMP.append(str_temp[i])
                    CMD_TEMP.append(checksum[0]) 
                    self.process_cmd(CMD_TEMP)  
                    # print(CMD_TEMP)
                    # print('===CMD_1====')
                    # print(str(str_temp.decode('UTF-8','ignore')))
        else:
            # print(head)
            # print('==head==')
            # print('**^**')
            # del _cmd
            gc.collect()

    def process_cmd(self,cmd):
        global k230_flag
    
        CMD = cmd
        if(len(CMD)>0):
            if(CMD[2]==0x01):
                if(CMD[3]==0x01 and CMD[4]==0xFF):
                    self.AI_Uart_CMD(0x01,0xFF)
                    k230_flag["sensor_mode"] = True
                    time.sleep_ms(1)                    
                    print("=== init end ===")
                elif(CMD[3]==DEFAULT_MODE and CMD[4]==0x01):
                    print("switcherMode")
                    k230_flag["run_mode"] = SENSOR_MODE
                    change_route(url='sensor', arge=k230_flag)   
                    # self.switcherMode(CMD[5])
                elif(CMD[3]==FACE_DETECTION_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_DETECTION_MODE
                    change_route(url='sensor', arge=k230_flag)    
                elif(CMD[3]==OBJECT_RECOGNIZATION_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = OBJECT_RECOGNIZATION_MODE
                    change_route(url='sensor', arge=k230_flag)   
                elif(CMD[3]==FALL_DETECTION and CMD[4]==0x01):
                    k230_flag["run_mode"] = FALL_DETECTION  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==HAND_KEYPOINT_CLASS and CMD[4]==0x01):
                    k230_flag["run_mode"] = HAND_KEYPOINT_CLASS  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==LICENSE_PLATE_RECOGNITION and CMD[4]==0x01):
                    k230_flag["run_mode"] = LICENSE_PLATE_RECOGNITION  
                    change_route(url='sensor', arge=k230_flag)     
                elif(CMD[3]==PERSON_KEYPOINT_DETECT and CMD[4]==0x01):
                    k230_flag["run_mode"] = PERSON_KEYPOINT_DETECT  
                    change_route(url='sensor', arge=k230_flag)   
                elif(CMD[3]==PERSON_KEYPOINT_DETECT_PLUS and CMD[4]==0x01):
                    k230_flag["run_mode"] = PERSON_KEYPOINT_DETECT_PLUS  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==FACE_LANDMARK_LIVING_BODY and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_LANDMARK_LIVING_BODY  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==FACE_LANDMARK_EXPRESSION and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_LANDMARK_EXPRESSION  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==SELF_LEARNING_CLASSIFIER_MODE and CMD[4]==0x01):
                    print(k230_flag)
                    k230_flag["run_mode"] = SELF_LEARNING_CLASSIFIER_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==QRCODE_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = QRCODE_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==BARCODE_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = BARCODE_MODE  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==FALL_DETECTION and CMD[4]==0x01):
                    k230_flag["run_mode"] = FALL_DETECTION  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==FACE_RECOGNITION_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_RECOGNITION_MODE  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==DYNAMIC_GESTURE and CMD[4]==0x01):
                    k230_flag["run_mode"] = DYNAMIC_GESTURE  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==COLOR_OBJECT_COUNT_MODE and CMD[4]==0x01):
                    model_dict = {}
                    model_dict["cur_mode"] = int(CMD[5])
                    
                    k230_flag["run_mode"] = COLOR_OBJECT_COUNT_MODE  
                    k230_flag["model_dict"] = model_dict  
                    change_route(url='sensor', arge=k230_flag)  
                                          
            elif(CMD[2]==0x02):
                if(CMD[3]==CLASSIFY_MODEL_MODE and CMD[4]==0x01):
                    time.sleep(0.1)
                    str_temp = bytes(CMD[9:-1])
                    # print(str_temp)
                    komodel_path = str(str_temp.decode('UTF-8','ignore'))
                    model_dict = {}
                    model_dict["classify_num"] = int(CMD[5])
                    model_dict["classify_komodel_path"] = komodel_path
                    k230_flag["model_dict"] = model_dict  
                    k230_flag["run_mode"] = CLASSIFY_MODEL_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==DETECT_MODEL_MODE and CMD[4]==0x01):
                    str_temp = bytes(CMD[9:-1])
                    komodel_path = str(str_temp.decode('UTF-8','ignore'))
                    model_dict = {}
                    model_dict["detect_num"] = int(CMD[5])
                    model_dict["detect_komodel_path"] = komodel_path
                    k230_flag["model_dict"] = model_dict  
                    k230_flag["run_mode"] = DETECT_MODEL_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                                 
    def uart_listen(self):
        try:
            global k230_flag
            num = 0
            while True:
                gc.collect()
                time.sleep_ms(20)
                # print("uart_listen:"+str(time.ticks_ms()))
                self.uart_handle()
        except Exception as e:
            print(str(e))
            print("==uart_listen==")
    
         
    # def reset(self):
    #     print('==reset==')
    #     self.AI_Uart_CMD(0x01,0x01,0xFF)
    #     time.sleep_ms(10)
    #     machine.reset()
    
    # def switcherMode(self, mode):
    #     if(mode==self.flag.mode or self.flag.sw_lock):
    #         print('switcherMode return')
    #         return
        
    #     self.flag.sw_lock = True
    #     if(self.flag.mode==GUIDEPOST_MODE):
    #         self.guidepost.__del__()
    #         del self.guidepost
    #         self.guidepost=None
    #     elif(self.flag.mode==TRACK_MODE):
    #         self.track.__del__()
    #         del self.track
    #         self.track=None
    #     elif(self.flag.mode==COLOR_STATISTICS_MODE):
    #         self.color_statistics.__del__()
    #         del self.color_statistics
    #         self.color_statistics=None
    #     elif(self.flag.mode==APRILTAG_MODE):
    #         self.apriltag.__del__()
    #         del self.apriltag
    #         self.apriltag=None
    #     elif(self.flag.mode==SELF_LEARNING_CLASSIFIER_MODE):
    #         self.slc.__del__()
    #         del self.slc
    #         self.slc=None
    #     elif(self.flag.mode==OBJECT_RECOGNIZATION_MODE):
    #         self.yolo_detect.__del__()
    #         del self.yolo_detect
    #         self.yolo_detect=None
    #     elif(self.flag.mode==FACE_DETECTION_MODE):
    #         self.face_detect.__del__()
    #         del self.face_detect
    #         self.face_detect=None
        
    #     time.sleep(0.1)
    #     _cmd = self.uart.read()        
    #     del _cmd
    #     gc.collect()
    #     self.flag = self.K230()

    #     for i in range(3):
    #         self.AI_Uart_CMD(0x01,0x01,0xFE)
    #         time.sleep(0.1)
    
    #     # self.lcd.draw_string(0,225, 'switcher mode', lcd.WHITE, lcd.BLUE)
    #     self.flag.sw_lock = False
    #     print('===switcher mode===')
    
    # def show_lcd(self):
    #     img = image.Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, image.ARGB8888)
  
