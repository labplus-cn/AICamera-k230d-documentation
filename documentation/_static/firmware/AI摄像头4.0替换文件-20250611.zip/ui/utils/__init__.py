from media.sensor import *
from media.display import *
from media.media import *
from machine import FPIOA, Pin
import time, os, sys, gc
import lvgl as lv
import _thread
from utils.mp4 import encoder_init, encoder_deinit

from libs.Public import * 
from libs.Board import * 
from libs.UARTFun import *

FONT_SIZE_24 = None
FONT_SIZE_32 = None

display_size = [544, 368]
rgb888p_size = [640, 360]

sensor = None

disp_img1 = None
disp_img2 = None

uart = None
k230_flag = None
uart_process = None

ASSETS_LIST = [
    'home-sensor', 'home-sensor-hv', 'home-example', 'home-example-hv', 'home-camera',
    'home-camera-hv', 'home-photos', 'home-photos-hv', 'home-set', 'home-set-hv',
    'take-pictures', 'take-pictures-hv', 'record-video', 'record-video-hv', 'record-video-ing',
    'roller-arrow-left', 'roller-arrow-left-hv', 'roller-arrow-right', 'roller-arrow-right-hv', 'roller-info',
    'roller-info-hv', 'roller-mark', 'roller-mark-hv', 'roller-play', 'roller-play-hv',
    'play', 'del', 'photo', 'video',
]
assets_src = {}

home_active = 1

k230_flag = K230Flag()


# 串口注册引脚
fpioa.set_function(3,FPIOA.UART1_TXD)
fpioa.set_function(4,FPIOA.UART1_RXD)

# led 灯
led = LED(8)

# 读取按键状态的回调函数
# 注册按键功能
fpioa.set_function(1,FPIOA.GPIO1)
fpioa.set_function(7,FPIOA.GPIO7)
fpioa.set_function(12,FPIOA.GPIO12)
fpioa.set_function(10,FPIOA.GPIO10)

KEY1=Pin(1,Pin.IN,Pin.PULL_UP) # 波轮左键
KEY2=Pin(7,Pin.IN,Pin.PULL_UP) # 波轮右键
KEY3=Pin(12,Pin.IN,Pin.PULL_UP) # 波轮中键
KEY=Pin(10,Pin.IN,Pin.PULL_UP) # 左边单独按键


def media_init():
    global sensor
    Display.init(Display.ST7701, width = display_size[0], height = display_size[1], osd_num=3)
    sensor = Sensor(fps=30)
    sensor.reset()
    sensor.set_framesize(width=display_size[0], height=display_size[1], chn=CAM_CHN_ID_0)
    sensor.set_pixformat(Sensor.RGB888)
    sensor.set_framesize(w = rgb888p_size[0], h = rgb888p_size[1], chn=CAM_CHN_ID_1, alignment=12)
    sensor.set_pixformat(Sensor.YUV420SP, chn=CAM_CHN_ID_1)
    sensor.set_framesize(w=rgb888p_size[0], h=rgb888p_size[1], chn=CAM_CHN_ID_2)
    sensor.set_pixformat(Sensor.RGBP888, chn=CAM_CHN_ID_2)
    encoder_init(rgb888p_size[0], rgb888p_size[1])
    MediaManager.init()
    sensor.run()

def media_deinit():
    encoder_deinit()
    os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    sensor.stop()
    Display.deinit()
    time.sleep_ms(50)
    MediaManager.deinit()

def disp_drv_flush_cb(disp_drv, area, color):
    global disp_img1, disp_img2
    if disp_drv.flush_is_last() == True:
        if disp_img1.virtaddr() == uctypes.addressof(color.__dereference__()):
            disp_img2.clear()
            Display.show_image(disp_img1, layer=Display.LAYER_OSD3)
        else:
            disp_img1.clear()
            Display.show_image(disp_img2, layer=Display.LAYER_OSD3)
        time.sleep(0.01)
    disp_drv.flush_ready()

def lvgl_init():
    global disp_img1, disp_img2, FONT_SIZE_24, FONT_SIZE_32
    lv.init()
    FONT_SIZE_24 = lv.font_load("A:/sdcard/libs/Font/SourceHanSans-Medium-24.bin")
    FONT_SIZE_32 = lv.font_load("A:/sdcard/libs/Font/SourceHanSans-Medium-32.bin")

    disp_drv = lv.disp_create(display_size[0], display_size[1])
    disp_drv.set_flush_cb(disp_drv_flush_cb)
    disp_drv.set_color_format(lv.COLOR_FORMAT.ARGB8888)
    disp_img1 = image.Image(display_size[0], display_size[1], image.BGRA8888)
    disp_img2 = image.Image(display_size[0], display_size[1], image.BGRA8888)
    disp_img1.clear()
    disp_img2.clear()
    disp_drv.set_draw_buffers(disp_img1.bytearray(), disp_img2.bytearray(), disp_img1.size(), lv.DISP_RENDER_MODE.FULL)

def lvgl_deinit():
    global disp_img1, disp_img2
    disp_img1.clear()
    disp_img2.clear()
    lv.deinit()
    del disp_img1
    del disp_img2

# 串口处理函数初始化
def uart_process_init():
    global uart_process
    uart_process = K230UartProcess()


# 按键相关
lv_group = None
key_is_end = None
key_press_time = 0
long_pressed = False  # 是否已经触发过长按
LONG_PRESS_TIME = 800  # ms
key_pressed = None
key_pressed_cb = {}
key_long_pressed_cb = {}

def set_lv_key(_key):
    global key_pressed
    key_pressed = _key

def is_key_pressed(key, debounce_ms=50):
    if key.value() == 0:
        time.sleep_ms(debounce_ms)
        return key.value() == 0
    return False

def detect_key():
    global key_is_end, key_press_time, long_pressed

    if key_is_end is None:
        if is_key_pressed(KEY1):
            key_is_end = 'key1'
            # key_press_time = time.ticks_ms()
            # long_pressed = False
        elif is_key_pressed(KEY2):
            key_is_end = 'key2'
            # key_press_time = time.ticks_ms()
            # long_pressed = False
        elif is_key_pressed(KEY3):
            key_is_end = 'key3'
            key_press_time = time.ticks_ms()
            long_pressed = False
        elif is_key_pressed(KEY):
            key_is_end = 'key'
            # key_press_time = time.ticks_ms()
            # long_pressed = False
        
        if key_is_end != 'key3' and key_pressed_cb.get(key_is_end):
            key_pressed_cb.get(key_is_end)()

    else:
        # 检查长按是否已达到阈值
        if not long_pressed and key_is_end == 'key3':
            press_duration = time.ticks_diff(time.ticks_ms(), key_press_time)
            if press_duration >= LONG_PRESS_TIME:
                if key_long_pressed_cb.get(key_is_end): key_long_pressed_cb.get(key_is_end)() # 滚轮中键有长按事件则触发长按事件
                elif key_pressed_cb.get(key_is_end): key_pressed_cb.get(key_is_end)() # 滚轮中键没有长按事件则触发短按事件
                long_pressed = True  # 防止重复触发

        # 检查是否已释放
        released = (
            (key_is_end == 'key1' and KEY1.value() == 1) or
            (key_is_end == 'key2' and KEY2.value() == 1) or
            (key_is_end == 'key3' and KEY3.value() == 1) or
            (key_is_end == 'key'  and KEY.value()  == 1)
        )

        if released:
            if not long_pressed and key_is_end == 'key3':
                if key_pressed_cb.get(key_is_end): key_pressed_cb.get(key_is_end)() # 触发滚轮中键短按事件
            key_is_end = None
            long_pressed = False
    

# 输入设备按下响应回调
def my_input_read(indev_drv, data):
    global key_pressed
    detect_key()
    if key_pressed is not None:
        data.key = key_pressed
        data.state = lv.INDEV_STATE.PRESSED
        key_pressed = None  # 清除按键状态
    else:
        data.state = lv.INDEV_STATE.RELEASED
    return False  # 表示没有更多数据

# 创建输入设备组并绑定
def create_group():
    global lv_group
    
    lv_group = lv.group_create()
    # 创建输入设备
    indev = lv.indev_create()
    indev.set_type(lv.INDEV_TYPE.KEYPAD)  # 设为键盘输入
    indev.set_read_cb(my_input_read)      # 绑定回调

    # 绑定到 lv_group
    indev.set_group(lv_group)

def set_key_config(fns = {}):
    global key_pressed_cb, key_long_pressed_cb
    key_pressed_cb = {
        'key': fns.get('separate_letf_cb'),
        'key1': fns.get('roller_letf_cb') if fns.get('roller_letf_cb') else lambda: set_lv_key(lv.KEY.PREV),
        'key2': fns.get('roller_right_cb') if fns.get('roller_right_cb') else lambda: set_lv_key(lv.KEY.NEXT),
        'key3': fns.get('roller_middle_cb') if fns.get('roller_middle_cb') else lambda: set_lv_key(lv.KEY.ENTER)
    }
    key_long_pressed_cb = {
        'key': fns.get('long_separate_letf_cb'),
        'key1': fns.get('long_roller_letf_cb'),
        'key2': fns.get('long_roller_right_cb'),
        'key3': fns.get('long_roller_middle_cb')
    }
    group_wrap = fns.get('group_wrap')
    lv_group.set_wrap(group_wrap if group_wrap is not None else True)

def import_module(name):
    try:
        module = __import__(name)
        return module
    except ImportError as e:
        print(f"Module {name} not found: {e}")
        return None

def load_assets():
    global assets_src
    for item in ASSETS_LIST:
        data = None
        with open('/sdcard/ui/assets/' + item + '.png','rb') as f:
            data = f.read()
        img_src = lv.img_dsc_t({
            'data_size': len(data),
            'data': data
        })
        assets_src[item.replace("-", "_")] = img_src

def get_img_src(name):
    return assets_src[name.replace("-", "_")]

def change_route(url, destroy=None, arge={}):
    try:
        if destroy is not None: 
            lv_group.remove_all_objs()
            destroy()  # 删除当前页面
            gc.collect()
        page_obj = import_module('pages/' + url)
        if (url == 'sensor'):
            page_obj.init(arge)
        else:
            page_obj.init()
        lv.scr_load(page_obj.container)
    except Exception as e:
        print(f"path {url} not found: {e}")

def folder_exists(path):
    try:
        stat = os.stat(path)
        return stat[0] & 0x4000 != 0  # 判断是否是目录
    except OSError:
        return False  # 目录不存在或其他错误

def mkdirs(path):
    """ 递归创建多级目录 """
    if folder_exists(path): return

    dirs = path.split("/")
    current_path = ""
    for p in dirs:
        if p:  # 防止空路径
            current_path += "/" + p
            try:
                os.mkdir(current_path)  # 尝试创建
            except OSError as e:
                print(e)

def set_home_active(num):
    global home_active
    home_active = num

def get_home_active():
    return home_active


def optimized_gc_thread():
    global cur_state
    gc_threshold = 200000  # 设置内存阈值
    while True:
        if gc.mem_free() < gc_threshold:
            gc.collect()
        time.sleep_ms(1000)  # 每秒检查一次


def start_optimized_gc_thread():
    _thread.start_new_thread(optimized_gc_thread, ())