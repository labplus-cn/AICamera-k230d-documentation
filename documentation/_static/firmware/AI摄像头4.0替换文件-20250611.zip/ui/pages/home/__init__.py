import _thread, time
import lvgl as lv
from utils import change_route, lv_group, import_module, set_key_config, get_img_src, set_home_active, get_home_active

container = None
INDEX_PAGE = [
    {'name': '传感器', 'page': 'sensor', 'parent': 'home', 'icon': 'sensor'},
    {'name': 'AI示例', 'page': 'example', 'parent': 'home', 'icon': 'example'},
    # {'name': '照相机', 'page': 'camera', 'parent': 'home', 'icon': 'camera'},
    # {'name': '相册', 'page': 'album', 'parent': 'home', 'icon': 'photos'},
    {'name': '照相机', 'page': 'camera-photo', 'parent': 'home', 'icon': 'camera'},
    {'name': '相册', 'page': 'album-photo', 'parent': 'home', 'icon': 'photos'},
    {'name': '系统信息', 'page': 'set', 'parent': 'home', 'icon': 'set'}
]
lastNum = None
is_init = False

# 启动 X 轴移动动画
def start_x_anim(obj, target_x):
    a = lv.anim_t()
    a.init()
    a.set_var(obj)  # 绑定动画对象
    a.set_values(obj.get_style_translate_x(0), target_x)
    a.set_time(200)
    a.set_path_cb(lv.anim_t.path_ease_out)
    a.set_custom_exec_cb(lambda a,val: obj.set_style_translate_x(int(val), 0))
    lv.anim_t.start(a)

# 事件回调：根据滚动位置调整子项的 X 偏移量
def scroll_event_cb(e):
    global lv_group, lastNum
    if not is_init: return
    cont = lv.obj.__cast__(e.get_target())
    fchild = lv_group.get_focused()
    count = cont.get_child_cnt()
    num = None
    for i in range(count):
        if (cont.get_child(i) == fchild):
            num = i
            break
    
    if (num == lastNum): return
    lastNum = num
    set_active_sty(cont, lastNum)
    

def set_active_sty(cont, active):
    count = cont.get_child_cnt()
    for i in range(count):
        child = cont.get_child(i)
        icon = child.get_child(0)
        icon_hv = child.get_child(1)
        if (i == active):
            start_x_anim(child, 22)  # 焦点按钮
            icon.add_flag(lv.obj.FLAG.HIDDEN)
            icon_hv.clear_flag(lv.obj.FLAG.HIDDEN)
        else:
            icon_hv.add_flag(lv.obj.FLAG.HIDDEN)
            icon.clear_flag(lv.obj.FLAG.HIDDEN)
        if i in (active - 1, active + 1):
            start_x_anim(child, 72)  # 相邻按钮
        elif i in (active - 2, active + 2):
            start_x_anim(child, 200)  # 更远按钮

def btn_clicked_event(e):
    code = e.get_code()
    data = e.user_data.__cast__()
    dom = lv.obj.__cast__(e.get_target())
    name = dom.get_child(2)
    if code == lv.EVENT.PRESSED:
        name.set_style_text_color(lv.color_hex(0xFF0000), lv.PART.MAIN)
    elif code == lv.EVENT.RELEASED:
        name.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)

    if code == lv.EVENT.CLICKED:
        change_route(data.get('page'), destroy)

def init_sty():
    global is_init, lastNum
    active = get_home_active()
    if (active != lastNum): lastNum = active
    cont = container.get_child(0)
    set_active_sty(cont, active)
    cont.get_child(active).scroll_to_view(lv.ANIM.OFF)
    time.sleep(0.1)
    lv.group_focus_obj(cont.get_child(active))
    is_init = True

def init():
    global container, lastNum
    css = import_module('pages/home/css')

    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)
    
    content = lv.obj(container)
    content.set_flex_flow(lv.FLEX_FLOW.COLUMN)
    content.add_event(scroll_event_cb, lv.EVENT.SCROLL, None)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.set_scroll_dir(lv.DIR.VER)
    content.set_scroll_snap_y(lv.SCROLL_SNAP.CENTER)
    content.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)

    for i in range(len(INDEX_PAGE)):
        item = INDEX_PAGE[i]
        item_obj = lv.btn(content)
        item_obj.add_style(css.item_sty, lv.PART.MAIN)
        item_obj.add_style(css.item_active_sty, lv.STATE.FOCUSED)
        item_obj.add_style(css.item_clicked_sty, lv.STATE.PRESSED)
        item_obj.add_event(btn_clicked_event, lv.EVENT.ALL, {"page": item.get('page')})
        item_obj.set_scroll_dir(lv.DIR.NONE)
        lv_group.add_obj(item_obj)
        
        item_icon = lv.img(item_obj)
        item_icon.set_src(get_img_src('home-' + item.get('icon')))
        item_icon.add_style(css.item_icon_sty, lv.PART.MAIN)

        item_icon_hv = lv.img(item_obj)
        item_icon_hv.set_src(get_img_src('home-' + item.get('icon') + '-hv'))
        item_icon_hv.add_style(css.item_icon_sty, lv.PART.MAIN)

        item_label = lv.label(item_obj)
        item_label.set_text(item.get('name'))
        item_label.add_style(css.item_label_sty, lv.PART.MAIN)

    # set_active_sty(content, active)
    # 触发滚动事件以更新初始布局
    # content.send_event(lv.EVENT.SCROLL, None)

    # 确保当前默认选中按钮位于中央
    # content.get_child(active).scroll_to_view(lv.ANIM.OFF)
    _thread.start_new_thread(init_sty,())

    set_key_config({ 'group_wrap': False })

def destroy():
    global container, is_init
    set_home_active(lastNum)
    container.clean()
    container = None
    is_init = False