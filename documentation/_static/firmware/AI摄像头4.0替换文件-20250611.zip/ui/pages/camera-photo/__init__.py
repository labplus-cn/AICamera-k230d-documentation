import lvgl as lv
import _thread, gc, time, os
from media.display import *
from utils import import_module, change_route, set_key_config, get_img_src, sensor

file_path = '/data/Camera/Photos/'
container = None
camera_flag = False
take_picture = False
view_img = None

def back_timer_cb(timer):
    data = timer.user_data.__cast__()
    label = data.get('label')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    # change_route('camera', destroy)
    change_route('home', destroy)

def back_event(e):
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(back_timer_cb, 100, {'label': label})  # 1000ms 后调用

def view_event(e):
    print('阅览相册')

def take_picture_event_cb(timer):
    global take_picture
    data = timer.user_data.__cast__()
    dom = data.get('dom')
    dom.set_src(get_img_src('take-pictures'))
    timer._del()
    print('拍照')
    take_picture = True

def take_picture_event(e):
    data = e.user_data.__cast__()
    dom = data.get('dom')
    dom.set_src(get_img_src('take-pictures-hv'))
    lv.timer_create(take_picture_event_cb, 100, {'dom': dom})  # 1000ms 后调用

def camera_start():
    global camera_flag, take_picture
    camera_flag = True

    while camera_flag:
        time.sleep(0.05)
        img=sensor.snapshot(chn=CAM_CHN_ID_0)
        Display.show_image(img, 0, 0, Display.LAYER_OSD1)
        if take_picture:
            #将当前img图片保存
            img1 = img.crop(roi=(0,0,544,368)) #保存图片分辨率可以自行修改，比初始化摄像分辨率小即可
            file_name = str(time.ticks_us()) + '.png'
            img1.save(file_path + file_name)
            time.sleep(0.1)
            data = None
            with open(file_path + file_name, 'rb') as f:
                data = f.read()
            img_src = lv.img_dsc_t({
                'data_size': len(data),
                'data': data
            })
            view_img.set_src(img_src)
            take_picture = False
        gc.collect()

def init():
    global container, view_img
    _thread.start_new_thread(camera_start,())

    css = import_module('pages/camera-photo/css')

    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)

    back_btn = lv.obj(container)
    back_btn.add_style(css.obj_sty, lv.PART.MAIN)
    back_btn.add_style(css.back_sty, lv.PART.MAIN)
    back_btn.add_event(back_event, lv.EVENT.CLICKED, None)
    back_btn.set_scroll_dir(lv.DIR.NONE)

    back_label = lv.label(back_btn)
    back_label.set_text('返回')
    back_label.add_style(css.back_lab_sty, lv.PART.MAIN)

    content = lv.obj(container)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.set_scroll_dir(lv.DIR.NONE)
    content.move_background()

    tool = lv.obj(container)
    tool.add_style(css.obj_sty, lv.PART.MAIN)
    tool.add_style(css.tool_sty, lv.PART.MAIN)
    tool.set_scroll_dir(lv.DIR.NONE)

    tool_pic = lv.obj(tool)
    tool_pic.add_style(css.tool_pic_sty, lv.PART.MAIN)
    tool_pic.add_style(css.tool_pic_active_sty, lv.STATE.FOCUSED)
    tool_pic.add_event(view_event, lv.EVENT.CLICKED, None)
    tool_pic.set_scroll_dir(lv.DIR.NONE)
    view_img = lv.img(tool_pic)
    view_img.add_style(css.view_img_sty, lv.PART.MAIN)

    tool_take = lv.img(tool)
    tool_take.set_src(get_img_src('take-pictures'))
    tool_take.add_style(css.tool_take_sty, lv.PART.MAIN)
    tool_take.add_event(take_picture_event, lv.EVENT.CLICKED, {'dom': tool_take})

    
    set_key_config({
        'separate_letf_cb': lambda: back_btn.send_event(lv.EVENT.CLICKED, None),
        'roller_letf_cb': lambda: tool_pic.send_event(lv.EVENT.CLICKED, None),
        'roller_middle_cb': lambda: tool_take.send_event(lv.EVENT.CLICKED, None),
        'roller_right_cb': lambda: tool_pic.send_event(lv.EVENT.CLICKED, None),
    })


def destroy():
    global container, camera_flag, view_img
    camera_flag = False
    container.clean()
    container = None
    view_img = None