import sys
sys.path.append('/sdcard/ui')
from utils import *

def user_gui_init():
    try:
        data_paths = [
            '/data/Camera/Photos/',
            '/data/Camera/Videos/'
        ]
        for p in data_paths:
            if not folder_exists(p):
                mkdirs(p)

        create_group()
        load_assets()
        change_route('home')
    except Exception as e:
        print("Error:", e)


def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    try:
        media_init()
        lvgl_init()
        user_gui_init()
        uart_process_init()
        start_optimized_gc_thread() 
        while True:
            time.sleep_ms(lv.task_handler()) 
    except BaseException as e:
        print(f"Exception {e}")
    lvgl_deinit()
    media_deinit()
    gc.collect()

if __name__ == "ui":
    main()