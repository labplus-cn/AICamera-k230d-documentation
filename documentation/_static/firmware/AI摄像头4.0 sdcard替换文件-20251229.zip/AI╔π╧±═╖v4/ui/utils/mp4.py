from libs.Utils import *
from media.vencoder import *
from media.sensor import *
from media.media import *
from media.display import *
from mpp.mp4_format import *
from mpp.mp4_format_struct import *
import time, os
import gc
import uctypes

mp4_size=[None, None]
venc_chn = VENC_CHN_ID_0
video_payload_type=K_MP4_CODEC_ID_H264
encoder = None
record_flag = True

def mp4_muxer_init(file_name,  fmp4_flag):
    mp4_cfg = k_mp4_config_s()
    mp4_cfg.config_type = K_MP4_CONFIG_MUXER
    mp4_cfg.muxer_config.file_name[:] = bytes(file_name, 'utf-8')
    mp4_cfg.muxer_config.fmp4_flag = fmp4_flag

    handle = k_u64_ptr()
    ret = kd_mp4_create(handle, mp4_cfg)
    if ret:
        raise OSError("kd_mp4_create failed.")
    return handle.value

def mp4_muxer_create_video_track(mp4_handle, width, height, video_payload_type):
    video_track_info = k_mp4_track_info_s()
    video_track_info.track_type = K_MP4_STREAM_VIDEO
    video_track_info.time_scale = 1000
    video_track_info.video_info.width = width
    video_track_info.video_info.height = height
    video_track_info.video_info.codec_id = video_payload_type
    video_track_handle = k_u64_ptr()
    ret = kd_mp4_create_track(mp4_handle, video_track_handle, video_track_info)
    if ret:
        raise OSError("kd_mp4_create_track failed.")
    return video_track_handle.value

def mp4_muxer_create_audio_track(mp4_handle,channel,sample_rate, bit_per_sample ,audio_payload_type):
    audio_track_info = k_mp4_track_info_s()
    audio_track_info.track_type = K_MP4_STREAM_AUDIO
    audio_track_info.time_scale = 1000
    audio_track_info.audio_info.channels = channel
    audio_track_info.audio_info.codec_id = audio_payload_type
    audio_track_info.audio_info.sample_rate = sample_rate
    audio_track_info.audio_info.bit_per_sample = bit_per_sample
    audio_track_handle = k_u64_ptr()
    ret = kd_mp4_create_track(mp4_handle, audio_track_handle, audio_track_info)
    if ret:
        raise OSError("kd_mp4_create_track failed.")
    return audio_track_handle.value

def encoder_init(width = 640, height = 360):
    global encoder, mp4_size
    # 实例化video encoder
    encoder = Encoder()
    # 设置video encoder 输出buffer
    encoder.SetOutBufs(venc_chn, 8, width, height)
    mp4_size[0] = width
    mp4_size[1] = height

def encoder_deinit():
    global encoder, record_flag
    encoder = None
    record_flag = True


def record_video(sensor):
    global record_flag

    if not record_flag: return
    record_flag = False

    width = mp4_size[0]
    height = mp4_size[1]
    chnAttr = ChnAttrStr(encoder.PAYLOAD_TYPE_H264, encoder.H264_PROFILE_MAIN, width, height)
    streamData = StreamData()

    # 文件名
    file_name="/data/Camera/Videos/mp4_" + str(time.ticks_us()) + ".mp4"
    print(f"正在保存视频到{file_name}...")

    # 编码器参数
    yuv420sp_img = None
    frame_info = k_video_frame_info()
    # MP4相关参数
    idr_index = 0
    video_start_timestamp = 0
    get_first_I_frame = False
    frame_data = k_mp4_frame_data_s()
    save_idr = bytearray(width * height * 3 // 4)

    # mp4 muxer init
    mp4_handle = mp4_muxer_init(file_name, False)
    mp4_video_track_handle = mp4_muxer_create_video_track(mp4_handle, width, height, video_payload_type)

    # 创建编码器
    encoder.Create(venc_chn, chnAttr)
    # 开始编码
    encoder.Start(venc_chn)

    try:
        while True:
            os.exitpoint()
            time.sleep(0.02)

            yuv420sp_img = sensor.snapshot(chn=CAM_CHN_ID_1)
            if (yuv420sp_img == -1):
                continue
            frame_info.v_frame.width = yuv420sp_img.width()
            frame_info.v_frame.height = yuv420sp_img.height()
            frame_info.v_frame.pixel_format = Sensor.YUV420SP
            frame_info.pool_id = yuv420sp_img.poolid()
            frame_info.v_frame.phys_addr[0] = yuv420sp_img.phyaddr()
            if (yuv420sp_img.width() == 800 and yuv420sp_img.height() == 480):
                frame_info.v_frame.phys_addr[1] = frame_info.v_frame.phys_addr[0] + frame_info.v_frame.width*frame_info.v_frame.height + 1024
            elif (yuv420sp_img.width() == 1920 and yuv420sp_img.height() == 1080):
                frame_info.v_frame.phys_addr[1] = frame_info.v_frame.phys_addr[0] + frame_info.v_frame.width*frame_info.v_frame.height + 3072
            elif (yuv420sp_img.width() == 640 and yuv420sp_img.height() == 360):
                frame_info.v_frame.phys_addr[1] = frame_info.v_frame.phys_addr[0] + frame_info.v_frame.width*frame_info.v_frame.height + 3072
            else:
                frame_info.v_frame.phys_addr[1] = frame_info.v_frame.phys_addr[0] + frame_info.v_frame.width*frame_info.v_frame.height
            
            encoder.SendFrame(venc_chn, frame_info)
            encoder.GetStream(venc_chn, streamData) # 获取一帧码流
            streamData.pts[0] = time.ticks_us() # 使用系统时间戳

            stream_type = streamData.stream_type[0]

            # Retrieve first IDR frame and write to MP4 file. Note: The first frame must be an IDR frame.
            if not get_first_I_frame:
                if stream_type == encoder.STREAM_TYPE_I:
                    get_first_I_frame = True
                    video_start_timestamp = streamData.pts[0]
                    # print('streamData.pts', streamData.pts)
                    # print('video_start_timestamp: ',video_start_timestamp)
                    save_idr[idr_index:idr_index+streamData.data_size[0]] = uctypes.bytearray_at(streamData.data[0], streamData.data_size[0])
                    idr_index += streamData.data_size[0]

                    frame_data.codec_id = video_payload_type
                    frame_data.data = uctypes.addressof(save_idr)
                    frame_data.data_length = idr_index
                    frame_data.time_stamp = streamData.pts[0] - video_start_timestamp

                    ret = kd_mp4_write_frame(mp4_handle, mp4_video_track_handle, frame_data)
                    if ret:
                        raise OSError("kd_mp4_write_frame failed.")
                    encoder.ReleaseStream(venc_chn, streamData)
                    continue

                elif stream_type == encoder.STREAM_TYPE_HEADER:
                    save_idr[idr_index:idr_index+streamData.data_size[0]] = uctypes.bytearray_at(streamData.data[0], streamData.data_size[0])
                    idr_index += streamData.data_size[0]
                    encoder.ReleaseStream(venc_chn, streamData)
                    continue
                else:
                    encoder.ReleaseStream(venc_chn, streamData) # 释放一帧码流
                    continue

            # Write video stream to MP4 file （not first idr frame）
            frame_data.codec_id = video_payload_type
            frame_data.data = streamData.data[0]
            frame_data.data_length = streamData.data_size[0]
            frame_data.time_stamp = streamData.pts[0] - video_start_timestamp

            # print("video size: ", streamData.data_size[0], "video type: ", streamData.stream_type[0],"video timestamp:",frame_data.time_stamp)
            ret = kd_mp4_write_frame(mp4_handle, mp4_video_track_handle, frame_data)
            if ret:
                raise OSError("kd_mp4_write_frame failed.")

            encoder.ReleaseStream(venc_chn, streamData) # 释放一帧码流

            if record_flag:
                break
    except BaseException as e:
        print(f"Exception {e}")

    encoder.Stop(venc_chn)
    encoder.Destroy(venc_chn)
    kd_mp4_destroy_tracks(mp4_handle)
    kd_mp4_destroy(mp4_handle)
    print("视频保存完成！")
    gc.collect()

def record_finish():
    global record_flag
    record_flag = True