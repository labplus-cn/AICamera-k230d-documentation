import lvgl as lv
from utils import import_module, change_route, set_key_config

container = None
run_program = import_module('/sdcard/libs/Program/index').run

def back_timer_cb(timer):
    data = timer.user_data.__cast__()
    label = data.get('label')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    change_route('home', destroy)

def back_event(e):
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(back_timer_cb, 100, {'label': label})  # 1000ms 后调用

def init(args):
    global container
    css = import_module('pages/sensor/css')

    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)

    content = lv.obj(container)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
    content.set_scroll_dir(lv.DIR.NONE)

    back_btn = lv.obj(content)
    back_btn.add_style(css.obj_sty, lv.PART.MAIN)
    back_btn.add_style(css.back_sty, lv.PART.MAIN)
    back_btn.add_event(back_event, lv.EVENT.CLICKED, None)
    back_btn.set_scroll_dir(lv.DIR.NONE)

    back_label = lv.label(back_btn)
    back_label.set_text('返回')
    back_label.add_style(css.back_lab_sty, lv.PART.MAIN)

    tips = lv.label(container)
    tips.set_text('请搭配“主控板”运行程序')
    tips.add_style(css.tips_sty, lv.PART.MAIN)
    tips.move_background()
    tips.add_flag(lv.obj.FLAG.HIDDEN)
    
    print(args)
    print("===sensor===")
    mode_code = args.get('run_mode') if args.get('run_mode') else 0

    if not mode_code:
        tips.clear_flag(lv.obj.FLAG.HIDDEN)
        run_program(-1)
    else:
        run_program(mode_code, args)

    set_key_config({
        'separate_letf_cb': lambda: back_btn.send_event(lv.EVENT.CLICKED, None),
        'roller_letf_cb': args.get('left_cb'),
        'roller_middle_cb': args.get('middle_cb'),
        'roller_right_cb': args.get('right_cb'),
    })


def destroy():
    global container
    run_program(0)
    container.clean()
    container = None