import lvgl as lv
import _thread, gc, time, math
from media.display import *
from utils import import_module, change_route, set_key_config, get_img_src, sensor
from utils.mp4 import record_video, record_finish

container = None
time_obj = None
file_path = '/data/Camera/Videos/'
is_capture = False
record_time = 0

def back_timer_cb(timer):
    data = timer.user_data.__cast__()
    label = data.get('label')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    change_route('camera', destroy)

def back_event(e):
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(back_timer_cb, 100, {'label': label})  # 1000ms 后调用

def view_event(e):
    print('阅览视频')

def take_video_event(e):
    global is_capture, record_time
    data = e.user_data.__cast__()
    dom = data.get('dom')
    if is_capture:
        dom.set_src(get_img_src('record-video'))
        is_capture = False
        record_time = 0
        _thread.start_new_thread(lambda: record_finish(), ())
        record_finish()
        print('录制结束')
        time_obj.add_flag(lv.obj.FLAG.HIDDEN)
    else:
        dom.set_src(get_img_src('record-video-ing'))
        time_lab = time_obj.get_child(0)
        time_lab.set_text('00:00:00')
        time_obj.clear_flag(lv.obj.FLAG.HIDDEN)
        is_capture = True
        record_time = time.ticks_ms()
        _thread.start_new_thread(lambda: record_video(sensor), ())
        print('开始录制')

def refresh_record_time():
    global record_time
    seconds = math.floor((time.ticks_ms() - record_time)/1000)
    hours = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60
    time_lab = time_obj.get_child(0)
    time_lab.set_text(f"{hours:02d}:{minutes:02d}:{seconds:02d}")


def camera_start():
    global camera_flag
    camera_flag = True

    num = 0
    while camera_flag:
        time.sleep(0.05)
        num += 1
        img_0=sensor.snapshot(chn=CAM_CHN_ID_0)
        Display.show_image(img_0, 0, 0, Display.LAYER_OSD1)
        gc.collect()
        if is_capture and num % 20:
            num = 0
            refresh_record_time()

def camera_stop():
    global camera_flag
    camera_flag = False


def init():
    global container, time_obj
    css = import_module('pages/camera-video/css')

    _thread.start_new_thread(camera_start,())

    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)

    back_btn = lv.obj(container)
    back_btn.add_style(css.obj_sty, lv.PART.MAIN)
    back_btn.add_style(css.back_sty, lv.PART.MAIN)
    back_btn.add_event(back_event, lv.EVENT.CLICKED, None)
    back_btn.set_scroll_dir(lv.DIR.NONE)

    back_label = lv.label(back_btn)
    back_label.set_text('返回')
    back_label.add_style(css.back_lab_sty, lv.PART.MAIN)

    content = lv.obj(container)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.set_scroll_dir(lv.DIR.NONE)
    content.move_background()

    time_obj = lv.obj(container)
    time_obj.add_style(css.obj_sty, lv.PART.MAIN)
    time_obj.add_style(css.time_obj_sty, lv.PART.MAIN)
    time_obj.set_scroll_dir(lv.DIR.NONE)
    time_lab = lv.label(time_obj)
    time_lab.set_text('00:00:00')
    time_lab.add_style(css.time_lab_sty, lv.PART.MAIN)
    time_obj.add_flag(lv.obj.FLAG.HIDDEN)


    tool = lv.obj(container)
    tool.add_style(css.obj_sty, lv.PART.MAIN)
    tool.add_style(css.tool_sty, lv.PART.MAIN)
    tool.set_scroll_dir(lv.DIR.NONE)

    tool_vid = lv.obj(tool)
    tool_vid.add_style(css.tool_vid_sty, lv.PART.MAIN)
    tool_vid.add_style(css.tool_vid_active_sty, lv.STATE.FOCUSED)
    tool_vid.add_event(view_event, lv.EVENT.CLICKED, None)

    tool_take = lv.img(tool)
    tool_take.set_src(get_img_src('record-video'))
    tool_take.add_style(css.tool_take_sty, lv.PART.MAIN)
    tool_take.add_event(take_video_event, lv.EVENT.CLICKED, {'dom': tool_take})

    
    set_key_config({
        'separate_letf_cb': lambda: back_btn.send_event(lv.EVENT.CLICKED, None),
        'roller_letf_cb': lambda: tool_vid.send_event(lv.EVENT.CLICKED, None),
        'roller_middle_cb': lambda: tool_take.send_event(lv.EVENT.CLICKED, None),
        'roller_right_cb': lambda: tool_vid.send_event(lv.EVENT.CLICKED, None),
    })


def destroy():
    global container, time_obj, camera_flag
    camera_flag = False
    time_obj = None
    container.clean()
    container = None