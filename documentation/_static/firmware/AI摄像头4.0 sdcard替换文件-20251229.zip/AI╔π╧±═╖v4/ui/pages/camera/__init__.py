import lvgl as lv
from utils import import_module, change_route, set_key_config, get_img_src, lv_group

container = None
ITEMS = [{'name': '照相', 'icon': 'photo'}, {'name': '拍摄', 'icon': 'video'}]

def back_timer_cb(timer):
    data = timer.user_data.__cast__()
    label = data.get('label')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    change_route('home', destroy)

def back_event(e):
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(back_timer_cb, 100, {'label': label})  # 1000ms 后调用

def roller_timer_cb(timer):
    data = timer.user_data.__cast__()
    dom = data.get('dom')
    type = data.get('type')
    timer._del()
    if type == 'arrow-left':
        lv_group.focus_prev()
    if type == 'arrow-right':
        lv_group.focus_next()
    if type == 'circle':
        dom.set_style_bg_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
        dom = lv_group.get_focused()
        index = dom.get_index()
        change_route('camera-photo' if index == 0 else 'camera-video', destroy)
    else:
        dom.set_src(get_img_src('roller-' + type))

def roller_event(e):
    data = e.user_data.__cast__()
    dom = data.get('dom')
    type = data.get('type')
    if type == 'circle':
        dom.set_style_bg_color(lv.color_hex(0x999999), lv.PART.MAIN)
    else:
        dom.set_src(get_img_src('roller-' + type + '-hv'))
    lv.timer_create(roller_timer_cb, 100, {'dom': dom, 'type': type})  # 1000ms 后调用

def init():
    global container
    css = import_module('pages/camera/css')

    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)


    header = lv.obj(container)
    header.add_style(css.obj_sty, lv.PART.MAIN)
    header.add_style(css.header_sty, lv.PART.MAIN)
    header.move_foreground()

    back_btn = lv.obj(header)
    back_btn.add_style(css.obj_sty, lv.PART.MAIN)
    back_btn.add_style(css.back_sty, lv.PART.MAIN)
    back_btn.add_event(back_event, lv.EVENT.CLICKED, None)
    back_btn.set_scroll_dir(lv.DIR.NONE)
    back_label = lv.label(back_btn)
    back_label.set_text('返回')
    back_label.add_style(css.back_lab_sty, lv.PART.MAIN)

    roller = lv.obj(header)
    roller.add_style(css.obj_sty, lv.PART.MAIN)
    roller.add_style(css.roller_sty, lv.PART.MAIN)
    roller.set_scroll_dir(lv.DIR.NONE)

    roller_left = lv.img(roller)
    roller_left.set_src(get_img_src('roller-arrow-left'))
    roller_left.add_style(css.roller_left_sty, lv.PART.MAIN)
    roller_left.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_left, 'type': 'arrow-left'})

    roller_middle = lv.obj(roller)
    roller_middle.add_style(css.obj_sty, lv.PART.MAIN)
    roller_middle.add_style(css.roller_middle_sty, lv.PART.MAIN)
    roller_middle.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_middle, 'type': 'circle'})

    roller_right = lv.img(roller)
    roller_right.set_src(get_img_src('roller-arrow-right'))
    roller_right.add_style(css.roller_right_sty, lv.PART.MAIN)
    roller_right.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_right, 'type': 'arrow-right'})


    content = lv.obj(container)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
    content.move_background()
    
    for item in ITEMS:
        item_obj = lv.obj(content)
        item_obj.add_style(css.item_obj_sty, lv.PART.MAIN)
        item_obj.add_style(css.item_obj_active_sty, lv.STATE.FOCUSED)
        item_obj.set_scroll_dir(lv.DIR.NONE)
        lv_group.add_obj(item_obj)

        item_icon = lv.img(item_obj)
        item_icon.set_src(get_img_src(item.get('icon')))
        item_icon.add_style(css.item_icon_sty, lv.PART.MAIN)

        item_label = lv.label(item_obj)
        item_label.set_text(item.get('name'))
        item_label.add_style(css.item_lab_sty, lv.PART.MAIN)

    
    set_key_config({
        'separate_letf_cb': lambda: back_btn.send_event(lv.EVENT.CLICKED, None),
        'roller_letf_cb': lambda: roller_left.send_event(lv.EVENT.CLICKED, None),
        'roller_middle_cb': lambda: roller_middle.send_event(lv.EVENT.CLICKED, None),
        'roller_right_cb': lambda: roller_right.send_event(lv.EVENT.CLICKED, None)
    })


def destroy():
    global container
    container.clean()
    container = None