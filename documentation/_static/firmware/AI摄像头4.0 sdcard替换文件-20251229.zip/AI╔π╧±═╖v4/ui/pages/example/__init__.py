import lvgl as lv
from utils import import_module, change_route, set_key_config, get_img_src, lv_group, set_led_state
from libs.Public import *

container = None
header = None
tips = None
example_nav = None
hide_nav = False
hide_nav_ing = False

EXAMPLE = [
    # {
    #     'name': 'demo',
    #     'num': APS_MODE,
    #     'abbr': 'demo'
    # },
    # AprilTag标签识别
    # 单目标跟踪
    {
        'name': '80类物体识别',
        'num': OBJECT_RECOGNIZATION_MODE,
        'abbr': '物体识别'
    }, {
        'name': '人脸识别',
        'num': FACE_RECOGNITION_MODE,
        'abbr': '人脸识别'
    }, 
    {
        'name': '人脸注册', 
        'num': FACE_REG_MODE,
        'abbr': '人脸注册'
    }, 
    {
        'name': '人脸检测',
        'num': FACE_DETECTION_MODE,
        'abbr': '人脸检测'
    }, {
        'name': '表情识别',
        'num': FACE_LANDMARK_EXPRESSION,
        'abbr': '表情识别'
    }, {
        'name': '眨眼张嘴检测',
        'num': FACE_LANDMARK_LIVING_BODY,
        'abbr': '眨眼张嘴'
    }, {
        'name': '手掌检测',
        'num': HAND_DETECTION,
        'abbr': '手掌检测'
    }, {
        'name': '动态手势识别',
        'num': DYNAMIC_GESTURE,
        'abbr': '手势识别'
    }, {
        'name': '手掌关键点检测',
        'num': HAND_KEYPOINT,
        'abbr': '手掌关键点'
    }, {
        'name': '手掌关键点分类',
        'num': HAND_KEYPOINT_CLASS,
        'abbr': '手掌分类'
    }, {
        'name': '人体检测',
        'num': PERSON_DETECTION,
        'abbr': '人体检测'
    }, {
        'name': '跌倒检测',
        'num': FALL_DETECTION,
        'abbr': '跌倒检测'
    }, {
        'name': '人体姿态识别',
        'num': PERSON_KEYPOINT_DETECT_PLUS,
        'abbr': '姿态识别'
    }, {
        'name': '人体关键点检测',
        'num': PERSON_KEYPOINT_DETECT,
        'abbr': '人体关键点'
    }, {
        'name': '车牌识别',
        'num': LICENSE_PLATE_RECOGNITION,
        'abbr': '车牌识别'
    }, {
        'name': '条形码识别',
        'num': BARCODE_MODE,
        'abbr': '条形码'
    }, {
        'name': '二维码识别',
        'num': QRCODE_MODE,
        'abbr': '二维码'
    }, {
        'name': '边缘检测器', 
        'num': CANNY_FIND_EDGES,
        'abbr': '边缘检测'
    }
]

run_program = import_module('/sdcard/libs/Program/index').run

def back_timer_cb(timer):
    data = timer.user_data.__cast__()
    label = data.get('label')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    change_route('home', destroy)

def back_event(e):
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(back_timer_cb, 100, {'label': label})

# 执行动画
def start_y_anim(obj, target_y):
    a = lv.anim_t()
    a.init()
    a.set_var(obj)  # 绑定动画对象
    a.set_values(obj.get_style_translate_y(lv.PART.MAIN), target_y)
    a.set_time(200)
    a.set_path_cb(lv.anim_t.path_ease_out)
    a.set_custom_exec_cb(lambda a,val: obj.set_style_translate_y(int(val), lv.PART.MAIN))
    lv.anim_t.start(a)

def hide_nav_timer_cb(timer):
    global hide_nav, hide_nav_ing
    if not hide_nav and hide_nav_ing:
        start_y_anim(header, -70)
        start_y_anim(example_nav, 48)
        hide_nav = True
    hide_nav_ing = False
    timer._del()

def roller_timer_cb(timer):
    global hide_nav, hide_nav_ing
    data = timer.user_data.__cast__()
    dom = data.get('dom')
    type = data.get('type')
    dom.set_src(get_img_src('roller-' + type))
    timer._del()
    if type == 'arrow-left':
        lv_group.focus_prev()
    if type == 'arrow-right':
        lv_group.focus_next()
    
    dom = lv_group.get_focused()
    index = dom.get_index()
    if type == 'play':
        print('标记---', index)
        tips.add_flag(lv.obj.FLAG.HIDDEN)
        num = EXAMPLE[index].get('num')
        run_program(num)
        if hide_nav:
            start_y_anim(header, 0)
            start_y_anim(example_nav, 0)
            hide_nav = False
        hide_nav_ing = True
        lv.timer_create(hide_nav_timer_cb, 2000, None)
    else:
        name = EXAMPLE[index].get('name')
        title = data.get('title')
        title.set_text(name)
        example_nav.get_child(index).scroll_to_view(lv.ANIM.OFF)
        print('切换---', name)
        run_program(-1)
        tips.clear_flag(lv.obj.FLAG.HIDDEN)
        hide_nav_ing = False
        if hide_nav:
            start_y_anim(header, 0)
            start_y_anim(example_nav, 0)
            hide_nav = False
        

def roller_event(e):
    data = e.user_data.__cast__()
    dom = data.get('dom')
    type = data.get('type')
    dom.set_src(get_img_src('roller-' + type + '-hv'))
    lv.timer_create(roller_timer_cb, 100, {'dom': dom, 'title': data.get('title'), 'type': type})  # 1000ms 后调用



def init():
    global container, header, tips, example_nav
    css = import_module('pages/example/css')

    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)
    container.set_scroll_dir(lv.DIR.NONE)
    

    header = lv.obj(container)
    header.add_style(css.obj_sty, lv.PART.MAIN)
    header.add_style(css.header_sty, lv.PART.MAIN)
    header.move_foreground()

    back_btn = lv.obj(header)
    back_btn.add_style(css.obj_sty, lv.PART.MAIN)
    back_btn.add_style(css.back_sty, lv.PART.MAIN)
    back_btn.add_event(back_event, lv.EVENT.CLICKED, None)
    back_btn.set_scroll_dir(lv.DIR.NONE)
    back_label = lv.label(back_btn)
    back_label.set_text('返回')
    back_label.add_style(css.back_lab_sty, lv.PART.MAIN)

    title = lv.label(header)
    title.add_style(css.title_sty, lv.PART.MAIN)

    roller = lv.obj(header)
    roller.add_style(css.obj_sty, lv.PART.MAIN)
    roller.add_style(css.roller_sty, lv.PART.MAIN)
    roller.set_scroll_dir(lv.DIR.NONE)

    roller_left = lv.img(roller)
    roller_left.set_src(get_img_src('roller-arrow-left'))
    roller_left.add_style(css.roller_left_sty, lv.PART.MAIN)
    roller_left.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_left, 'title': title, 'type': 'arrow-left'})

    roller_middle = lv.img(roller)
    roller_middle.set_src(get_img_src('roller-play'))
    roller_middle.add_style(css.roller_middle_sty, lv.PART.MAIN)
    roller_middle.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_middle, 'title': title, 'type': 'play'})

    roller_right = lv.img(roller)
    roller_right.set_src(get_img_src('roller-arrow-right'))
    roller_right.add_style(css.roller_right_sty, lv.PART.MAIN)
    roller_right.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_right, 'title': title, 'type': 'arrow-right'})


    content = lv.obj(container)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)
    content.move_background()

    tips = lv.label(container)
    tips.set_text('请按“拔轮中键”运行示例')
    tips.add_style(css.tips_sty, lv.PART.MAIN)
    tips.move_background()


    example_nav = lv.obj(container)
    example_nav.add_style(css.obj_sty, lv.PART.MAIN)
    example_nav.add_style(css.example_nav_sty, lv.PART.MAIN)
    example_nav.set_scroll_dir(lv.DIR.HOR)
    example_nav.set_scroll_snap_x(lv.SCROLL_SNAP.CENTER)
    example_nav.set_scrollbar_mode(lv.SCROLLBAR_MODE.OFF)

    for i in range(len(EXAMPLE)):
        item = EXAMPLE[i]
        item_obj = lv.obj(example_nav)
        item_obj.add_style(css.obj_sty, lv.PART.MAIN)
        item_obj.add_style(css.item_obj_sty, lv.PART.MAIN)
        item_obj.add_style(css.item_obj_active_sty, lv.STATE.FOCUSED)
        item_obj.set_scroll_dir(lv.DIR.NONE)
        if (i + 1) >= len(EXAMPLE): item_obj.set_style_margin_right(0, lv.PART.MAIN)
        lv_group.add_obj(item_obj)

        item_label = lv.label(item_obj)
        item_label.set_text(item.get('abbr'))
        item_label.add_style(css.item_lab_sty, lv.PART.MAIN)
        item_label.set_long_mode(lv.label.LONG.SCROLL)

    title.set_text(EXAMPLE[0].get('name'))
    example_nav.get_child(0).scroll_to_view(lv.ANIM.OFF)
    run_program(-1)


    set_key_config({
        'separate_letf_cb': lambda: back_btn.send_event(lv.EVENT.CLICKED, None),
        'roller_letf_cb': lambda: roller_left.send_event(lv.EVENT.CLICKED, None),
        'roller_middle_cb': lambda: roller_middle.send_event(lv.EVENT.CLICKED, None),
        'roller_right_cb': lambda: roller_right.send_event(lv.EVENT.CLICKED, None),
        'long_roller_middle_cb': set_led_state,
        'group_wrap': True
    })


def destroy():
    global container, header, tips, example_nav
    set_led_state('off')
    run_program(0)
    container.clean()
    container = None
    header = None
    tips = None
    example_nav = None