import lvgl as lv
import os
from utils import import_module, change_route, set_key_config, get_img_src

container = None
roller = None
pic_obj = None
info_obj = None
del_obj = None
file_path = '/data/Camera/Photos/'
photos = []
pic_info = {}
current_index = 0
info_mask = False
del_mask = False

def back_timer_cb(timer):
    data = timer.user_data.__cast__()
    label = data.get('label')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    # change_route('album', destroy)
    change_route('home', destroy)

def back_event(e):
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(back_timer_cb, 100, {'label': label})  # 1000ms 后调用

def reset_roller():
    left = 'roller-arrow-left'
    info = 'roller-info'
    right = 'roller-arrow-right'
    if len(photos) <= 0:
        left = left + '-hv'
        info = info + '-hv'
        right = right + '-hv'
    elif len(photos) == 1:
        left = left + '-hv'
        right = right + '-hv'
    elif current_index == 0:
        left = left + '-hv'
    elif current_index == (len(photos) - 1):
        right = right + '-hv'
    roller.get_child(0).set_src(get_img_src(left))
    roller.get_child(1).set_src(get_img_src(info))
    roller.get_child(2).set_src(get_img_src(right))

def roller_timer_cb(timer):
    global current_index
    data = timer.user_data.__cast__()
    dom = data.get('dom')
    type = data.get('type')
    dom.set_src(get_img_src('roller-' + type))
    timer._del()
    if type == 'arrow-left':
        current_index = 0 if current_index <= 0 else (current_index - 1)
    if type == 'arrow-right':
        current_index = (len(photos) - 1) if current_index >= (len(photos) - 1) else (current_index + 1)

    if type == 'info':
        view_pic_info()
        # print('信息---', current_index, pic_info)
    else:
        # print('切换---', current_index)
        set_pic_src(photos[current_index])
        reset_roller()


def roller_event(e):
    global info_mask
    if (info_mask):
        info_obj.add_flag(lv.obj.FLAG.HIDDEN)
        info_mask = False
        return
    if len(photos) <= 0:
        reset_roller()
        return
    data = e.user_data.__cast__()
    dom = data.get('dom')
    type = data.get('type')
    dom.set_src(get_img_src('roller-' + type + '-hv'))
    lv.timer_create(roller_timer_cb, 100, {'dom': dom, 'type': type})  # 1000ms 后调用

def set_pic_src(file):
    global current_index, pic_info
    try:
        data = None
        with open(file_path + file,'rb') as f:
            data = f.read()
        img_src = lv.img_dsc_t({
            'data_size': len(data),
            'data': data
        })
        pic_obj.set_src(img_src)
        pic_obj.update_layout()
        p_w = pic_obj.get_width()
        p_h= pic_obj.get_height()

        pic_info['name'] = file
        pic_info['date'] = '2024/10/15 15:30'
        pic_info['resolution'] = str(p_w) + ' x ' + str(p_h)
        pic_info['size'] = str(round(len(data) / 1024, 2)) + 'KB'
    except BaseException as e:
        print(f"Exception {e}")
        current_index = 0
        pic_info = {}

def view_pic_info():
    global info_mask
    info_mask = True
    info_obj.clear_flag(lv.obj.FLAG.HIDDEN)
    info_obj.get_child(1).get_child(0).set_text('名称             ' + pic_info['name'])
    info_obj.get_child(1).get_child(1).set_text('创建日期   ' + pic_info['date'])
    info_obj.get_child(1).get_child(2).set_text('分辨率        ' + pic_info['resolution'])
    info_obj.get_child(1).get_child(3).set_text('大小             ' + pic_info['size'])


def show_del_mask():
    global del_mask
    if len(photos) <= 0: return
    del_mask = True
    del_obj.clear_flag(lv.obj.FLAG.HIDDEN)

def del_btn_timer_cb(timer):
    global del_mask, photos, current_index
    data = timer.user_data.__cast__()
    label = data.get('label')
    res = data.get('res')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    print('res: ', res)
    del_mask = False
    del_obj.add_flag(lv.obj.FLAG.HIDDEN)
    if not res: return
    try:
        file_name = pic_info.get('name')
        if not file_name: return
        os.remove(file_path + file_name)
        photos = os.listdir(file_path)
        if len(photos) > 0:
            current_index = (current_index - 1) if current_index >= len(photos) else current_index
            set_pic_src(photos[current_index])
        reset_roller()
    except BaseException as e:
        print(f"Exception {e}")
    

def del_btn_event(e):
    data = e.user_data.__cast__()
    res = data.get('res')
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(del_btn_timer_cb, 100, {'label': label, 'res': res})  # 1000ms 后调用


def init():
    global container, photos, roller, pic_obj, info_obj, del_obj
    photos = os.listdir(file_path)
    css = import_module('pages/album-photo/css')
    
    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)


    header = lv.obj(container)
    header.add_style(css.obj_sty, lv.PART.MAIN)
    header.add_style(css.header_sty, lv.PART.MAIN)
    header.move_foreground()

    back_btn = lv.obj(header)
    back_btn.add_style(css.obj_sty, lv.PART.MAIN)
    back_btn.add_style(css.back_sty, lv.PART.MAIN)
    back_btn.add_event(back_event, lv.EVENT.CLICKED, None)
    back_btn.set_scroll_dir(lv.DIR.NONE)
    back_label = lv.label(back_btn)
    back_label.set_text('返回')
    back_label.add_style(css.back_lab_sty, lv.PART.MAIN)

    roller = lv.obj(header)
    roller.add_style(css.obj_sty, lv.PART.MAIN)
    roller.add_style(css.roller_sty, lv.PART.MAIN)
    roller.set_scroll_dir(lv.DIR.NONE)

    roller_left = lv.img(roller)
    roller_left.set_src(get_img_src('roller-arrow-left-hv'))
    roller_left.add_style(css.roller_left_sty, lv.PART.MAIN)

    roller_middle = lv.img(roller)
    roller_middle.set_src(get_img_src('roller-info'))
    roller_middle.add_style(css.roller_middle_sty, lv.PART.MAIN)

    roller_right = lv.img(roller)
    roller_right.set_src(get_img_src('roller-arrow-right'))
    roller_right.add_style(css.roller_right_sty, lv.PART.MAIN)
    if len(photos) > 0:
        roller_left.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_left, 'type': 'arrow-left'})
        roller_middle.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_middle, 'type': 'info'})
        roller_right.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_right, 'type': 'arrow-right'})
    else:
        reset_roller()


    content = lv.obj(container)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.move_background()

    pic_obj = lv.img(content)
    pic_obj.add_style(css.obj_sty, lv.PART.MAIN)
    pic_obj.add_style(css.pic_obj_sty, lv.PART.MAIN)


    info_obj = lv.obj(container)
    info_obj.add_style(css.obj_sty, lv.PART.MAIN)
    info_obj.add_style(css.info_obj_sty, lv.PART.MAIN)
    info_obj.add_flag(lv.obj.FLAG.HIDDEN)

    info_header = lv.obj(info_obj)
    info_header.add_style(css.obj_sty, lv.PART.MAIN)
    info_header.add_style(css.info_header_sty, lv.PART.MAIN)
    info_header.set_scroll_dir(lv.DIR.NONE)
    info_header_lab = lv.label(info_header)
    info_header_lab.set_text('详细信息')
    info_header_lab.add_style(css.info_header_lab_sty, lv.PART.MAIN)

    info_con = lv.obj(info_obj)
    info_con.add_style(css.obj_sty, lv.PART.MAIN)
    info_con.add_style(css.info_con_sty, lv.PART.MAIN)
    info_con.set_scroll_dir(lv.DIR.NONE)
    info_con_name = lv.label(info_con)
    info_con_name.set_text('名称             ------')
    info_con_name.set_y(0)
    info_con_name.add_style(css.info_con_lab_sty, lv.PART.MAIN)
    info_con_name.set_long_mode(lv.label.LONG.DOT)
    info_con_date = lv.label(info_con)
    info_con_date.set_y(34)
    info_con_date.set_text('创建日期   ----/--/-- --:--')
    info_con_date.add_style(css.info_con_lab_sty, lv.PART.MAIN)
    info_con_res = lv.label(info_con)
    info_con_res.set_y(68)
    info_con_res.set_text('分辨率        --- x ---')
    info_con_res.add_style(css.info_con_lab_sty, lv.PART.MAIN)
    info_con_size = lv.label(info_con)
    info_con_size.set_y(102)
    info_con_size.set_text('大小             -----')
    info_con_size.add_style(css.info_con_lab_sty, lv.PART.MAIN)


    del_obj = lv.obj(container)
    del_obj.add_style(css.obj_sty, lv.PART.MAIN)
    del_obj.add_style(css.del_obj_sty, lv.PART.MAIN)
    del_obj.add_flag(lv.obj.FLAG.HIDDEN)

    del_con = lv.obj(del_obj)
    del_con.add_style(css.obj_sty, lv.PART.MAIN)
    del_con.add_style(css.del_con_sty, lv.PART.MAIN)

    del_icon = lv.img(del_con)
    del_icon.set_src(get_img_src('del'))
    del_icon.add_style(css.del_icon_sty, lv.PART.MAIN)

    del_lab = lv.label(del_con)
    del_lab.set_text('是否删除该图片？')
    del_lab.add_style(css.del_lab_sty, lv.PART.MAIN)

    del_btn_no = lv.obj(del_obj)
    del_btn_no.add_style(css.obj_sty, lv.PART.MAIN)
    del_btn_no.add_style(css.del_btn_sty, lv.PART.MAIN)
    del_btn_no.set_x(10)
    del_btn_no.add_event(del_btn_event, lv.EVENT.CLICKED, {'res': 0})
    del_btn_no.set_scroll_dir(lv.DIR.NONE)
    del_btn_no_label = lv.label(del_btn_no)
    del_btn_no_label.set_text('否')
    del_btn_no_label.add_style(css.del_btn_lab_sty, lv.PART.MAIN)

    del_btn_yes = lv.obj(del_obj)
    del_btn_yes.add_style(css.obj_sty, lv.PART.MAIN)
    del_btn_yes.add_style(css.del_btn_sty, lv.PART.MAIN)
    del_btn_yes.set_x(444)
    del_btn_yes.add_event(del_btn_event, lv.EVENT.CLICKED, {'res': 1})
    del_btn_yes.set_scroll_dir(lv.DIR.NONE)
    del_btn_yes_label = lv.label(del_btn_yes)
    del_btn_yes_label.set_text('是')
    del_btn_yes_label.add_style(css.del_btn_lab_sty, lv.PART.MAIN)
    
    if len(photos) > 0: set_pic_src(photos[0])
    

    set_key_config({
        'separate_letf_cb': lambda: del_btn_no.send_event(lv.EVENT.CLICKED, None) if del_mask else back_btn.send_event(lv.EVENT.CLICKED, None),
        'roller_letf_cb': lambda: None if del_mask else roller_left.send_event(lv.EVENT.CLICKED, None),
        'roller_middle_cb': lambda: del_btn_yes.send_event(lv.EVENT.CLICKED, None) if del_mask else roller_middle.send_event(lv.EVENT.CLICKED, None),
        'roller_right_cb': lambda: None if del_mask else roller_right.send_event(lv.EVENT.CLICKED, None),
        'long_roller_middle_cb': None if del_mask else lambda: show_del_mask(),
        'group_wrap': False
    })


def destroy():
    global container, roller, pic_obj, info_obj, del_obj
    container.clean()
    roller = None
    pic_obj = None
    info_obj = None
    del_obj = None
    container = None