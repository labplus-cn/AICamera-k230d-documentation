import lvgl as lv
import os
from utils import import_module, change_route, set_key_config, get_img_src

container = None
vid_obj = None
mask_obj = None
file_path = '/data/Camera/Videos/'
videos = []
vid_info = {}
current_index = 0
view_info = False

def back_timer_cb(timer):
    data = timer.user_data.__cast__()
    label = data.get('label')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    change_route('album', destroy)

def back_event(e):
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(back_timer_cb, 100, {'label': label})  # 1000ms 后调用

def roller_timer_cb(timer):
    global current_index
    data = timer.user_data.__cast__()
    dom = data.get('dom')
    type = data.get('type')
    dom.set_src(get_img_src('roller-' + type))
    timer._del()
    if type == 'arrow-left':
        current_index = 0 if current_index <= 0 else (current_index - 1)
    if type == 'arrow-right':
        current_index = (len(videos) - 1) if current_index >= (len(videos) - 1) else (current_index + 1)

    if type == 'info':
        pass
        # view_vid_info()
        # print('信息---', current_index, vid_info)
    else:
        # print('切换---', current_index)
        set_vid_src(videos[current_index])

def roller_event(e):
    global view_info
    if (view_info):
        mask_obj.add_flag(lv.obj.FLAG.HIDDEN)
        view_info = False
        return
    
    data = e.user_data.__cast__()
    dom = data.get('dom')
    type = data.get('type')
    dom.set_src(get_img_src('roller-' + type + '-hv'))
    lv.timer_create(roller_timer_cb, 100, {'dom': dom, 'type': type})  # 1000ms 后调用

def set_vid_src(file):
    data = None
    with open(file_path + file,'rb') as f:
        data = f.read()
    img_src = lv.img_dsc_t({
        'data_size': len(data),
        'data': data
    })
    vid_obj.set_src(img_src)
    vid_obj.update_layout()
    p_w = vid_obj.get_width()
    p_h= vid_obj.get_height()

    # c_w = container.get_width()
    # c_h = container.get_height()
    # if p_w > c_w or p_h > c_h:
    #     print(p_w, p_h, c_w, c_h)
    #     zoom = (c_w / p_w) if (c_w / p_w) <= (c_h / p_h) else (c_h / p_h)
    #     print(zoom, round(p_w / zoom), round(p_h / zoom))
        # vid_obj.set_size(round(p_w / zoom), round(p_h / zoom))
        # vid_obj.set_style_transform_zoom(round(zoom * 256), lv.PART.MAIN)

    vid_info['name'] = file
    vid_info['date'] = '2024/10/15 15:30'
    vid_info['resolution'] = str(p_w) + ' x ' + str(p_h)
    vid_info['size'] = str(round(len(data) / 1024, 2)) + 'KB'

def view_vid_info():
    global view_info
    view_info = True
    mask_obj.clear_flag(lv.obj.FLAG.HIDDEN)
    mask_obj.get_child(1).get_child(0).set_text('名称             ' + vid_info['name'])
    mask_obj.get_child(1).get_child(1).set_text('创建日期   ' + vid_info['date'])
    mask_obj.get_child(1).get_child(2).set_text('分辨率        ' + vid_info['resolution'])
    mask_obj.get_child(1).get_child(3).set_text('大小             ' + vid_info['size'])


def init():
    global container, videos, vid_obj, mask_obj
    videos = os.listdir(file_path)
    css = import_module('pages/album-video/css')

    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)


    header = lv.obj(container)
    header.add_style(css.obj_sty, lv.PART.MAIN)
    header.add_style(css.header_sty, lv.PART.MAIN)

    back_btn = lv.obj(header)
    back_btn.add_style(css.obj_sty, lv.PART.MAIN)
    back_btn.add_style(css.back_sty, lv.PART.MAIN)
    back_btn.add_event(back_event, lv.EVENT.CLICKED, None)
    back_btn.set_scroll_dir(lv.DIR.NONE)
    back_label = lv.label(back_btn)
    back_label.set_text('返回')
    back_label.add_style(css.back_lab_sty, lv.PART.MAIN)

    roller = lv.obj(header)
    roller.add_style(css.obj_sty, lv.PART.MAIN)
    roller.add_style(css.roller_sty, lv.PART.MAIN)
    roller.set_scroll_dir(lv.DIR.NONE)

    roller_left = lv.img(roller)
    roller_left.set_src(get_img_src('roller-arrow-left'))
    roller_left.add_style(css.roller_left_sty, lv.PART.MAIN)
    roller_left.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_left, 'type': 'arrow-left'})

    roller_middle = lv.img(roller)
    roller_middle.set_src(get_img_src('roller-info'))
    roller_middle.add_style(css.roller_middle_sty, lv.PART.MAIN)
    roller_middle.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_middle, 'type': 'info'})

    roller_right = lv.img(roller)
    roller_right.set_src(get_img_src('roller-arrow-right'))
    roller_right.add_style(css.roller_right_sty, lv.PART.MAIN)
    roller_right.add_event(roller_event, lv.EVENT.CLICKED, {'dom': roller_right, 'type': 'arrow-right'})


    content = lv.obj(container)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.move_background()

    vid_obj = lv.img(content)
    vid_obj.add_style(css.obj_sty, lv.PART.MAIN)
    vid_obj.add_style(css.vid_obj_sty, lv.PART.MAIN)


    mask_obj = lv.obj(container)
    mask_obj.add_style(css.obj_sty, lv.PART.MAIN)
    mask_obj.add_style(css.mask_obj_sty, lv.PART.MAIN)
    mask_obj.add_flag(lv.obj.FLAG.HIDDEN)

    mask_header = lv.obj(mask_obj)
    mask_header.add_style(css.obj_sty, lv.PART.MAIN)
    mask_header.add_style(css.mask_header_sty, lv.PART.MAIN)
    mask_header.set_scroll_dir(lv.DIR.NONE)
    mask_header_lab = lv.label(mask_header)
    mask_header_lab.set_text('详细信息')
    mask_header_lab.add_style(css.mask_header_lab_sty, lv.PART.MAIN)

    mask_con = lv.obj(mask_obj)
    mask_con.add_style(css.obj_sty, lv.PART.MAIN)
    mask_con.add_style(css.mask_con_sty, lv.PART.MAIN)
    mask_con.set_scroll_dir(lv.DIR.NONE)
    mask_con_name = lv.label(mask_con)
    mask_con_name.set_text('名称             apple_92112ff341.png')
    mask_con_name.set_y(0)
    mask_con_name.add_style(css.mask_con_lab_sty, lv.PART.MAIN)
    mask_con_name.set_long_mode(lv.label.LONG.DOT)
    mask_con_name.update_layout()
    mask_con_date = lv.label(mask_con)
    mask_con_date.set_y(34)
    mask_con_date.set_text('创建日期   2024/10/15 15:30')
    mask_con_date.add_style(css.mask_con_lab_sty, lv.PART.MAIN)
    mask_con_res = lv.label(mask_con)
    mask_con_res.set_y(68)
    mask_con_res.set_text('分辨率        285 x 538')
    mask_con_res.add_style(css.mask_con_lab_sty, lv.PART.MAIN)
    mask_con_size = lv.label(mask_con)
    mask_con_size.set_y(102)
    mask_con_size.set_text('大小             8.99KB')
    mask_con_size.add_style(css.mask_con_lab_sty, lv.PART.MAIN)
    
    if len(videos) > 0: vid_obj.set_src(videos[0])
    

    set_key_config({
        'separate_letf_cb': lambda: back_btn.send_event(lv.EVENT.CLICKED, None),
        'roller_letf_cb': lambda: roller_left.send_event(lv.EVENT.CLICKED, None),
        'roller_middle_cb': lambda: roller_middle.send_event(lv.EVENT.CLICKED, None),
        'roller_right_cb': lambda: roller_right.send_event(lv.EVENT.CLICKED, None),
        'group_wrap': False
    })


def destroy():
    global container
    container.clean()
    container = None