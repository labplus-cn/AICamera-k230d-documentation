import lvgl as lv
from utils import FONT_SIZE_24, FONT_SIZE_32

obj_sty = lv.style_t()
obj_sty.init()
obj_sty.set_pad_all(0)
obj_sty.set_radius(0)
obj_sty.set_border_width(0)

container_sty = lv.style_t()
container_sty.init()
container_sty.set_size(lv.pct(100), lv.pct(100))


header_sty = lv.style_t()
header_sty.init()
header_sty.set_size(lv.pct(100), 70)
header_sty.set_bg_color(lv.color_hex(0x000000))
header_sty.set_bg_opa(102)

back_sty = lv.style_t()
back_sty.init()
back_sty.set_size(90, 50)
back_sty.set_x(10)
back_sty.set_y(10)
back_sty.set_bg_color(lv.color_hex(0x333333))
back_sty.set_radius(25)
back_sty.set_border_width(0)
back_sty.set_pad_all(0)

back_lab_sty = lv.style_t()
back_lab_sty.init()
back_lab_sty.set_text_font(FONT_SIZE_32)
back_lab_sty.set_text_color(lv.color_hex(0xFFFFFF))
back_lab_sty.set_align(lv.ALIGN.CENTER)

title_sty = lv.style_t()
title_sty.init()
title_sty.set_text_font(FONT_SIZE_32)
title_sty.set_text_color(lv.color_hex(0xFFFFFF))
title_sty.set_align(lv.ALIGN.CENTER)

roller_sty = lv.style_t()
roller_sty.init()
roller_sty.set_size(88, 50)
roller_sty.set_x(446)
roller_sty.set_y(10)
roller_sty.set_bg_color(lv.color_hex(0x333333))
roller_sty.set_radius(25)
roller_sty.set_border_width(0)
roller_sty.set_pad_all(0)

roller_left_sty = lv.style_t()
roller_left_sty.init()
roller_left_sty.set_size(12, 15)
roller_left_sty.set_x(10)
roller_left_sty.set_y(18)

roller_middle_sty = lv.style_t()
roller_middle_sty.init()
roller_middle_sty.set_size(26, 26)
roller_middle_sty.set_x(32)
roller_middle_sty.set_y(12)

roller_right_sty = lv.style_t()
roller_right_sty.init()
roller_right_sty.set_size(12, 15)
roller_right_sty.set_x(68)
roller_right_sty.set_y(18)


content_sty = lv.style_t()
content_sty.init()
content_sty.set_size(lv.pct(100), lv.pct(100))
content_sty.set_bg_color(lv.color_hex(0x333333))

vid_obj_sty = lv.style_t()
vid_obj_sty.init()
vid_obj_sty.set_align(lv.ALIGN.CENTER)


mask_obj_sty = lv.style_t()
mask_obj_sty.init()
mask_obj_sty.set_size(380, 205)
mask_obj_sty.set_x(82)
mask_obj_sty.set_y(104)

mask_header_sty = lv.style_t()
mask_header_sty.init()
mask_header_sty.set_size(lv.pct(100), 49)
mask_header_sty.set_bg_color(lv.color_hex(0xCBE8F6))

mask_header_lab_sty = lv.style_t()
mask_header_lab_sty.init()
mask_header_lab_sty.set_text_font(FONT_SIZE_32)
mask_header_lab_sty.set_text_color(lv.color_hex(0x26A0DA))
mask_header_lab_sty.set_align(lv.ALIGN.CENTER)

mask_con_sty = lv.style_t()
mask_con_sty.init()
mask_con_sty.set_y(49)
mask_con_sty.set_size(lv.pct(100), 156)
mask_con_sty.set_bg_color(lv.color_hex(0xFFFFFF))
mask_con_sty.set_pad_hor(12)
mask_con_sty.set_pad_ver(5)

mask_con_lab_sty = lv.style_t()
mask_con_lab_sty.init()
mask_con_lab_sty.set_size(lv.pct(100), 34)
mask_con_lab_sty.set_text_font(FONT_SIZE_24)
mask_con_lab_sty.set_text_color(lv.color_hex(0x333333))