import lvgl as lv
from utils import FONT_SIZE_24, FONT_SIZE_32

obj_sty = lv.style_t()
obj_sty.init()
obj_sty.set_pad_all(0)
obj_sty.set_radius(0)
obj_sty.set_border_width(0)

container_sty = lv.style_t()
container_sty.init()
container_sty.set_size(lv.pct(100), lv.pct(100))


header_sty = lv.style_t()
header_sty.init()
header_sty.set_size(lv.pct(100), 70)
header_sty.set_bg_color(lv.color_hex(0x000000))
header_sty.set_bg_opa(102)

back_sty = lv.style_t()
back_sty.init()
back_sty.set_size(90, 50)
back_sty.set_x(10)
back_sty.set_y(10)
back_sty.set_bg_color(lv.color_hex(0x333333))
back_sty.set_radius(25)
back_sty.set_border_width(0)
back_sty.set_pad_all(0)

back_lab_sty = lv.style_t()
back_lab_sty.init()
back_lab_sty.set_text_font(FONT_SIZE_32)
back_lab_sty.set_text_color(lv.color_hex(0xFFFFFF))
back_lab_sty.set_align(lv.ALIGN.CENTER)


content_sty = lv.style_t()
content_sty.init()
content_sty.set_size(lv.pct(100), lv.pct(100))
content_sty.set_bg_color(lv.color_hex(0x333333))
content_sty.set_pad_hor(25)
content_sty.set_pad_top(90)
content_sty.set_pad_bottom(20)

con_lab_sty = lv.style_t()
con_lab_sty.init()
con_lab_sty.set_size(lv.pct(100), 34)
con_lab_sty.set_text_font(FONT_SIZE_24)
con_lab_sty.set_text_color(lv.color_hex(0xFFFFFF))