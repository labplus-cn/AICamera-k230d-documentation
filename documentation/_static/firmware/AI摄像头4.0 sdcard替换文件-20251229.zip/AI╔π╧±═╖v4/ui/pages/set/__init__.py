import lvgl as lv
import uos, gc, machine
from utils import import_module, change_route, set_key_config

container = None
refresh_flag = False

def back_timer_cb(timer):
    data = timer.user_data.__cast__()
    label = data.get('label')
    label.set_style_text_color(lv.color_hex(0xFFFFFF), lv.PART.MAIN)
    timer._del()
    change_route('home', destroy)

def back_event(e):
    dom = lv.obj.__cast__(e.get_target())
    label = dom.get_child(0)
    label.set_style_text_color(lv.color_hex(0x999999), lv.PART.MAIN)
    lv.timer_create(back_timer_cb, 100, {'label': label})  # 1000ms 后调用

def get_memory_usage():
    gc.collect()  # 先执行垃圾回收，确保统计准确
    total = gc.mem_alloc() + gc.mem_free()  # 总堆内存
    used = gc.mem_alloc()  # 已使用内存
    usage = (used / total) * 100 if total > 0 else 0  # 计算使用率（百分比）
    return usage

def refresh_timer_cb(timer):
    if refresh_flag:
        data = timer.user_data.__cast__()
        cpu_temp_dom = data.get('cpu_temp_dom')
        cpu_usage_dom = data.get('cpu_usage_dom')
        ram_usage_dom = data.get('ram_usage_dom')
        cpu_temp = machine.temperature()
        cpu_usage = uos.cpu_usage()
        ram_usage = get_memory_usage()

        cpu_temp_dom.set_text('CPU Temp: ' + str(round(cpu_temp, 2)) + '\'C')
        cpu_usage_dom.set_text('CPU Usage: ' + str(cpu_usage) + '%')
        ram_usage_dom.set_text('RAM Usage: ' + str(round(ram_usage, 2)) + '%')
    else:
        timer._del()

def init():
    global container, refresh_flag
    css = import_module('pages/set/css')
    refresh_flag = True

    uname = uos.uname()
    cpu_temp = machine.temperature()
    cpu_usage = uos.cpu_usage()
    ram_usage = get_memory_usage()

    container = lv.obj()
    container.add_style(css.obj_sty, lv.PART.MAIN)
    container.add_style(css.container_sty, lv.PART.MAIN)

    header = lv.obj(container)
    header.add_style(css.obj_sty, lv.PART.MAIN)
    header.add_style(css.header_sty, lv.PART.MAIN)

    back_btn = lv.obj(header)
    back_btn.add_style(css.obj_sty, lv.PART.MAIN)
    back_btn.add_style(css.back_sty, lv.PART.MAIN)
    back_btn.add_event(back_event, lv.EVENT.CLICKED, None)
    back_btn.set_scroll_dir(lv.DIR.NONE)

    back_label = lv.label(back_btn)
    back_label.set_text('返回')
    back_label.add_style(css.back_lab_sty, lv.PART.MAIN)

    content = lv.obj(container)
    content.add_style(css.obj_sty, lv.PART.MAIN)
    content.add_style(css.content_sty, lv.PART.MAIN)
    content.set_scroll_dir(lv.DIR.NONE)
    content.move_background()

    con_lab1 = lv.label(content)
    con_lab1.set_y(0)
    con_lab1.set_text('名称: AI Camera')
    con_lab1.add_style(css.con_lab_sty, lv.PART.MAIN)

    con_lab2 = lv.label(content)
    con_lab2.set_y(34)
    con_lab2.set_text('CPU Temp: ' + str(round(cpu_temp, 2)) + '\'C')
    con_lab2.add_style(css.con_lab_sty, lv.PART.MAIN)

    con_lab3 = lv.label(content)
    con_lab3.set_y(68)
    con_lab3.set_text('CPU Usage: ' + str(cpu_usage) + '%')
    con_lab3.add_style(css.con_lab_sty, lv.PART.MAIN)

    con_lab4 = lv.label(content)
    con_lab4.set_y(102)
    con_lab4.set_text('RAM Usage: ' + str(round(ram_usage, 2)) + '%')
    con_lab4.add_style(css.con_lab_sty, lv.PART.MAIN)

    con_lab5 = lv.label(content)
    con_lab5.set_y(136)
    con_lab5.set_text('FLASH: 8GB EMMC')
    con_lab5.add_style(css.con_lab_sty, lv.PART.MAIN)

    con_lab6 = lv.label(content)
    con_lab6.set_y(204)
    con_lab6.set_text('版本号：' + uname[3])
    con_lab6.add_style(css.con_lab_sty, lv.PART.MAIN)
    con_lab6.set_height(68)

    lv.timer_create(refresh_timer_cb, 1000, {'cpu_temp_dom': con_lab2, 'cpu_usage_dom': con_lab3, 'ram_usage_dom': con_lab4})

    set_key_config({ 'separate_letf_cb': lambda: back_btn.send_event(lv.EVENT.CLICKED, None) })


def destroy():
    global container, refresh_flag
    refresh_flag = False
    container.clean()
    container = None