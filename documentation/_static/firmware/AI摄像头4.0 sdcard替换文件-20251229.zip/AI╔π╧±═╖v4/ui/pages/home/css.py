import lvgl as lv
from utils import FONT_SIZE_32

obj_sty = lv.style_t()
obj_sty.init()
obj_sty.set_pad_all(0)
obj_sty.set_radius(0)
obj_sty.set_border_width(0)

container_sty = lv.style_t()
container_sty.init()
container_sty.set_size(lv.pct(100), lv.pct(100))

content_sty = lv.style_t()
content_sty.init()
content_sty.set_size(lv.pct(100), lv.pct(100))
content_sty.set_bg_color(lv.color_hex(0x000000))
content_sty.set_pad_gap(0)

item_sty = lv.style_t()
item_sty.init()
item_sty.set_size(500, 130)
item_sty.set_bg_color(lv.color_hex(0x666666))
item_sty.set_pad_all(8)
item_sty.set_margin_bottom(12)
item_sty.set_radius(66)

item_active_sty = lv.style_t()
item_active_sty.init()
item_active_sty.set_border_width(0)
item_active_sty.set_border_opa(0)
item_active_sty.set_outline_width(0)
item_active_sty.set_outline_opa(0)
item_active_sty.set_outline_opa(0)

item_clicked_sty = lv.style_t()
item_clicked_sty.init()
item_clicked_sty.set_bg_color(lv.color_hex(0xFFFFFF))

item_icon_sty = lv.style_t()
item_icon_sty.init()
item_icon_sty.set_size(114, 114)
item_icon_sty.set_text_align(lv.TEXT_ALIGN.CENTER)

item_label_sty = lv.style_t()
item_label_sty.init()
item_label_sty.set_x(152)
item_label_sty.set_y(38)
item_label_sty.set_text_font(FONT_SIZE_32)
item_label_sty.set_text_color(lv.color_hex(0xFFFFFF))
item_label_sty.set_text_align(lv.TEXT_ALIGN.CENTER)