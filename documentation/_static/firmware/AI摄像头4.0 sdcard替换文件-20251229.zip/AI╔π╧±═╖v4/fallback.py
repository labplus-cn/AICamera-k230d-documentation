print('bad main')

import time, os, gc
from media.display import *
from media.media import *
from machine import FPIOA, Pin, reset

fpioa = FPIOA()
fpioa.set_function(12, FPIOA.GPIO12) # 注册按键功能
KEY = Pin(12, Pin.IN, Pin.PULL_UP) # 拨轮中键

bad_main_path = '/sdcard/bad_main.py'
main_path = '/sdcard/main.py'

def has_file(_path):
    try:
        os.stat(_path)
        return True
    except OSError:
        return False

def main():
    # create image for drawing
    img = image.Image("/sdcard/libs/Images/fallback.png", copy_to_fb=True)
    # use lcd as display output
    Display.init(Display.ST7701, width = 544, height = 368, osd_num = 1, to_ide = True)
    # init media manager
    MediaManager.init()
    try:
        img = img.to_rgb888()
        Display.show_image(img)
        while True:
            if KEY.value() == 0:
                time.sleep_ms(50)
                if KEY.value() == 0:
                    print('开始修复...')
                    break
            # print("Free memory:", gc.mem_free(), "bytes")
            time.sleep(0.2)
        if has_file(bad_main_path): os.remove(bad_main_path)
        with open(main_path, 'w') as f:
            f.write('import ui')
        os.exitpoint()
    except KeyboardInterrupt as e:
        print("user stop: ", e)
    except BaseException as e:
        print(f"Exception {e}")

    # deinit display
    Display.deinit()
    os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    time.sleep_ms(100)
    # release media buffer
    MediaManager.deinit()
    print('修复完成，正在重启...')
    # reset
    time.sleep(0.5)
    reset()

os.exitpoint(os.EXITPOINT_ENABLE)
main()
