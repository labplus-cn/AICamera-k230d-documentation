import time, os, gc, sys, math
from media.sensor import *
from media.display import *
from media.media import *

class LinearRegressionFast:
    def __init__(self,
                 line_color="black", # 黑线和白线是"black" 或 "white"
                 detect_intersections=True, 
                 detect_zebra=True
                 ):
        base_sample_step = 12
        smooth_alpha = 0.6
        border_margin_ratio = 0.06
        target_fps = 20.0
        self.DETECT_WIDTH = 544
        self.DETECT_HEIGHT = 368
        self.LINE_COLOR = line_color
        self.detect_intersections = detect_intersections
        self.detect_ZEBRA = detect_zebra
        self.BASE_SAMPLE_STEP = base_sample_step
        self.SMOOTH_ALPHA = smooth_alpha
        self.BORDER_MARGIN_RATIO = border_margin_ratio
        self.TARGET_FPS = target_fps

        self.RECT_THRESHOLD = 2000
        self.RECT_MARGIN = 10
        self.MIN_ZEBRA_RECTS = 3
        self.MIN_RECT_ASPECT_RATIO = 3.0
        self.MIN_RECT_WIDTH_RATIO = 0.1

        self._last_mean = None
        self.sensor = None
        self.SAMPLE_COORDS = None
        self.SAMPLE_STEP = self.BASE_SAMPLE_STEP
        self.SAMPLE_COORDS = self.build_sample_coords(self.DETECT_WIDTH, self.DETECT_HEIGHT, self.SAMPLE_STEP, self.BORDER_MARGIN_RATIO)
    
        self._last_mean = None
        self.frame_idx = 0

        if not self.SAMPLE_COORDS:
            self.SAMPLE_COORDS = self.build_sample_coords(self.DETECT_WIDTH, self.DETECT_HEIGHT, self.SAMPLE_STEP, self.BORDER_MARGIN_RATIO)

        self.fps = time.clock()

    # def camera_init(self):
    #     self.sensor = Sensor(width=self.DETECT_WIDTH, height=self.DETECT_HEIGHT)
    #     self.sensor.reset()
    #     self.sensor.set_framesize(width=self.DETECT_WIDTH, height=self.DETECT_HEIGHT)
    #     self.sensor.set_pixformat(Sensor.GRAYSCALE)
    #     Display.init(Display.VIRT, width=self.DETECT_WIDTH, height=self.DETECT_HEIGHT, fps=100, to_ide=True)
    #     MediaManager.init()
    #     self.sensor.run()
    #     self.SAMPLE_COORDS = self.build_sample_coords(self.DETECT_WIDTH, self.DETECT_HEIGHT, self.SAMPLE_STEP, self.BORDER_MARGIN_RATIO)

    def build_sample_coords(self, w, h, step, border_margin_ratio):
        # print(w, h, step, border_margin_ratio)
        margin_x = max(1, int(w * border_margin_ratio))
        margin_y = max(1, int(h * border_margin_ratio))
        coords = []
        y_start = margin_y + step // 2
        x_start = margin_x + step // 2
        for y in range(y_start, h - margin_y, step):
            for x in range(x_start, w - margin_x, step):
                coords.append((x, y))
        return coords

    def estimate_mean_and_std_from_coords(self, img, coords):
        s = 0
        s2 = 0
        cnt = 0
        for (x, y) in coords:
            p = img.get_pixel(x, y)
            s += p
            s2 += p * p
            cnt += 1
        if cnt == 0:
            return (0, 0)
        mean = s / cnt
        var = max(0.0, s2 / cnt - mean * mean)
        std = var ** 0.5
        return (int(mean), int(std))

    def compute_threshold_from_mean(self, mean, std, line_color="black"):
        offset_by_mean = int(max(12, mean * 0.12))
        offset_by_std = int(max(8, std * 1.2))
        offset = max(offset_by_mean, offset_by_std)
        if line_color == "black":
            lo = 0
            hi = max(30, mean - offset)
        else:
            lo = min(225, mean + offset)
            hi = 255
        lo = max(0, min(255, lo))
        hi = max(0, min(255, hi))
        if hi <= lo:
            if line_color == "black":
                hi = max(lo + 10, min(200, mean))
            else:
                lo = min(hi - 10, max(50, mean))
        return (lo, hi)

    def fast_clear_border_on_image(self, img, margin, fill_value=0):
        w = img.width()
        h = img.height()
        try:
            img.draw_rectangle(0, 0, w, margin, color=fill_value, fill=True)
            img.draw_rectangle(0, h - margin, w, margin, color=fill_value, fill=True)
            img.draw_rectangle(0, 0, margin, h, color=fill_value, fill=True)
            img.draw_rectangle(w - margin, 0, margin, h, color=fill_value, fill=True)
        except Exception:
            step = max(2, self.SAMPLE_STEP // 2)
            for y in range(0, h, step):
                for x in range(0, margin, step):
                    img.set_pixel(x, y, fill_value)
                for x in range(w - margin, w, step):
                    img.set_pixel(x, y, fill_value)
            for x in range(0, w, step):
                for y in range(0, margin, step):
                    img.set_pixel(x, y, fill_value)
                for y in range(h - margin, h, step):
                    img.set_pixel(x, y, fill_value)

    # def detect_intersections_with_find_lines(self, bin_img):
    #     lines = bin_img.find_lines(threshold=1000, theta_margin=15, rho_margin=20)
    #     if not lines or len(lines) < 2:
    #         return False

    #     w, h = bin_img.width(), bin_img.height()

    #     horizontals = []
    #     verticals = []
    #     for l in lines:
    #         angle = l.theta()
    #         length = l.length()
    #         if 80 <= angle <= 100 and length > w // 3:
    #             horizontals.append(l)

    #         elif (angle <= 10 or angle >= 170) and length > h // 4:
    #             verticals.append(l)

    #     if not horizontals or not verticals:
    #         return False

    #     for hl in horizontals:
    #         for vl in verticals:
    #             hx = (hl.x1() + hl.x2()) // 2
    #             hy = (hl.y1() + hl.y2()) // 2
    #             vx = (vl.x1() + vl.x2()) // 2
    #             vy = (vl.y1() + vl.y2()) // 2
    #             cx, cy = (hx + vx) // 2, (hy + vy) // 2
    #             if (w // 3 < cx < 2 * w // 3) and (h // 2 < cy < int(h * 0.85)):
    #                 return True
    #     return False
    def detect_intersections_with_find_lines(self, bin_img):
        lines = bin_img.find_lines(threshold=800, theta_margin=20, rho_margin=20)
        if not lines or len(lines) < 2:
            return False

        w, h = bin_img.width(), bin_img.height()

        for i in range(len(lines)):
            for j in range(i + 1, len(lines)):
                l1, l2 = lines[i], lines[j]
                angle_diff = abs(l1.theta() - l2.theta())
                if angle_diff > 90:
                    angle_diff = 180 - angle_diff

                if 70 <= angle_diff <= 110:
                    if l1.length() > l2.length():
                        main_line, cross_line = l1, l2
                    else:
                        main_line, cross_line = l2, l1

                    if cross_line.length() > main_line.length() * 0.7:
                        continue

                    x1, y1 = (l1.x1() + l1.x2()) // 2, (l1.y1() + l1.y2()) // 2
                    x2, y2 = (l2.x1() + l2.x2()) // 2, (l2.y1() + l2.y2()) // 2
                    cx, cy = (x1 + x2) // 2, (y1 + y2) // 2

                    if abs(cx - w // 2) < w // 4 and h // 4 < cy < h // 2:
                        return True
                   
        

    def detect_zebra_with_rects(self, bin_img, threshold=None, margin=None):
        if threshold is None:
            threshold = self.RECT_THRESHOLD
        if margin is None:
            margin = self.RECT_MARGIN
        try:
            rects = bin_img.find_rects(threshold=threshold, margin=margin)
        except Exception:
            return False

        if not rects:
            return False

        h_img = bin_img.height()
        w_img = bin_img.width()
        candidates = []

        for r in rects:
            try:
                x, y, w, h = r.rect()
            except Exception:
                try:
                    x, y, w, h = r.x(), r.y(), r.w(), r.h()
                except Exception:
                    continue

            if y < h_img // 2:
                continue

            if h == 0:
                continue
            aspect = float(w) / float(h)
            if aspect >= self.MIN_RECT_ASPECT_RATIO and (w >= w_img * self.MIN_RECT_WIDTH_RATIO):
                candidates.append((x, y, w, h))

        return len(candidates) >= self.MIN_ZEBRA_RECTS
    

    def detect_zebra_with_blobs(self,
                            bin_img,
                            min_stripes=3,
                            min_width=6,
                            min_height=6,
                            min_horizontal_span_frac=0.35,
                            max_gap_cv=1.2,
                            max_width_cv=1.0):
        blobs = bin_img.find_blobs([(255, 255)], merge=True)

        cand = []
        for b in blobs:
            if b.w() >= min_width and b.h() >= min_height:
                cand.append(b)

        if len(cand) < min_stripes:
            return False

        cand_sorted = sorted(cand, key=lambda bb: bb.cy())
        centers_y = [b.cy() for b in cand_sorted]
        widths = [b.w() for b in cand_sorted]
        heights = [b.h() for b in cand_sorted]

        leftmost = min(b.x() for b in cand_sorted)
        rightmost = max(b.x() + b.w() for b in cand_sorted)
        horizontal_span = rightmost - leftmost
        if horizontal_span < bin_img.width() * min_horizontal_span_frac:
            return False

        gaps = [centers_y[i+1] - centers_y[i] for i in range(len(centers_y)-1)]
        if len(gaps) == 0:
            return False
        mean_gap = sum(gaps) / len(gaps)
        var_gap = sum((g - mean_gap) ** 2 for g in gaps) / len(gaps)
        std_gap = var_gap ** 0.5
        gap_cv = std_gap / mean_gap if mean_gap > 0 else float('inf')
        if gap_cv > max_gap_cv:
            return False
        mean_w = sum(widths) / len(widths)
        var_w = sum((w - mean_w) ** 2 for w in widths) / len(widths)
        std_w = var_w ** 0.5
        width_cv = std_w / mean_w if mean_w > 0 else float('inf')
        if width_cv > max_width_cv:
            return False

        return True


    def run(self,img):
        self.fps.tick()
        res = {"cx": None, "cy": None, "angle": None, "is_int": False, "is_zebra": False}
        try:
            # img = self.sensor.snapshot()

            mean, std = self.estimate_mean_and_std_from_coords(img, self.SAMPLE_COORDS)
            if self._last_mean is None:
                smooth_mean = mean
            else:
                smooth_mean = int(self.SMOOTH_ALPHA * self._last_mean + (1.0 - self.SMOOTH_ALPHA) * mean)
            self._last_mean = smooth_mean

            threshold = self.compute_threshold_from_mean(smooth_mean, std, self.LINE_COLOR)
            margin = max(2, int(min(img.width(), img.height()) * self.BORDER_MARGIN_RATIO))
            bin_img = img.binary([threshold])
            self.fast_clear_border_on_image(bin_img, margin, fill_value=0)
            try:
                bin_img.erode(1)
                bin_img.dilate(1)
            except Exception:
                pass

            line = bin_img.get_regression([(255, 255)])
            intersection = False
            ZEBRA = False
            if line:
                img.draw_line(line.line(), color=127)
                angle = math.degrees(math.atan2(line.y2() - line.y1(), line.x2() - line.x1()))
                if angle < 0:
                    angle += 180
                cx = (line.x1() + line.x2()) // 2
                cy = (line.y1() + line.y2()) // 2
                # 检测 T 字路口
                if self.detect_intersections:
                    intersection = self.detect_intersections_with_find_lines(bin_img)
                    if intersection==None:
                        intersection = False
                # 检测斑马线
                if self.detect_ZEBRA:
                    # ZEBRA = self.detect_zebra_with_rects(bin_img)
                    ZEBRA = self.detect_zebra_with_blobs(bin_img)
                res = {"cx": cx, "cy": cy, "angle": round(angle,3), "is_int": intersection, "is_zebra": ZEBRA}
                # print("线中心点:", cx, cy, "倾斜角度：", angle, "是否T字路口：", intersection, "是否斑马线：", ZEBRA)
                # Display.show_image(img)

            # ------------------ FPS 自适应采样 ------------------
            self.frame_idx += 1
            # del img
            # gc.collect()

            current_fps = self.fps.fps()
            # print("fps:", current_fps)
            if current_fps < self.TARGET_FPS and self.SAMPLE_STEP < 40:
                self.SAMPLE_STEP = int(max(1, self.SAMPLE_STEP * 1.25))
                self.SAMPLE_COORDS = self.build_sample_coords(self.DETECT_WIDTH, self.DETECT_HEIGHT, self.SAMPLE_STEP, self.BORDER_MARGIN_RATIO)
            elif current_fps > self.TARGET_FPS * 1.5 and self.SAMPLE_STEP > self.BASE_SAMPLE_STEP:
                self.SAMPLE_STEP = max(self.BASE_SAMPLE_STEP, int(self.SAMPLE_STEP * 0.9))
                self.SAMPLE_COORDS = self.build_sample_coords(self.DETECT_WIDTH, self.DETECT_HEIGHT, self.SAMPLE_STEP, self.BORDER_MARGIN_RATIO)
            return res
        except Exception as e:
            print(e)

# if __name__ == "__main__":
#     lr = LinearRegressionFast(line_color="white", detect_intersections=True, detect_zebra=True)

#     while True:
#         lr.run()
