from libs.PipeLine import ScopedTiming
from libs.AIBase import AIBase
from libs.AI2D import Ai2d
from media.media import *
# from time import *
import nncase_runtime as nn
import ulab.numpy as np
import gc
import sys
import aidemo
import math

# COCO-17关键点索引定义
NOSE = 0
LEFT_SHOULDER = 5
RIGHT_SHOULDER = 6
LEFT_ELBOW = 7
RIGHT_ELBOW = 8
LEFT_WRIST = 9
RIGHT_WRIST = 10
LEFT_HIP = 11
RIGHT_HIP = 12
LEFT_KNEE = 13
RIGHT_KNEE = 14
LEFT_ANKLE = 15
RIGHT_ANKLE = 16

rgb888p_size = [640, 360]
display_size = [544, 368]

# 模拟数据：正常站立时的基准高度（需根据实际校准）
standing_heights = {
    "head": 1.7,  # 单位：米（假设）
    "hip": 0.9
}

# 阈值设置
thresholds = {
    "torso_angle": 50,  # 躯干倾斜角阈值（度）
}

def calculate_angle(a, b, c):
    """通过向量叉积与点积计算三点夹角（单位：度）"""
    ba = a - b  # 向量 B→A
    bc = c - b  # 向量 B→C
    
    # 计算模长
    norm_ba = np.linalg.norm(ba)
    norm_bc = np.linalg.norm(bc)
    if norm_ba == 0 or norm_bc == 0:
        return 0.0  # 避免零向量导致除零错误
    
    # 计算点积与叉积
    dot_product = np.dot(ba, bc)
    cross_product = ba[0] * bc[1] - ba[1] * bc[0]  # 二维叉积
    
    # 计算正余弦值
    cos_theta = dot_product / (norm_ba * norm_bc)
    sin_theta = abs(cross_product) / (norm_ba * norm_bc)  # 取绝对值确保非负
    
    # 使用 arctan2 计算角度（直接得到 0~180 度范围）
    angle_rad = np.arctan2(sin_theta, cos_theta)
    return np.degrees(angle_rad)

def calculate_vector(p1, p2):
    """计算三维向量差 (p2 - p1)"""
    return (
        p2[0] - p1[0],
        p2[1] - p1[1],
        p2[2] - p1[2]
    )

def vector_length(vec):
    """计算三维向量模长"""
    return math.sqrt(vec[0]**2 + vec[1]**2 + vec[2]**2)


def calculate_height(keypoints):
    """ 计算人体骨骼模型的身高 """
    head_z = keypoints[NOSE][1]  # 头顶的 y 坐标
    foot_z = min(keypoints[LEFT_ANKLE][1], keypoints[RIGHT_ANKLE][1])  # 取最低的脚踝点
    height = math.fabs(head_z - foot_z)  # 计算身高
    return height

def calculate_torso_angle(keypoints):
    """
    计算躯干与垂直轴的夹角（三维空间）
    :param keypoints: 包含17个关键点(x,y,z)的列表
    :return: 角度（度）
    """
    # 计算髋部中点
    left_hip = keypoints[LEFT_HIP]
    right_hip = keypoints[RIGHT_HIP]
    hip_center = (
        (left_hip[0] + right_hip[0]) / 2,
        (left_hip[1] + right_hip[1]) / 2,
        (left_hip[2] + right_hip[2]) / 2
    )
    
    # 计算肩部中点
    left_shoulder = keypoints[LEFT_SHOULDER]
    right_shoulder = keypoints[RIGHT_SHOULDER]
    shoulder_center = (
        (left_shoulder[0] + right_shoulder[0]) / 2,
        (left_shoulder[1] + right_shoulder[1]) / 2,
        (left_shoulder[2] + right_shoulder[2]) / 2
    )
    
    # 躯干向量（从髋部到肩部）
    torso_vec = calculate_vector(hip_center, shoulder_center)
    
    # 垂直向量（假设y轴为垂直方向）
    vertical_vec = (0, -1, 0)
    
    # 计算点积
    dot_product = (
        torso_vec[0] * vertical_vec[0] +
        torso_vec[1] * vertical_vec[1] +
        torso_vec[2] * vertical_vec[2]
    )
    
    # 计算模长
    torso_len = vector_length(torso_vec)
    vertical_len = vector_length(vertical_vec)
    
    # 计算角度
    if torso_len == 0:
        return 0.0
    cos_theta = dot_product / (torso_len * vertical_len)
    return math.degrees(math.acos(max(min(cos_theta, 1.0), -1.0)))


def is_arm_raised(shoulder, elbow, wrist):
    """判断手臂是否伸直且手腕高于肩膀"""
    angle = calculate_angle(shoulder, elbow, wrist)
    return angle > 150 and wrist[1] < shoulder[1]

def is_leg_straight(hip, knee, ankle):
    """判断腿是否伸直"""
    angle = calculate_angle(hip, knee, ankle)
    return angle > 150

def is_leg_bent(hip, knee, ankle):
    """判断腿是否弯曲"""
    angle = calculate_angle(hip, knee, ankle)
    return angle < 130

def is_arm_forward(shoulder, elbow, wrist):
    """判断手臂是否向前伸直"""
    angle = calculate_angle(shoulder, elbow, wrist)
    horizontal_forward = math.fabs(wrist[0] - shoulder[0]) > 40  # 往右伸，数值根据图片定调
    # print('is_arm_forward:{},{}',angle,math.fabs(wrist[0] - shoulder[0]))
    return angle > 160 and horizontal_forward


def is_torso_leaning_forward(nose, shoulder_center):
    """ 判断上身是否前倾"""
    v = shoulder_center - nose
    # angle = np.degrees(np.arccos(np.clip(v[1] / (np.linalg.norm(v) + 1e-6), -1.0, 1.0)))
    angle = np.degrees(np.arctan2(v[0], v[1]))  # 注意：x, y 颠倒是为了与 y 轴夹角
    # print('is_torso_leaning_forward:{}',angle)

    return 45 < angle < 120


def detect_fall(keypoints, standing_heights, angle_threshold=50):
    """
    跌倒检测
    :param keypoints: 包含17个关键点(x,y,z)的列表
    :param standing_heights: 正常站立时的基准高度字典 {'head': 1.7, 'hip': 0.9}
    :param angle_threshold: 躯干倾斜角度阈值（默认50度）
    """
    # 条件1：躯干倾斜角度过大
    angle = calculate_torso_angle(keypoints)
    # print('angle:',angle)
    
    # 条件2：关键点高度异常
    nose_y = keypoints[NOSE][1]
    hip_avg_y = (keypoints[LEFT_HIP][1] + keypoints[RIGHT_HIP][1]) / 2
    # height_alert = (nose_y < standing_heights["head"] * 0.6 or hip_avg_y < standing_heights["hip"] * 0.6)
    height_alert = math.fabs(nose_y - hip_avg_y) < 75
    
    # print('nose_y:',nose_y)
    # print('hip_avg_y:',hip_avg_y)
    # print('height_alert:',height_alert)
    
    # 条件3：无下肢支撑（脚踝在髋部上方）
    ankle_support = (
        keypoints[LEFT_ANKLE][1] < keypoints[LEFT_HIP][1] and keypoints[RIGHT_ANKLE][1] < keypoints[RIGHT_HIP][1]
    )
    
    # print('ankle_support:',ankle_support)
    
    # 综合判断
    return (0 if (angle > angle_threshold and height_alert) or (height_alert and ankle_support) else 1)



# 自定义人体关键点检测类
class PersonKeyPointApp(AIBase):
    def __init__(self,kmodel_path,model_input_size,confidence_threshold=0.2,nms_threshold=0.5,rgb888p_size=[1280,720],display_size=[1920,1080],debug_mode=0):
        super().__init__(kmodel_path,model_input_size,rgb888p_size,debug_mode)
        self.kmodel_path=kmodel_path
        # 模型输入分辨率
        self.model_input_size=model_input_size
        # 置信度阈值设置
        self.confidence_threshold=confidence_threshold
        # nms阈值设置
        self.nms_threshold=nms_threshold
        # sensor给到AI的图像分辨率
        self.rgb888p_size=[ALIGN_UP(rgb888p_size[0],16),rgb888p_size[1]]
        # 显示分辨率
        self.display_size=[ALIGN_UP(display_size[0],16),display_size[1]]
        self.debug_mode=debug_mode
        #骨骼信息
        self.SKELETON = [(16, 14),(14, 12),(17, 15),(15, 13),(12, 13),(6,  12),(7,  13),(6,  7),(6,  8),(7,  9),(8,  10),(9,  11),(2,  3),(1,  2),(1,  3),(2,  4),(3,  5),(4,  6),(5,  7)]
        #肢体颜色
        self.LIMB_COLORS = [(255, 51,  153, 255),(255, 51,  153, 255),(255, 51,  153, 255),(255, 51,  153, 255),(255, 255, 51,  255),(255, 255, 51,  255),(255, 255, 51,  255),(255, 255, 128, 0),(255, 255, 128, 0),(255, 255, 128, 0),(255, 255, 128, 0),(255, 255, 128, 0),(255, 0,   255, 0),(255, 0,   255, 0),(255, 0,   255, 0),(255, 0,   255, 0),(255, 0,   255, 0),(255, 0,   255, 0),(255, 0,   255, 0)]
        #关键点颜色，共17个
        self.KPS_COLORS = [(255, 0, 255, 0),(255, 0, 255, 0),(255, 0, 255, 0),(255, 0, 255, 0),(255, 0,   255, 0),(255, 255, 128, 0),(255, 255, 128, 0),(255, 255, 128, 0),(255, 255, 128, 0),(255, 255, 128, 0),(255, 255, 128, 0),(255, 51,  153, 255),(255, 51,  153, 255),(255, 51,  153, 255),(255, 51,  153, 255),(255, 51,  153, 255),(255, 51,  153, 255)]

        # Ai2d实例，用于实现模型预处理
        self.ai2d=Ai2d(debug_mode)
        # 设置Ai2d的输入输出格式和类型
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT,nn.ai2d_format.NCHW_FMT,np.uint8, np.uint8)
        self.fall_labels = ["跌倒","未跌倒"]

    # 配置预处理操作，这里使用了pad和resize，Ai2d支持crop/shift/pad/resize/affine，具体代码请打开/sdcard/app/libs/AI2D.py查看
    def config_preprocess(self,input_image_size=None):
        with ScopedTiming("set preprocess config",self.debug_mode > 0):
            # 初始化ai2d预处理配置，默认为sensor给到AI的尺寸，您可以通过设置input_image_size自行修改输入尺寸
            ai2d_input_size=input_image_size if input_image_size else self.rgb888p_size
            top,bottom,left,right=self.get_padding_param()
            self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [0,0,0])
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],[1,3,self.model_input_size[1],self.model_input_size[0]])

    # 自定义当前任务的后处理
    def postprocess(self,results):
        with ScopedTiming("postprocess",self.debug_mode > 0):
            # 这里使用了aidemo库的person_kp_postprocess接口
            results = aidemo.person_kp_postprocess(results[0],[self.rgb888p_size[1],self.rgb888p_size[0]],self.model_input_size,self.confidence_threshold,self.nms_threshold)
            return results

    #绘制结果，绘制人体关键点
    def draw_result(self,osd_img,res):
        if res[0]:
            kpses = res[1]
            for i in range(len(res[0])):
                for k in range(17+2):
                    if (k < 17):
                        kps_x,kps_y,kps_s = round(kpses[i][k][0]),round(kpses[i][k][1]),kpses[i][k][2]
                        kps_x1 = int(float(kps_x) * self.display_size[0] // self.rgb888p_size[0])
                        kps_y1 = int(float(kps_y) * self.display_size[1] // self.rgb888p_size[1])
                        if (kps_s > 0):
                            osd_img.draw_circle(kps_x1,kps_y1,5,self.KPS_COLORS[k],4)
                    ske = self.SKELETON[k]
                    pos1_x,pos1_y= round(kpses[i][ske[0]-1][0]),round(kpses[i][ske[0]-1][1])
                    pos1_x_ = int(float(pos1_x) * self.display_size[0] // self.rgb888p_size[0])
                    pos1_y_ = int(float(pos1_y) * self.display_size[1] // self.rgb888p_size[1])

                    pos2_x,pos2_y = round(kpses[i][(ske[1] -1)][0]),round(kpses[i][(ske[1] -1)][1])
                    pos2_x_ = int(float(pos2_x) * self.display_size[0] // self.rgb888p_size[0])
                    pos2_y_ = int(float(pos2_y) * self.display_size[1] // self.rgb888p_size[1])

                    pos1_s,pos2_s = kpses[i][(ske[0] -1)][2],kpses[i][(ske[1] -1)][2]
                    if (pos1_s > 0.0 and pos2_s >0.0):
                        osd_img.draw_line(pos1_x_,pos1_y_,pos2_x_,pos2_y_,self.LIMB_COLORS[k],4)
                gc.collect()
                       
    # 计算padding参数
    def get_padding_param(self):
        dst_w = self.model_input_size[0]
        dst_h = self.model_input_size[1]
        input_width = self.rgb888p_size[0]
        input_high = self.rgb888p_size[1]
        ratio_w = dst_w / input_width
        ratio_h = dst_h / input_high
        if ratio_w < ratio_h:
            ratio = ratio_w
        else:
            ratio = ratio_h
        new_w = (int)(ratio * input_width)
        new_h = (int)(ratio * input_high)
        dw = (dst_w - new_w) / 2
        dh = (dst_h - new_h) / 2
        top = int(round(dh - 0.1))
        bottom = int(round(dh + 0.1))
        left = int(round(dw - 0.1))
        right = int(round(dw - 0.1))
        return  top, bottom, left, right
    

    def detect_pos_fall(self,osd_img,res):
        is_fallen = 1
        # 检测跌倒
        if res[0]:
            kpses = res[1][0]
            is_fallen = detect_fall(kpses, standing_heights)
    
            for det_box in res[0]:
                # 计算显示分辨率下的坐标
                x1, y1, x2, y2 = det_box[0], det_box[1], det_box[2], det_box[3]
                w = (x2 - x1) * self.display_size[0] // self.rgb888p_size[0]
                h = (y2 - y1) * self.display_size[1] // self.rgb888p_size[1]
                x1 = int(x1 * self.display_size[0] // self.rgb888p_size[0])
                y1 = int(y1 * self.display_size[1] // self.rgb888p_size[1])
                x2 = int(x2 * self.display_size[0] // self.rgb888p_size[0])
                y2 = int(y2 * self.display_size[1] // self.rgb888p_size[1])
                # 绘制矩形框和类别标签
                osd_img.draw_rectangle(x1, y1, int(w), int(h), color=(0,255,0), thickness=2)
                osd_img.draw_string_advanced(x1, y1-50, 32," " + self.fall_labels[is_fallen] + " ", color=(0,255,0))
                
            # 模拟跌倒姿势关键点数据（y轴方向向下增大）
        # print(is_fallen)
        return is_fallen

        
    def detect_pose_0(self,keypoints):
        angle_threshold=18
        leg_ratio=1.25
        if keypoints[0]:
            keypoints = keypoints[1][0]
            
        keypoints_len = len(keypoints)
  
        if(keypoints_len<17):
            return -1

        # 提取关键点坐标
        left_shoulder = keypoints[LEFT_SHOULDER]
        right_shoulder = keypoints[RIGHT_SHOULDER]
        left_wrist = keypoints[LEFT_WRIST]
        right_wrist = keypoints[RIGHT_WRIST]
        left_ankle = keypoints[LEFT_ANKLE]
        right_ankle = keypoints[RIGHT_ANKLE]
        hips_center = (keypoints[LEFT_HIP] + keypoints[RIGHT_HIP]) / 2

        # 计算肩宽
        shoulder_width = np.linalg.norm(left_shoulder - right_shoulder)

        # 判断手臂水平（Y轴坐标差异 < 阈值）
        arm_y_diff = math.fabs(left_wrist[1] - left_shoulder[1]) + math.fabs(right_wrist[1] - right_shoulder[1])
        arm_horizontal = arm_y_diff < angle_threshold

        # 判断手臂伸展（手腕X坐标超出肩宽）
        arm_span_ratio = (math.fabs(left_wrist[0] - right_wrist[0]) / shoulder_width) > 2.0

        # 判断双腿分开
        leg_span = np.linalg.norm(left_ankle - right_ankle)
        leg_separated = leg_span > leg_ratio * shoulder_width

        # 判断躯干直立（头-髋-踝垂线偏移 < 阈值）
        head_y = keypoints[0][1]
        vertical_offset = math.fabs(hips_center[0] - (left_ankle[0] + right_ankle[0])/2)
        torso_vertical = vertical_offset < 0.2 * shoulder_width
        
        # print('大字姿势:{},{},{},{}',arm_horizontal, arm_span_ratio, leg_separated, torso_vertical)
        
        if all([arm_horizontal, arm_span_ratio, leg_separated, torso_vertical]):
            return 0
        else:
            return -1


    def detect_pose_1(self,keypoints):
        flag = False
        angle_threshold=120
        dist_ratio=0.36
        if keypoints[0]:
            keypoints = keypoints[1][0]
            
        keypoints_len = len(keypoints)
        if(keypoints_len<17):
            return -1
        
        left_shoulder = keypoints[LEFT_SHOULDER]
        right_shoulder = keypoints[RIGHT_SHOULDER]
        left_elbow = keypoints[LEFT_ELBOW]
        right_elbow = keypoints[RIGHT_ELBOW]
        left_wrist = keypoints[LEFT_WRIST]
        right_wrist = keypoints[RIGHT_WRIST]
        left_hip = keypoints[LEFT_HIP]
        right_hip = keypoints[RIGHT_HIP]
        
        # 计算肘部弯曲角度（肩-肘-腕）
        left_elbow_angle = calculate_angle(left_shoulder, left_elbow, left_wrist)
        right_elbow_angle = calculate_angle(right_shoulder, right_elbow, right_wrist)
        
        # 判断手腕与髋部水平对齐
        left_hand_hip = math.fabs(left_wrist[1] - left_hip[1]) < dist_ratio * np.linalg.norm(left_hip - keypoints[LEFT_ANKLE])  # 与踝部高度比例
        right_hand_hip = math.fabs(right_wrist[1] - right_hip[1]) < dist_ratio * np.linalg.norm(right_hip - keypoints[RIGHT_ANKLE])
        
        # 判断肘部外展角度
        elbow_condition = (left_elbow_angle < angle_threshold) and (right_elbow_angle < angle_threshold)
    
        # 综合判断
        flag = all([left_hand_hip, right_hand_hip, elbow_condition])
        # print(left_elbow_angle,right_elbow_angle)
        # print('叉腰姿势:{},{},{}',left_hand_hip, right_hand_hip, elbow_condition)

        if flag:
            return 1
        else:
            return -1

    def detect_pose_2(self,keypoints):
        # 单腿站立 + 手臂飞翔状
        if keypoints[0]:
            keypoints = keypoints[1][0]
            
        keypoints_len = len(keypoints)
        if(keypoints_len<17):
            return -1
        
        left_shoulder = keypoints[LEFT_SHOULDER]
        left_elbow = keypoints[LEFT_ELBOW]
        left_wrist = keypoints[LEFT_WRIST]

        right_shoulder = keypoints[RIGHT_SHOULDER]
        right_elbow = keypoints[RIGHT_ELBOW]
        right_wrist = keypoints[RIGHT_WRIST]

        left_hip = keypoints[LEFT_HIP]
        left_knee = keypoints[LEFT_KNEE]
        left_ankle = keypoints[LEFT_ANKLE]

        right_hip = keypoints[RIGHT_HIP]
        right_knee = keypoints[RIGHT_KNEE]
        right_ankle = keypoints[RIGHT_ANKLE]
        # 角度计算
        arm_angle = calculate_angle(left_wrist, left_shoulder, right_wrist)
        right_arm_angle = calculate_angle(right_shoulder, right_elbow, right_wrist)        # 计算右臂夹角
        
        left_leg_angle = calculate_angle(left_hip, left_knee, left_ankle)
        right_leg_angle = calculate_angle(right_hip, right_knee, right_ankle)

        is_left_leg_standing = left_leg_angle > 160
        is_right_leg_lifted = right_leg_angle < 130

        is_arm_straight_line = arm_angle > 150       # 判断左右手腕连线
        is_right_arm_up = right_arm_angle > 150
        is_wrist_above_shoulder = right_wrist[1] < right_shoulder[1]    # 判断是否“上举”：手腕高于肩膀
        
        # 综合判断：右手臂向上抬起
        is_right_arm_raised = is_right_arm_up and is_wrist_above_shoulder
        
        # 输出判断
        # print("左腿是否站立：", is_left_leg_standing)
        # print("右腿是否抬起：", is_right_leg_lifted)

        # print("左腿：", left_leg_angle)
        # print("右腿：", right_leg_angle)

        # print("双臂连线：", is_arm_straight_line)
        # print("右臂：", is_right_arm_raised)
        

        # if is_left_leg_standing and is_right_arm_raised and is_arm_straight_line:
        #     print("姿势识别结果：飞翔状姿态")
        # else:
        #     print("姿势识别结果：不符合飞翔状特征")
            
        flag = all([is_left_leg_standing, is_right_arm_raised, is_arm_straight_line])
        # print('手臂飞翔状姿势:{},{},{}',is_left_leg_standing, is_right_arm_raised, is_arm_straight_line)
        if flag:
            return 2
        else:
            return -1

    
    def detect_pose_3(self,keypoints):
        flag = False
        if keypoints[0]:
            keypoints = keypoints[1][0]
            
        keypoints_len = len(keypoints)
        if(keypoints_len<17):
            return -1
        
        nose = keypoints[NOSE]
        left_shoulder = keypoints[LEFT_SHOULDER]
        right_shoulder = keypoints[RIGHT_SHOULDER]
        left_elbow = keypoints[LEFT_ELBOW]
        right_elbow = keypoints[RIGHT_ELBOW]
        left_wrist = keypoints[LEFT_WRIST]
        right_wrist = keypoints[RIGHT_WRIST]
        left_hip = keypoints[LEFT_HIP]
        right_hip = keypoints[RIGHT_HIP]
        left_knee = keypoints[LEFT_KNEE]
        right_knee = keypoints[RIGHT_KNEE]
        left_ankle = keypoints[LEFT_ANKLE]
        right_ankle = keypoints[RIGHT_ANKLE]
        
        shoulder_center = (left_shoulder + right_shoulder) / 2

        arms_forward = (
            is_arm_forward(left_shoulder, left_elbow, left_wrist) and
            is_arm_forward(right_shoulder, right_elbow, right_wrist)
        )
        torso_forward = is_torso_leaning_forward(nose, shoulder_center)
        legs_straight = (
            is_leg_straight(left_hip, left_knee, left_ankle) and
            is_leg_straight(right_hip, right_knee, right_ankle)
        )
        # print('detect_pose_3:{},{},{}',arms_forward, torso_forward, legs_straight)
        flag = arms_forward and torso_forward and legs_straight
        if flag:
            return 3
        else:
            return -1
        
    def detect_pose_all(self,res):
        pose_flag = -1
        pose_flag = self.detect_pose_2(res)
        if(pose_flag!=-1):
            return pose_flag
        pose_flag = self.detect_pose_0(res)
        if(pose_flag!=-1):
            return pose_flag
        pose_flag = self.detect_pose_1(res)
        if(pose_flag!=-1):
            return pose_flag
        pose_flag = self.detect_pose_3(res)
        if(pose_flag!=-1):
            return pose_flag
        
        return pose_flag
