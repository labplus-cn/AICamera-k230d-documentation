# 快速线性回归示例
#
# 本示例展示如何使用 CanMV 摄像头的 get_regression() 方法
# 获取指定 ROI 区域的线性回归结果。通过该方法可以轻松构建
# 能够跟踪同一方向但不连续线条的机器人。对于连通性好的线条，
# 建议使用 find_blobs() 方法进行更好的过滤和控制。
#
# 之所以称为“快速线性回归”，是因为采用了最小二乘法拟合直线。
# 但该方法不适用于包含大量（甚至少量）异常点的图像，否则会影响拟合效果。
import time, os, gc, sys

from media.sensor import *
from media.display import *
from media.media import *


DETECT_WIDTH = 544
DETECT_HEIGHT = 368

THRESHOLD = (0, 100) # 灰度阈值，设置阈值，（0，100）检测黑色线
BINARY_VISIBLE = True # 是否先进行二值化处理，便于观察线性回归的输入数据，可能会降低帧率

sensor = None

def camera_init():
    global sensor

    # 构造 Sensor 对象并使用默认配置
    sensor = Sensor(width=DETECT_WIDTH,height=DETECT_HEIGHT)
    # 复位摄像头
    sensor.reset()
    # 设置水平镜像
    # sensor.set_hmirror(False)
    # 设置垂直翻转
    # sensor.set_vflip(False)

    # 设置 chn0 输出尺寸
    sensor.set_framesize(width=DETECT_WIDTH,height=DETECT_HEIGHT)
    # 设置 chn0 输出格式为灰度
    sensor.set_pixformat(Sensor.GRAYSCALE)

    Display.init(Display.ST7701, width = DETECT_WIDTH, height = DETECT_HEIGHT, to_ide = True)
    # 初始化媒体管理器
    MediaManager.init()
    # 启动摄像头
    sensor.run()

def camera_deinit():
    global sensor

    # 停止摄像头
    sensor.stop()
    # 释放显示资源
    Display.deinit()
    # 进入休眠
    os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    time.sleep_ms(100)
    # 释放媒体缓冲区
    MediaManager.deinit()

def capture_picture():
    while True:
        res = {"x1":None, "y1":None, "x2":None, "y2":None, "length":None, "magnitude":None, "theta":None, "rho":None}
        try:
            os.exitpoint()

            global sensor
            img = sensor.snapshot()
            # 根据设置决定是否进行二值化处理
            img = img.binary([THRESHOLD]) if BINARY_VISIBLE else img
            # 返回一个 line 对象，类似于 find_lines() 和 find_line_segments() 的结果
            # 包含 x1(), y1(), x2(), y2(), length(),
            # theta()（旋转角度，单位为度）、rho() 和 magnitude() 等属性
            # 函数返回回归后的线段对象line，有x1(), y1(), x2(), y2(), length(), theta(), rho(), magnitude()参数。
            # x1 y1 x2 y2分别代表线段的两个顶点坐标，length是线段长度，theta是线段的角度。
            # magnitude表示线性回归的效果，它是（0，+∞）范围内的一个数字，其中0代表一个圆。如果场景线性回归的越好，这个值越大。
            line = img.get_regression([(255,255) if BINARY_VISIBLE else THRESHOLD])
            if (line): 
                img.draw_line(line.line(), color = 127)
                # print(line) #{"x1":88, "y1":367, "x2":526, "y2":0, "length":571, "magnitude":1, "theta":50, "rho":338}
                res["x1"] = line.x1()
                res["y1"] = line.y1()
                res["x2"] = line.x2()
                res["y2"] = line.y2()
                res["length"] = line.length()
                res["magnitude"] = line.magnitude()
                res["theta"] = line.theta()
                res["rho"] = line.rho()
                print(res)
            else:
                print("未检测到线条")



            # 显示结果到屏幕
            Display.show_image(img)

            del img
            gc.collect()
        except KeyboardInterrupt as e:
            print("用户中断: ", e)
            break
        except BaseException as e:
            print("异常: {}".format(e))
            break

def main():
    os.exitpoint(os.EXITPOINT_ENABLE)
    camera_is_init = False
    try:
        print("摄像头初始化")
        camera_init()
        camera_is_init = True
        print("开始采集图像")
        capture_picture()
    except Exception as e:
        print("异常: {}".format(e))
    finally:
        if camera_is_init:
            print("摄像头资源释放")
            camera_deinit()

if __name__ == "__main__":
    main()
