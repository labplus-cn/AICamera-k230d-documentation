import os

DISPLAY_WIDTH = 544
DISPLAY_HEIGHT = 368

DEFAULT_MODE = 0 # 默认UI
SENSOR_MODE = -1 # 摄像头
FACE_DETECTION_MODE = 1
OBJECT_RECOGNIZATION_MODE = 2 
HAND_DETECTION = 3
HAND_KEYPOINT_CLASS = 4
QRCODE_MODE = 5
PERSON_DETECTION = 6
FALL_DETECTION = 7 
LICENSE_PLATE_RECOGNITION = 8
CANNY_FIND_EDGES = 9
PERSON_KEYPOINT_DETECT = 10 # 人体关键点数据

PERSON_KEYPOINT_DETECT_PLUS = 11 
COLOR_STATISTICS_MODE = 13 # 颜色的统计信息
COLOR_EXTRACTO_MODE = 14 # LAB颜色提取器
APRILTAG_MODE = 15
COLOE_MODE = 16
SPEECH_RECOGNIZATION_MODE = 17
SELF_LEARNING_CLASSIFIER_MODE = 18 # 自学习
GUIDEPOST_MODE = 19 #清华教材交通标志识别
KPU_MODEL_MODE = 20 #自定义模型 

HAND_RECOGNIZATION_MODE = 21
BARCODE_MODE = 23

DYNAMIC_GESTURE = 25 #动态手势
FACE_LANDMARK = 26  # 人脸关键点
FACE_LANDMARK_LIVING_BODY = 27
FACE_LANDMARK_EXPRESSION = 28

COLOR_OBJECT_COUNT_MODE = 29
LAB_COLOR_OBJECT_COUNT_MODE = 22 #LAB

FACE_REG_MODE = 30 # 人脸注册
FACE_RECOGNITION_MODE = 31 #人脸识别
CLASSIFY_MODEL_MODE = 32 # 分类模型
DETECT_MODEL_MODE = 33  # 检测模型
HAND_KEYPOINT = 34 
FACE_REG_PLUS_MODE = 35 # 人脸拍照+注册
APS_MODE = 36  # 道路自动驾驶系统

LINEAR_REGRESSION_MODE = 40 #快速线性回归
LINEAR_REGRESSION_V3_MODE = 41 #快速线性回归 v3

FACTORY_MODE = 99 

YOLO80_ZH = ["人","自行车","汽车","摩托车","飞机","公共汽车","火车","卡车","船","交通灯","消防栓","停车标志","泊车计时器","长椅","鸟","猫","狗","马","绵羊","奶牛","大象","熊","斑马","长颈鹿","背包","雨伞","手提包","领带","手提箱","飞盘","滑雪板","运动球","风筝","棒球","蝙蝠","棒球手套","滑板","冲浪板","网球拍","瓶子","酒杯","杯子","叉子","刀","勺子","碗","香蕉","苹果","三明治","橙子","西兰花","胡萝卜","热狗","披萨","甜甜圈","蛋糕","椅子","沙发","盆栽","床","餐桌","厕所","电视","笔记本电脑","鼠标","遥控器","键盘","手机","微波炉","烤箱","烤面包机", "水槽","冰箱","书籍","时钟","花瓶","剪刀","泰迪熊","吹风机","牙刷"] 
HAND_KEYPOINT_CLASS_GESTURE = ['fist','five','gun','love','one','six','three','thumbUp','yeah']
FACE_LANDMARK_EXPRESSION_ZH = ['正常','开心','伤心','惊讶','生气']
DYNAMIC_GESTURE_STR = ['上','下','左','右'] 

def K230Flag():
    '''默认值'''
    k230_flag_dict = {
        "sensor_mode" : False,
        "run_mode" : DEFAULT_MODE,
        "model_dict": {},
        "res": None,
        "flag_fac_recognize" : 0,
        "flag_yolo_recognize" : 0,
        "flag_face_detection" : 0,
        "sw_lock" : False,   #切换模式锁定
        "left_cb" : None,
        "middle_cb": None,
        "key_middle_status": False,
        "key_left_status": False,
        "key_right_status": False
    }
    return k230_flag_dict
        

def del_dir(path):
    '''删除文件夹'''
    stat_info = os.stat(path)
    if (stat_info[0] & 0x4000):
        list_files = os.listdir(path)
        for l in list_files:
            os.remove(path + l)
    os.rmdir(path)


def rmdir(directory):
    # 递归删除目录内容
    for file in os.listdir(directory):
        path = '/'.join((directory, file)) if directory != '' else file
        try:
            os.remove(path)  # 先尝试删除文件
        except OSError:
            rmdir(path)  # 如果是目录则递归删除
#    os.rmdir(directory)  # 最后删除空目录

# 使用示例
# rmdir('/sdcard/test')


k230_flag = K230Flag()