from machine import FPIOA
from machine import Pin,Timer
import time
import uerrno

fpioa = FPIOA()

class button:
    """ 按键类 """
    # 按键状态
    KEY_DOWN = 0
    KEY_UP = 1

    # 记录所有创建的button对象,在定时器里周期性调用
    btn_list = []

    # 定时器触发事件处理
    def on_timer(timer):
        """
        on_button_timer 按键扫描定时器程序,为所有的按键(button)触发10ms一次的update操作
        
        """
        try:
            for btn in button.btn_list:
                btn.update()
        except:
            print('stop timer!')
            timer.deinit()
            button._timer_inited = False
    
    # 定时器初始化(所有button对象共享一个定时器)
    _timer_inited = False
    def timer_init(timer):
        button._timer_inited = True        
        # 实例化一个软定时器
        tim = Timer(-1)
        # 配置定时器，周期模式，周期 1000 毫秒
        print('timer started')
        tim.init(period=10, mode=Timer.PERIODIC, callback=button.on_timer)
        return tim
        # return Timer(timer, mode=Timer.PERIODIC, period=10, callback=button.on_timer)
        

    def __init__(self, pin, invert=False):
        global button_timer_inited
        # fm.register(pin, fm.fpioa.GPIOHS0 + pin)
        fpioa.set_function(pin,FPIOA.GPIO0 + pin)
        # self.GPIO = GPIO(GPIO.GPIOHS0 + pin, GPIO.IN, GPIO.PULL_UP)
        self.GPIO=Pin(FPIOA.GPIO0 + pin, Pin.IN, Pin.PULL_UP) 
        self.state = self.GPIO.value()
        self.invert = invert
        button.btn_list.append(self)       
        # self.trigger_time = 0
        self.pressed = 0
        if self.GPIO.value():
            self.curr_state = button.KEY_DOWN if self.invert else button.KEY_UP
        else:
            self.curr_state = button.KEY_UP if self.invert else button.KEY_DOWN
        self.pre_state = self.curr_state
        self.counter = 0
        if button._timer_inited == False:
            # self.tim = button.timer_init(Timer.TIMER1)
            self.tim = button.timer_init(-1)
            if self.tim == None:
                raise OSError(uerrono.ENODEV)

    def __del__(self):
        button.btn_list.remove(self)
        if len(button.btn_list) == 0:
            self.tim.stop()

    def update(self):
        if self.GPIO.value():
            self.counter = self.counter + 1
        else:
            self.counter = self.counter - 1
        
        if self.counter < -3:
            self.counter = -3
            self.curr_state = button.KEY_UP if self.invert else button.KEY_DOWN

        if self.counter > 3:
            self.counter = 3
            self.curr_state = button.KEY_DOWN if self.invert else button.KEY_UP
            
        if self.curr_state != self.pre_state:
            self.pre_state = self.curr_state

            if (self.curr_state == button.KEY_DOWN):
                self.pressed = self.pressed + 1
                # print('button pressed')
        # print('timer elapsed!')
        pass

    # def irq(self):
    #     # # 按键状态改变,发生第一次中断:记录中断时间
    #     diff = time.ticks_diff(time.ticks(), self.trigger_time)

    #     # 大于10ms的边沿
    #     if diff > 10:
    #         if self.GPIO.value() == 0:     
    #             # key down 
    #             print("%6d:button triggled, value = %d" % (time.ticks(), self.GPIO.value()))
    #     self.trigger_time = time.ticks()

    def is_pressed(self):
        if self.curr_state == button.KEY_DOWN:
            while not self.curr_state: #检测按键是否松开
                pass
            return True
        else:
            return False
    

class LED():
    """ LED K230引脚控制的LED,默认使用Pinx与对应的GPIOx驱动 """
    def __init__(self, pin, invert=False):
        fpioa.set_function(pin,FPIOA.GPIO0 + pin)
        self.GPIO=Pin(FPIOA.GPIO0 + pin, Pin.OUT) 
        self.invert = invert
        if invert:
            self.GPIO.value(1)
        else:
            self.GPIO.value(0)
    
    def on(self):
        if self.invert:
            self.GPIO.value(0)
        else:
            self.GPIO.value(1)
    
    def off(self):
        if self.invert:
            self.GPIO.value(1)
        else:
            self.GPIO.value(0)