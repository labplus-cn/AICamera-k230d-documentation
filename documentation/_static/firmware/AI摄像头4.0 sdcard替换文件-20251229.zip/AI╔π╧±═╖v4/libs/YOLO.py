from libs.PipeLine import ScopedTiming
from libs.AIBase import AIBase
from libs.AI2D import Ai2d
from libs.Utils import *
import os
import ujson
from media.media import *
from time import *
import nncase_runtime as nn
import ulab.numpy as np
import time
import utime
import image
import random
import gc
import sys
import aidemo

class YOLOv5(AIBase):
    def __init__(self,task_type="detect",mode="video",kmodel_path="",labels=[],rgb888p_size=[320,320],model_input_size=[320,320],display_size=[1920,1080],conf_thresh=0.5,nms_thresh=0.45,mask_thresh=0.5,max_boxes_num=50,debug_mode=0):
        if task_type not in ["classify","detect","segment"]:
            print("Please select the correct task_type parameter, including 'classify', 'detect', 'segment'.")
            return
        super().__init__(kmodel_path,model_input_size,rgb888p_size,debug_mode)
        self.task_type=task_type
        self.mode=mode
        self.kmodel_path=kmodel_path
        self.labels=labels
        self.class_num=len(labels)
        if mode=="video":
            self.rgb888p_size=[ALIGN_UP(rgb888p_size[0],16),rgb888p_size[1]]
        else:
            self.rgb888p_size=[rgb888p_size[0],rgb888p_size[1]]
        self.model_input_size=model_input_size
        self.display_size=[ALIGN_UP(display_size[0],16),display_size[1]]

        self.conf_thresh=conf_thresh
        self.nms_thresh=nms_thresh
        self.mask_thresh=mask_thresh
        self.max_boxes_num=max_boxes_num
        self.debug_mode=debug_mode

        self.scale=1.0
        self.colors=get_colors(len(self.labels))
        self.masks=None
        if self.task_type=="segment":
            if self.mode=="image":
                self.masks=np.zeros((1,self.rgb888p_size[1],self.rgb888p_size[0],4),dtype=np.uint8)
            elif self.mode=="video":
                self.masks=np.zeros((1,self.display_size[1],self.display_size[0],4),dtype=np.uint8)
        # Ai2d实例，用于实现模型预处理
        self.ai2d=Ai2d(self.debug_mode)
        # 设置Ai2d的输入输出格式和类型
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT,nn.ai2d_format.NCHW_FMT,np.uint8, np.uint8)

    # 配置预处理操作，这里使用了resize，Ai2d支持crop/shift/pad/resize/affine，具体代码请打开/sdcard/app/libs/AI2D.py查看
    def config_preprocess(self,input_image_size=None):
        with ScopedTiming("set preprocess config",self.debug_mode > 0):
            # 初始化ai2d预处理配置，默认为sensor给到AI的尺寸，您可以通过设置input_image_size自行修改输入尺寸
            ai2d_input_size=input_image_size if input_image_size else self.rgb888p_size
            if self.task_type=="classify":
                top,left,m=center_crop_param(self.rgb888p_size)
                self.ai2d.crop(left,top,m,m)
            elif self.task_type=="detect":
                # 计算padding参数
                top,bottom,left,right,self.scale=letterbox_pad_param(self.rgb888p_size,self.model_input_size)
                # 配置padding预处理
                self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            elif self.task_type=="segment":
                top,bottom,left,right,scale=letterbox_pad_param(self.rgb888p_size,self.model_input_size)
                self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            # build参数包含输入shape和输出shape
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],[1,3,self.model_input_size[1],self.model_input_size[0]])

    def postprocess(self,results):
        with ScopedTiming("postprocess",self.debug_mode > 0):
            if self.task_type=="classify":
                softmax_res=softmax(results[0][0])
                res_idx=np.argmax(softmax_res)
                cls_res=(-1,0.0)
                # 如果类别分数大于阈值，返回当前类别和分数
                if softmax_res[res_idx]>self.conf_thresh:
                    cls_res=(res_idx,softmax_res[res_idx])
                return cls_res
            elif self.task_type=="detect":
                output_data = results[0][0]
                boxes_ori = output_data[:,0:4]
                score_ori = output_data[:,4]
                class_ori = output_data[:,5:]
                class_res=np.argmax(class_ori,axis=-1)
                scores_ = score_ori*np.max(class_ori,axis=-1)
                boxes,inds,scores=[],[],[]
                for i in range(len(boxes_ori)):
                    if scores_[i]>self.conf_thresh:
                        x,y,w,h=boxes_ori[i][0],boxes_ori[i][1],boxes_ori[i][2],boxes_ori[i][3]
                        x1 = int((x - 0.5 * w)/self.scale)
                        y1 = int((y - 0.5 * h)/self.scale)
                        x2 = int((x + 0.5 * w)/self.scale)
                        y2 = int((y + 0.5 * h)/self.scale)
                        boxes.append([x1,y1,x2,y2])
                        inds.append(class_res[i])
                        scores.append(scores_[i])
                if len(boxes)==0:
                    return []
                boxes = np.array(boxes)
                scores = np.array(scores)
                inds = np.array(inds)
                # NMS过程
                keep = self.nms(boxes,scores,self.nms_thresh)
                dets = np.concatenate((boxes, scores.reshape((len(boxes),1)), inds.reshape((len(boxes),1))), axis=1)
                det_res = []
                for keep_i in keep:
                    det_res.append(dets[keep_i])
                det_res = np.array(det_res)
                det_res = det_res[:self.max_boxes_num, :]
                return det_res
            elif self.task_type=="segment":
                if self.mode=="image":
                    seg_res = aidemo.yolov5_seg_postprocess(results[0][0],results[1][0],[self.rgb888p_size[1],self.rgb888p_size[0]],[self.model_input_size[1],self.model_input_size[0]],[self.rgb888p_size[1],self.rgb888p_size[0]],len(self.labels),self.conf_thresh,self.nms_thresh,self.mask_thresh,self.masks)
                elif self.mode=="video":
                    seg_res = aidemo.yolov5_seg_postprocess(results[0][0],results[1][0],[self.rgb888p_size[1],self.rgb888p_size[0]],[self.model_input_size[1],self.model_input_size[0]],[self.display_size[1],self.display_size[0]],len(self.labels),self.conf_thresh,self.nms_thresh,self.mask_thresh,self.masks)
                return seg_res

    def draw_result(self,res,img):
        with ScopedTiming("draw result",self.debug_mode > 0):
            if self.mode=="video":
                if self.task_type=="classify":
                    ids,score=res[0],res[1]
                    if ids!=-1:
                        img.clear()
                        mes=self.labels[ids]+" "+str(round(score,3))
                        img.draw_string_advanced(5,5,32,mes,color=(0,255,0))
                    else:
                        img.clear()
                elif self.task_type=="detect":
                    if res:
                        img.clear()
                        for det in res:
                            x1, y1, x2, y2 = map(lambda x: int(round(x, 0)), det[:4])
                            x= x1*self.display_size[0] // self.rgb888p_size[0]
                            y= y1*self.display_size[1] // self.rgb888p_size[1]
                            w = (x2 - x1) * self.display_size[0] // self.rgb888p_size[0]
                            h = (y2 - y1) * self.display_size[1] // self.rgb888p_size[1]
                            img.draw_rectangle(x,y, w, h, color=self.colors[int(det[5])],thickness=4)
                            img.draw_string_advanced( x , y-50,32," " + self.labels[int(det[5])] + " " + str(round(det[4],2)) , color=self.colors[int(det[5])])
                    else:
                        img.clear()
                elif self.task_type=="segment":
                    if res[0]:
                        img.clear()
                        mask_img=image.Image(self.display_size[0], self.display_size[1], image.ARGB8888,alloc=image.ALLOC_REF,data=self.masks)
                        img.copy_from(mask_img)
                        dets,ids,scores = res[0],res[1],res[2]
                        for i, det in enumerate(dets):
                            x1, y1, w, h = map(lambda x: int(round(x, 0)), det)
                            img.draw_string_advanced(x1,y1-50,32, " " + self.labels[int(ids[i])] + " " + str(round(scores[i],2)) , color=self.colors[int(ids[i])])
                    else:
                        img.clear()
                else:
                    pass
            elif self.mode=="image":
                if self.task_type=="classify":
                    ids,score=res[0],res[1]
                    if ids!=-1:
                        mes=self.labels[ids]+" "+str(round(score,3))
                        img.draw_string_advanced(5,5,32,mes,color=(0,255,0))
                    img.compress_for_ide()
                elif self.task_type=="detect":
                    if res:
                        for det in res:
                            x1, y1, x2, y2 = map(lambda x: int(round(x, 0)), det[:4])
                            x,y=int(x1),int(y1)
                            w = int(x2 - x1)
                            h = int(y2 - y1)
                            img.draw_rectangle(x,y,w,h,color=self.colors[int(det[5])],thickness=4)
                            img.draw_string_advanced( x , y-25,20," " + self.labels[int(det[5])] + " " + str(round(det[4],2)) , color=self.colors[int(det[5])])
                    img.compress_for_ide()
                elif self.task_type=="segment":
                    if res[0]:
                        mask_rgb=self.masks[0,:,:,1:4]
                        mask_img=image.Image(self.rgb888p_size[0], self.rgb888p_size[1], image.RGB888,alloc=image.ALLOC_REF,data=mask_rgb.copy())
                        dets,ids,scores = res[0],res[1],res[2]
                        for i, det in enumerate(dets):
                            x, y, w, h = map(lambda x: int(round(x, 0)), det)
                            mask_img.draw_string_advanced(x,y-50,32, " " + self.labels[int(ids[i])] + " " + str(round(scores[i],2)) , color=self.colors[int(ids[i])])
                        mask_img.compress_for_ide()
                else:
                    pass


    # 多目标检测 非最大值抑制方法实现
    def nms(self,boxes,scores,thresh):
        """Pure Python NMS baseline."""
        x1,y1,x2,y2 = boxes[:, 0],boxes[:, 1],boxes[:, 2],boxes[:, 3]
        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = np.argsort(scores,axis = 0)[::-1]
        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            new_x1,new_y1,new_x2,new_y2,new_areas = [],[],[],[],[]
            for order_i in order:
                new_x1.append(x1[order_i])
                new_x2.append(x2[order_i])
                new_y1.append(y1[order_i])
                new_y2.append(y2[order_i])
                new_areas.append(areas[order_i])
            new_x1 = np.array(new_x1)
            new_x2 = np.array(new_x2)
            new_y1 = np.array(new_y1)
            new_y2 = np.array(new_y2)
            xx1 = np.maximum(x1[i], new_x1)
            yy1 = np.maximum(y1[i], new_y1)
            xx2 = np.minimum(x2[i], new_x2)
            yy2 = np.minimum(y2[i], new_y2)
            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h
            new_areas = np.array(new_areas)
            ovr = inter / (areas[i] + new_areas - inter)
            new_order = []
            for ovr_i,ind in enumerate(ovr):
                if ind < thresh:
                    new_order.append(order[ovr_i])
            order = np.array(new_order,dtype=np.uint8)
        return keep


class YOLOv8(AIBase):
    def __init__(self,task_type="detect",mode="video",kmodel_path="",labels=[],rgb888p_size=[320,320],model_input_size=[320,320],display_size=[1920,1080],conf_thresh=0.5,nms_thresh=0.45,mask_thresh=0.5,max_boxes_num=50,debug_mode=0):
        if task_type not in ["classify","detect","segment"]:
            print("Please select the correct task_type parameter, including 'classify', 'detect', 'segment'.")
            return
        super().__init__(kmodel_path,model_input_size,rgb888p_size,debug_mode)
        self.task_type=task_type
        self.mode=mode
        self.kmodel_path=kmodel_path
        self.labels=labels
        self.class_num=len(labels)
        if mode=="video":
            self.rgb888p_size=[ALIGN_UP(rgb888p_size[0],16),rgb888p_size[1]]
        else:
            self.rgb888p_size=[rgb888p_size[0],rgb888p_size[1]]
        self.model_input_size=model_input_size
        self.display_size=[ALIGN_UP(display_size[0],16),display_size[1]]

        self.conf_thresh=conf_thresh
        self.nms_thresh=nms_thresh
        self.mask_thresh=mask_thresh
        self.max_boxes_num=max_boxes_num
        self.debug_mode=debug_mode

        self.scale=1.0
        self.colors=get_colors(len(self.labels))
        self.masks=None
        if self.task_type=="segment":
            if self.mode=="image":
                self.masks=np.zeros((1,self.rgb888p_size[1],self.rgb888p_size[0],4),dtype=np.uint8)
            elif self.mode=="video":
                self.masks=np.zeros((1,self.display_size[1],self.display_size[0],4),dtype=np.uint8)
        # Ai2d实例，用于实现模型预处理
        self.ai2d=Ai2d(self.debug_mode)
        # 设置Ai2d的输入输出格式和类型
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT,nn.ai2d_format.NCHW_FMT,np.uint8, np.uint8)

    # 配置预处理操作，这里使用了resize，Ai2d支持crop/shift/pad/resize/affine，具体代码请打开/sdcard/app/libs/AI2D.py查看
    def config_preprocess(self,input_image_size=None):
        with ScopedTiming("set preprocess config",self.debug_mode > 0):
            # 初始化ai2d预处理配置，默认为sensor给到AI的尺寸，您可以通过设置input_image_size自行修改输入尺寸
            ai2d_input_size=input_image_size if input_image_size else self.rgb888p_size
            if self.task_type=="classify":
                top,left,m=center_crop_param(self.rgb888p_size)
                self.ai2d.crop(left,top,m,m)
            elif self.task_type=="detect":
                # 计算padding参数
                top,bottom,left,right,self.scale=letterbox_pad_param(self.rgb888p_size,self.model_input_size)
                # 配置padding预处理
                self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            elif self.task_type=="segment":
                top,bottom,left,right,scale=letterbox_pad_param(self.rgb888p_size,self.model_input_size)
                self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            # build参数包含输入shape和输出shape
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],[1,3,self.model_input_size[1],self.model_input_size[0]])

    def postprocess(self,results):
        with ScopedTiming("postprocess",self.debug_mode > 0):
            if self.task_type=="classify":
                scores=results[0][0]
                max_score=np.max(scores)
                res_idx=np.argmax(scores)
                cls_res=(-1,0.0)
                # 如果类别分数大于阈值，返回当前类别和分数
                if max_score>self.conf_thresh:
                    cls_res=(res_idx,max_score)
                return cls_res
            elif self.task_type=="detect":
                output_data = results[0][0]
                output_data=output_data.transpose()
                boxes_ori = output_data[:,0:4]
                class_ori = output_data[:,4:]
                class_res=np.argmax(class_ori,axis=-1)
                scores_ = np.max(class_ori,axis=-1)
                boxes,inds,scores=[],[],[]
                for i in range(len(boxes_ori)):
                    if scores_[i]>self.conf_thresh:
                        x,y,w,h=boxes_ori[i][0],boxes_ori[i][1],boxes_ori[i][2],boxes_ori[i][3]
                        x1 = int((x - 0.5 * w)/self.scale)
                        y1 = int((y - 0.5 * h)/self.scale)
                        x2 = int((x + 0.5 * w)/self.scale)
                        y2 = int((y + 0.5 * h)/self.scale)
                        boxes.append([x1,y1,x2,y2])
                        inds.append(class_res[i])
                        scores.append(scores_[i])
                if len(boxes)==0:
                    return []
                boxes = np.array(boxes)
                scores = np.array(scores)
                inds = np.array(inds)
                # NMS过程
                keep = self.nms(boxes,scores,self.nms_thresh)
                dets = np.concatenate((boxes, scores.reshape((len(boxes),1)), inds.reshape((len(boxes),1))), axis=1)
                det_res = []
                for keep_i in keep:
                    det_res.append(dets[keep_i])
                det_res = np.array(det_res)
                det_res = det_res[:self.max_boxes_num, :]
                return det_res
            elif self.task_type=="segment":
                new_result=results[0][0].transpose()
                if self.mode=="image":
                    seg_res = aidemo.yolov8_seg_postprocess(new_result.copy(),results[1][0],[self.rgb888p_size[1],self.rgb888p_size[0]],[self.model_input_size[1],self.model_input_size[0]],[self.rgb888p_size[1],self.rgb888p_size[0]],len(self.labels),self.conf_thresh,self.nms_thresh,self.mask_thresh,self.masks)
                elif self.mode=="video":
                    seg_res = aidemo.yolov8_seg_postprocess(new_result.copy(),results[1][0],[self.rgb888p_size[1],self.rgb888p_size[0]],[self.model_input_size[1],self.model_input_size[0]],[self.display_size[1],self.display_size[0]],len(self.labels),self.conf_thresh,self.nms_thresh,self.mask_thresh,self.masks)
                return seg_res

    def draw_result(self,res,img):
        with ScopedTiming("draw result",self.debug_mode > 0):
            if self.mode=="video":
                if self.task_type=="classify":
                    ids,score=res[0],res[1]
                    if ids!=-1:
                        img.clear()
                        mes=self.labels[ids]+" "+str(round(score,3))
                        img.draw_string_advanced(5,5,32,mes,color=(0,255,0))
                    else:
                        img.clear()
                elif self.task_type=="detect":
                    if res:
                        img.clear()
                        for det in res:
                            x1, y1, x2, y2 = map(lambda x: int(round(x, 0)), det[:4])
                            x= x1*self.display_size[0] // self.rgb888p_size[0]
                            y= y1*self.display_size[1] // self.rgb888p_size[1]
                            w = (x2 - x1) * self.display_size[0] // self.rgb888p_size[0]
                            h = (y2 - y1) * self.display_size[1] // self.rgb888p_size[1]
                            img.draw_rectangle(x,y, w, h, color=self.colors[int(det[5])],thickness=4)
                            img.draw_string_advanced( x , y-50,32," " + self.labels[int(det[5])] + " " + str(round(det[4],2)) , color=self.colors[int(det[5])])
                    else:
                        img.clear()
                elif self.task_type=="segment":
                    if res[0]:
                        img.clear()
                        mask_img=image.Image(self.display_size[0], self.display_size[1], image.ARGB8888,alloc=image.ALLOC_REF,data=self.masks)
                        img.copy_from(mask_img)
                        dets,ids,scores = res[0],res[1],res[2]
                        for i, det in enumerate(dets):
                            x1, y1, w, h = map(lambda x: int(round(x, 0)), det)
                            img.draw_string_advanced(x1,y1-50,32, " " + self.labels[int(ids[i])] + " " + str(round(scores[i],2)) , color=self.colors[int(ids[i])])
                    else:
                        img.clear()
                else:
                    pass
            elif self.mode=="image":
                if self.task_type=="classify":
                    ids,score=res[0],res[1]
                    if ids!=-1:
                        mes=self.labels[ids]+" "+str(round(score,3))
                        img.draw_string_advanced(5,5,32,mes,color=(0,255,0))
                    img.compress_for_ide()
                elif self.task_type=="detect":
                    if res:
                        for det in res:
                            x1, y1, x2, y2 = map(lambda x: int(round(x, 0)), det[:4])
                            x,y=int(x1),int(y1)
                            w = int(x2 - x1)
                            h = int(y2 - y1)
                            img.draw_rectangle(x,y,w,h,color=self.colors[int(det[5])],thickness=4)
                            img.draw_string_advanced( x , y-25,20," " + self.labels[int(det[5])] + " " + str(round(det[4],2)) , color=self.colors[int(det[5])])
                    img.compress_for_ide()
                elif self.task_type=="segment":
                    if res[0]:
                        mask_rgb=self.masks[0,:,:,1:4]
                        mask_img=image.Image(self.rgb888p_size[0], self.rgb888p_size[1], image.RGB888,alloc=image.ALLOC_REF,data=mask_rgb.copy())
                        dets,ids,scores = res[0],res[1],res[2]
                        for i, det in enumerate(dets):
                            x, y, w, h = map(lambda x: int(round(x, 0)), det)
                            mask_img.draw_string_advanced(x,y-50,32, " " + self.labels[int(ids[i])] + " " + str(round(scores[i],2)) , color=self.colors[int(ids[i])])
                        mask_img.compress_for_ide()
                else:
                    pass


    # 多目标检测 非最大值抑制方法实现
    def nms(self,boxes,scores,thresh):
        """Pure Python NMS baseline."""
        x1,y1,x2,y2 = boxes[:, 0],boxes[:, 1],boxes[:, 2],boxes[:, 3]
        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = np.argsort(scores,axis = 0)[::-1]
        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            new_x1,new_y1,new_x2,new_y2,new_areas = [],[],[],[],[]
            for order_i in order:
                new_x1.append(x1[order_i])
                new_x2.append(x2[order_i])
                new_y1.append(y1[order_i])
                new_y2.append(y2[order_i])
                new_areas.append(areas[order_i])
            new_x1 = np.array(new_x1)
            new_x2 = np.array(new_x2)
            new_y1 = np.array(new_y1)
            new_y2 = np.array(new_y2)
            xx1 = np.maximum(x1[i], new_x1)
            yy1 = np.maximum(y1[i], new_y1)
            xx2 = np.minimum(x2[i], new_x2)
            yy2 = np.minimum(y2[i], new_y2)
            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h
            new_areas = np.array(new_areas)
            ovr = inter / (areas[i] + new_areas - inter)
            new_order = []
            for ovr_i,ind in enumerate(ovr):
                if ind < thresh:
                    new_order.append(order[ovr_i])
            order = np.array(new_order,dtype=np.uint8)
        return keep

 
class SteeringController:
    def __init__(self, vehicle_type="car", max_rate=15, safety_margin=5):
        self.vehicle_type = vehicle_type
        self.steering_limits = {
            "bicycle": (-45, 45),
            "motorcycle": (-35, 35),
            "car": (-30, 30),
            "truck": (-25, 25),
            "agv": (-60, 60),
            "rc_car": (-45, 45)
        }
        self.max_angle = self.steering_limits[vehicle_type][1]
        self.max_rate = max_rate
        self.safety_margin = safety_margin
        self.previous_angle = 0
        self.angle_history = []
        
        # 转向灵敏度控制参数
        self.steering_sensitivity = 0.85  # 道路转向灵敏度
        self.obstacle_sensitivity = 1.75  # 障碍物避让灵敏度
        
    def calculate_steering(self, direction, turn_type, confidence=1.0, current_speed=0):
        """计算安全的转向角 - 减小道路角度，增大障碍物避让"""
        # 基础角度映射 - 减小道路转向角度
        base_mapping = {
            "straight": min(5, self.max_angle),      # 进一步减小道路转向
            "gentle_turn": min(10, self.max_angle),  # 进一步减小道路转向
            "sharp_turn": min(15, self.max_angle),   # 进一步减小道路转向
            "no_road": 0,
            "invalid": 0,
            "emergency_slowdown": -3.0,
            "emergency_historical": 0.0,
            "emergency_straight": 0.0,
            # 障碍物避让类型 - 增大避让角度
            "obstacle_avoidance_minor": min(20, self.max_angle),   # 增大避让角度
            "obstacle_avoidance_gentle": min(25, self.max_angle),  # 增大避让角度
            "obstacle_avoidance_sharp": min(30, self.max_angle),   # 增大避让角度
            "strong_avoidance": min(35, self.max_angle),           # 增大避让角度
            # 十字路口导航类型
            "straight_to_crossing": min(8, self.max_angle),      # 向十字路口直行
            "gentle_turn_to_crossing": min(15, self.max_angle),  # 向十字路口缓转
            "sharp_turn_to_crossing": min(25, self.max_angle)    # 向十字路口急转
        }
        
        max_angle = base_mapping.get(turn_type, 5)  # 默认值进一步减小
        
        # 根据置信度调整
        if confidence < 0.3:
            direction = direction * 0.3
        elif confidence < 0.7:
            direction = direction * 0.5
            
        # 根据速度调整灵敏度
        speed_factor = self._calculate_speed_factor(current_speed)
        
        # 选择灵敏度：道路转向使用低灵敏度，障碍物避让使用高灵敏度
        if "avoidance" in turn_type or "obstacle" in turn_type:
            sensitivity = self.obstacle_sensitivity  # 障碍物避让使用高灵敏度
            speed_factor = min(speed_factor * 1.3, 1.0)  # 障碍物避让时增加转向能力
        else:
            sensitivity = self.steering_sensitivity  # 道路转向使用低灵敏度
        
        sensitivity_adjusted_direction = direction * sensitivity
        
        desired_angle = sensitivity_adjusted_direction * max_angle * speed_factor
        
        # 应用安全限制
        safe_angle = self._apply_safety_limits(desired_angle)
        
        return safe_angle
    
    def _calculate_speed_factor(self, speed):
        """根据速度计算转向灵敏度"""
        if speed < 5:    return 1.0
        elif speed < 15: return 0.7
        elif speed < 25: return 0.5
        else:           return 0.3

    def _apply_safety_limits(self, desired_angle):
        """应用安全限制"""
        # 物理限制
        physical_limit = self.max_angle - self.safety_margin
        
        if desired_angle > physical_limit:
            limited_angle = physical_limit
        elif desired_angle < -physical_limit:
            limited_angle = -physical_limit
        else:
            limited_angle = desired_angle
        
        # 变化率限制
        angle_diff = limited_angle - self.previous_angle
        if abs(angle_diff) > self.max_rate:
            limited_angle = self.previous_angle + (1 if angle_diff > 0 else -1) * self.max_rate
        
        self.previous_angle = limited_angle
        self.angle_history.append(limited_angle)
        
        # 保持历史长度
        if len(self.angle_history) > 20:
            self.angle_history.pop(0)
            
        return limited_angle

class RoadDirectionExtractor:
    def __init__(self, debug_mode=0):
        self.debug_mode = debug_mode
        self.alpha_threshold = 10  # 道路像素阈值
        # 选择特定的行进行采样 - 改为每隔10行采样1行 (~10%采样率)
        self.row_stride = 10  # 从7改为10，每隔10行采样1行 (~10%采样率)
        self.col_stride = 7   # 列采样保持7列采样1列 (~14.3%采样率)
        # 使用画面中间55%区域，排除最上方35%区域
        self.upper_exclude_ratio = 0.35  # 排除最上方35%区域
        self.middle_ratio = 0.55  # 从0.45改为0.55，使用中间55%区域
        
        # 新增：方向平滑和限制参数
        self.direction_smoothing = 0.8  # 方向平滑因子
        self.last_direction = 0.0
        self.max_direction_change = 0.2  # 单次最大方向变化
        
    def extract_direction_from_mask(self, mask):
        """极速方向提取方法 - 使用画面中间55%区域，排除最上方35%，~1.4%采样"""
        if mask is None or mask.size == 0:
            if self.debug_mode > 0:
                print("Warning: Empty mask provided")
            return 0.0, "no_road", 0.0
            
        height, width = mask.shape[0], mask.shape[1]
        
        # 计算中间55%区域（排除最上方35%）
        exclude_height = int(height * self.upper_exclude_ratio)
        middle_height = int(height * self.middle_ratio)
        start_y = exclude_height
        end_y = start_y + middle_height
        
        # 确保不超过图像边界
        end_y = min(end_y, height)
        middle_mask = mask[start_y:end_y, :]
        
        if self.debug_mode > 1:
            print(f"Using middle {self.middle_ratio*100}% region (excluding top {self.upper_exclude_ratio*100}%): {start_y} to {end_y} (height: {middle_height})")
            print(f"Sampling rate: {self.row_stride}x{self.col_stride} (~1.4% of middle region)")
        
        # 极速采样计算
        simple_dir, simple_conf = self._ultra_fast_sampling_method(middle_mask, width)
        
        # 应用方向平滑和限制
        smoothed_dir = self._apply_direction_smoothing(simple_dir)
        
        if simple_conf < 0.06:  # 调整阈值以适应更多采样
            if self.debug_mode > 0:
                print("Low confidence in ultra fast sampling method")
            return 0.0, "no_road", 0.0
                
        # 确定转向类型 - 调整阈值使直行范围更大
        turn_type = self._get_turn_type(smoothed_dir, simple_conf)
        
        if self.debug_mode > 0:
            steering_direction = self._get_steering_direction(smoothed_dir)
            print(f"Middle {self.middle_ratio*100}% (exclude top {self.upper_exclude_ratio*100}%) + ~1.4% Sampling - Direction: {smoothed_dir:.3f}, Type: {turn_type}, Confidence: {simple_conf:.3f}, Steering: {steering_direction}")
            
        return smoothed_dir, turn_type, simple_conf

    def _apply_direction_smoothing(self, current_direction):
        """应用方向平滑处理"""
        # 限制单次方向变化
        direction_change = current_direction - self.last_direction
        if abs(direction_change) > self.max_direction_change:
            limited_change = self.max_direction_change * (1 if direction_change > 0 else -1)
            current_direction = self.last_direction + limited_change
        
        # 应用平滑滤波
        smoothed = (current_direction * 0.6) + (self.last_direction * 0.4)
        self.last_direction = smoothed
        
        return smoothed

    def _ultra_fast_sampling_method(self, middle_mask, original_width):
        """极速采样方法 - 处理约1.4%像素"""
        height, width = middle_mask.shape[0], middle_mask.shape[1]
        
        x_coords = []
        sampled_pixels = 0
        total_sampled = 0
        
        # 使用10x7采样步长，处理约1.4%的像素（在中间区域中）
        for y in range(0, height, self.row_stride):
            for x in range(0, width, self.col_stride):
                total_sampled += 1
                if middle_mask[y, x] > 0:
                    x_coords.append(x)
                    sampled_pixels += 1
        
        if len(x_coords) < 8:  # 提高阈值以适应更多采样
            return 0.0, 0.0
        
        # 计算重心
        center_x = sum(x_coords) / len(x_coords)
        image_center = original_width // 2
        
        # 计算方向 [-1, 1] - 降低灵敏度
        max_deviation = original_width * 0.3  # 从0.5减小到0.3，降低方向计算的灵敏度
        direction = (center_x - image_center) / max_deviation
        
        # 手动clip到[-1, 1]
        if direction > 1.0:
            direction = 1.0
        elif direction < -1.0:
            direction = -1.0
        
        # 计算置信度（基于采样到的道路像素比例）
        total_possible_pixels = (height // self.row_stride) * (width // self.col_stride)
        road_ratio = sampled_pixels / total_possible_pixels if total_possible_pixels > 0 else 0
        confidence = min(road_ratio * 4, 1.0)  # 调整乘数以适应更多采样
        
        if self.debug_mode > 1:
            steering_dir = self._get_steering_direction(direction)
            print(f"~1.4% Sampling - Image Center: {image_center}, Road Center: {center_x:.1f}")
            print(f"Direction: {direction:.3f}, {steering_dir}")
            print(f"Sampled road pixels: {sampled_pixels}/{total_possible_pixels}, Confidence: {confidence:.3f}")
            print(f"Middle region size: {width}x{height}")
            print(f"Sampling rate: {self.row_stride}x{self.col_stride} (~1.4% of middle region)")
        
        return direction, confidence

    def _get_turn_type(self, direction, confidence):
        """根据方向值确定转向类型 - 调整阈值使直行范围更大"""
        if confidence < 0.20:  # 调整阈值
            return "no_road"
            
        abs_direction = abs(direction)
        if abs_direction < 0.3:    # 从0.2增大到0.3，扩大直行范围
            return "straight"
        elif abs_direction < 0.6:  # 从0.5增大到0.6
            return "gentle_turn"
        else:
            return "sharp_turn"

    def _get_steering_direction(self, direction):
        """获取转向方向描述 - 调整死区范围"""
        if direction < -0.15:    # 从-0.1调整到-0.15，增大死区
            return "LEFT_TURN"
        elif direction > 0.15:   # 从0.1调整到0.15，增大死区
            return "RIGHT_TURN"
        else:
            return "STRAIGHT"


class YOLO11(AIBase):    
    def __init__(self,task_type="detect",mode="video",kmodel_path="",labels=[],rgb888p_size=[320,320],model_input_size=[320,320],display_size=[1920,1080],conf_thresh=0.5,nms_thresh=0.45,mask_thresh=0.5,max_boxes_num=50,debug_mode=0, vehicle_type="car"):
        if task_type not in ["classify","detect","segment"]:
            print("Please select the correct task_type parameter, including 'classify', 'detect', 'segment'.")
            return
        super().__init__(kmodel_path,model_input_size,rgb888p_size,debug_mode)
        self.task_type=task_type
        self.mode=mode
        self.kmodel_path=kmodel_path
        self.labels=labels
        self.class_num=len(labels)
        if mode=="video":
            self.rgb888p_size=[ALIGN_UP(rgb888p_size[0],16),rgb888p_size[1]]
        else:
            self.rgb888p_size=[rgb888p_size[0],rgb888p_size[1]]
        self.model_input_size=model_input_size
        self.display_size=[ALIGN_UP(display_size[0],16),display_size[1]]

        self.conf_thresh=conf_thresh
        self.nms_thresh=nms_thresh
        self.mask_thresh=mask_thresh
        self.max_boxes_num=max_boxes_num
        self.debug_mode=debug_mode

        self.scale=1.0
        self.colors=get_colors(len(self.labels))
        self.masks=None
        self.alpha_threshold = 10  # 道路像素阈值
        if self.task_type=="segment":
            if self.mode=="image":
                self.masks=np.zeros((1,self.rgb888p_size[1],self.rgb888p_size[0],4),dtype=np.uint8)
            elif self.mode=="video":
                self.masks=np.zeros((1,self.display_size[1],self.display_size[0],4),dtype=np.uint8)
        
        # 新增：初始化方向提取和转向控制
        self.direction_extractor = RoadDirectionExtractor(debug_mode=debug_mode)
        self.steering_controller = SteeringController(vehicle_type=vehicle_type)
        
        # 采样参数：处理约2%的总像素
        self.mask_row_stride = 7  # 掩码提取行步长 (~14.3%采样率)
        self.mask_col_stride = 7  # 掩码提取列步长 (~14.3%采样率)
        
        self.ai2d=Ai2d(self.debug_mode)
        self.ai2d.set_ai2d_dtype(nn.ai2d_format.NCHW_FMT,nn.ai2d_format.NCHW_FMT,np.uint8, np.uint8)

    def config_preprocess(self,input_image_size=None):
        with ScopedTiming("set preprocess config",self.debug_mode > 0):
            ai2d_input_size=input_image_size if input_image_size else self.rgb888p_size
            if self.task_type=="classify":
                top,left,m=center_crop_param(self.rgb888p_size)
                self.ai2d.crop(left,top,m,m)
            elif self.task_type=="detect":
                top,bottom,left,right,self.scale=letterbox_pad_param(self.rgb888p_size,self.model_input_size)
                self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            elif self.task_type=="segment":
                top,bottom,left,right,scale=letterbox_pad_param(self.rgb888p_size,self.model_input_size)
                self.ai2d.pad([0,0,0,0,top,bottom,left,right], 0, [128,128,128])
            self.ai2d.resize(nn.interp_method.tf_bilinear, nn.interp_mode.half_pixel)
            self.ai2d.build([1,3,ai2d_input_size[1],ai2d_input_size[0]],[1,3,self.model_input_size[1],self.model_input_size[0]])

    def postprocess(self,results):
        with ScopedTiming("postprocess",self.debug_mode > 0):
            if self.task_type=="classify":
                scores=results[0][0]
                max_score=np.max(scores)
                res_idx=np.argmax(scores)
                cls_res=(-1,0.0)
                if max_score>self.conf_thresh:
                    cls_res=(res_idx,max_score)
                return cls_res
            elif self.task_type=="detect":
                output_data = results[0][0]
                output_data=output_data.transpose()
                boxes_ori = output_data[:,0:4]
                class_ori = output_data[:,4:]
                class_res=np.argmax(class_ori,axis=-1)
                scores_ = np.max(class_ori,axis=-1)
                boxes,inds,scores=[],[],[]
                for i in range(len(boxes_ori)):
                    if scores_[i]>self.conf_thresh:
                        x,y,w,h=boxes_ori[i][0],boxes_ori[i][1],boxes_ori[i][2],boxes_ori[i][3]
                        x1 = int((x - 0.5 * w)/self.scale)
                        y1 = int((y - 0.5 * h)/self.scale)
                        x2 = int((x + 0.5 * w)/self.scale)
                        y2 = int((y + 0.5 * h)/self.scale)
                        boxes.append([x1,y1,x2,y2])
                        inds.append(class_res[i])
                        scores.append(scores_[i])
                if len(boxes)==0:
                    return []
                boxes = np.array(boxes)
                scores = np.array(scores)
                inds = np.array(inds)
                keep = self.nms(boxes,scores,self.nms_thresh)
                dets = np.concatenate((boxes, scores.reshape((len(boxes),1)), inds.reshape((len(boxes),1))), axis=1)
                det_res = []
                for keep_i in keep:
                    det_res.append(dets[keep_i])
                det_res = np.array(det_res)
                det_res = det_res[:self.max_boxes_num, :]
                return det_res
            elif self.task_type=="segment":
                new_result=results[0][0].transpose()
                if self.mode=="image":
                    seg_res = aidemo.yolov8_seg_postprocess(new_result.copy(),results[1][0],[self.rgb888p_size[1],self.rgb888p_size[0]],[self.model_input_size[1],self.model_input_size[0]],[self.rgb888p_size[1],self.rgb888p_size[0]],len(self.labels),self.conf_thresh,self.nms_thresh,self.mask_thresh,self.masks)
                elif self.mode=="video":
                    seg_res = aidemo.yolov8_seg_postprocess(new_result.copy(),results[1][0],[self.rgb888p_size[1],self.rgb888p_size[0]],[self.model_input_size[1],self.model_input_size[0]],[self.display_size[1],self.display_size[0]],len(self.labels),self.conf_thresh,self.nms_thresh,self.mask_thresh,self.masks)
                return seg_res

    def get_road_direction_and_steering(self, target_id=0, current_speed=0, obstacles=None, crossing=None):
        """改进的道路方向和转向角计算 - 没有检测到道路时不进行避障"""
        if self.task_type != "segment" or self.masks is None:
            if self.debug_mode > 0:
                print("Error: Not in segment mode or masks not initialized")
            return 0.0, "invalid", 0.0, 0.0
            
        # 提取道路掩码
        road_mask = self._extreme_fast_extract_binary_mask(target_id)

        if road_mask is None:
            if self.debug_mode > 0:
                print("Error: Failed to extract road mask")
            return 0.0, "no_road", 0.0, 0.0
        
        # --- [改进] 十字路口/斑马线导航逻辑 ---
        if crossing is not None and road_mask is not None and len(crossing) > 0:
            H, W = self.masks.shape[1], self.masks.shape[2]
            
            # 计算底部 50% 的 Y 坐标阈值（从30%改为50%）
            bottom_70_percent_threshold = H * 0.3  # 因为Y坐标从上到下增加，所以50%对应0.5
            bottom_10_percent_threshold = H * 0.85  # 底部15%阈值
            # crossing 格式为 (center_x, center_y, w, h)
            cross_x, cross_y, cross_w, cross_h = crossing[0][0], crossing[0][1], crossing[0][2], crossing[0][3]
            
            if cross_y >= bottom_10_percent_threshold:
                if self.debug_mode > 0:
                    print(f"!!! [CROSSING TOO CLOSE] 十字路口/斑马线 detected at (X:{cross_x}, Y:{cross_y}) in bottom 10% !!!")
                    print("Skipping navigation to avoid abrupt maneuvers.")
                
                return 0.0, "crossing", 0.0, 1.0 
            # 当十字路口/斑马线位于画面下方50%区域时，进行导航
            elif cross_y >= bottom_70_percent_threshold:
                if self.debug_mode > 0:
                    print(f"!!! [CROSSING NAVIGATION] 十字路口/斑马线 detected at (X:{cross_x}, Y:{cross_y}) in bottom 50% !!!")
                    print(f"十字路口大小: {cross_w}x{cross_h}")
                    print(f"底部50%阈值: Y >= {bottom_70_percent_threshold}")
                    print(f"图像高度: {H}, 图像宽度: {W}")
                
                # 计算向十字路口中心前进的方向
                image_center_x = W // 2
                
                # 计算十字路口相对于图像中心的水平偏移
                cross_center_x = cross_x
                cross_offset = cross_center_x - image_center_x
                
                # 计算导航方向 [-1, 1]，使用更小的最大偏移量使转向更平缓
                max_deviation = W * 0.2  # 从0.3减小到0.2，使转向更平缓
                nav_direction = cross_offset / max_deviation if max_deviation > 0 else 0
                
                # 限制方向值在[-1, 1]范围内
                nav_direction = max(-1.0, min(1.0, nav_direction))
                
                # 计算基于十字路口大小的置信度
                cross_area = cross_w * cross_h
                image_area = H * W
                confidence = min(1.0, cross_area / (image_area * 0.1))  # 当十字路口占画面10%时达到最大置信度
                
                # 确保有足够的置信度
                confidence = max(confidence, 0.8)  # 提高最低置信度到0.8，因为导航需要更高准确性
                
                # 根据方向确定转向类型
                abs_nav_dir = abs(nav_direction)
                if abs_nav_dir < 0.3:
                    turn_type = "straight_to_crossing"
                elif abs_nav_dir < 0.6:
                    turn_type = "gentle_turn_to_crossing"
                else:
                    turn_type = "sharp_turn_to_crossing"
                
                # 计算转向角
                steering_angle = self.steering_controller.calculate_steering(
                    nav_direction, turn_type, confidence, current_speed
                )
                
                # 添加转向方向信息
                steering_direction = self._get_steering_direction(nav_direction)
                
                if self.debug_mode > 0:
                    print(f"十字路口导航 - 图像中心: {image_center_x}, 十字路口中心: {cross_center_x}")
                    print(f"水平偏移: {cross_offset:.1f} 像素")
                    print(f"导航方向: {nav_direction:.3f}, {steering_direction}")
                    print(f"十字路口面积: {cross_area} (占画面 {(cross_area/image_area*100):.1f}%)")
                    print(f"导航转向类型: {turn_type}")
                    print(f"转向角度: {steering_angle:.1f}°")
                    print(f"置信度: {confidence:.3f}")
                    print("=========================================================")
                
                return nav_direction, turn_type, steering_angle, confidence
            
        # --- [改进] 十字路口导航逻辑结束 ---

        # 提取基础方向
        base_direction, turn_type, confidence = self.direction_extractor.extract_direction_from_mask(road_mask)
        
        # 如果没有检测到道路，不进行障碍物避让
        final_direction = base_direction
        avoidance_type = "none"
        
        # 只有在检测到道路时才进行障碍物避让
        if turn_type != "no_road" and obstacles and len(obstacles) > 0:
            final_direction, avoidance_type = self._avoid_obstacles(base_direction, obstacles, road_mask.shape)
            turn_type = self._get_avoidance_turn_type(final_direction, base_direction, avoidance_type)
            
            # 避让时增加置信度，确保避让动作被执行
            if avoidance_type != "none":
                confidence = max(confidence, 0.5)  # 确保避让时有足够的置信度
        elif turn_type == "no_road" and obstacles and len(obstacles) > 0:
            if self.debug_mode > 0:
                print("No road detected - skipping obstacle avoidance")
        
        # 计算转向角
        steering_angle = self.steering_controller.calculate_steering(
            final_direction, turn_type, confidence, current_speed
        )
        
        # 添加详细的转向方向信息
        steering_direction = self._get_steering_direction(final_direction)
        
        if self.debug_mode > 0:
            print(f"=== Enhanced Steering Control with Obstacle Avoidance ===")
            print(f"Base Road Direction: {base_direction:.3f}")
            if turn_type != "no_road" and obstacles and len(obstacles) > 0:
                print(f"Adjusted Direction (obstacle avoidance): {final_direction:.3f}")
                print(f"Direction adjustment: {final_direction - base_direction:.3f}")
                print(f"Avoidance type: {avoidance_type}")
                print(f"Avoidance strength: {abs(final_direction - base_direction):.3f}")
            elif turn_type == "no_road" and obstacles and len(obstacles) > 0:
                print(f"Obstacles detected but no road - skipping avoidance")
            print(f"Turn Type: {turn_type}")
            print(f"Steering Angle: {steering_angle:.1f}°")
            print(f"Steering Direction: {steering_direction}")
            print(f"Confidence: {confidence:.3f}")
            if obstacles and len(obstacles) > 0:
                print(f"Obstacles detected: {len(obstacles)}")
                for i, obs in enumerate(obstacles):
                    if len(obs) >= 4:
                        print(f"  Obstacle {i+1}: center({obs[0]}, {obs[1]}) size: {obs[2]}x{obs[3]}")
            print("=========================================================")
        
        return final_direction, turn_type, steering_angle, confidence

    def _avoid_obstacles(self, base_direction, obstacles, mask_shape):
        """障碍物避让逻辑 - 增大避让幅度"""
        if not obstacles or len(obstacles) == 0:
            return base_direction, "none"
        
        height, width = mask_shape[0], mask_shape[1]
        image_center_x = width // 2
        image_center_y = height // 2
        
        # 分析障碍物位置和威胁程度
        obstacle_threats = []
        
        for obstacle in obstacles:
            if len(obstacle) >= 4:  # 确保有x,y,w,h
                x, y, w, h = obstacle[0], obstacle[1], obstacle[2], obstacle[3]
                
                obstacle_center_x = x
                obstacle_center_y = y
                
                # 计算威胁程度 - 降低威胁阈值，让更多障碍物触发避让
                threat_level = self._calculate_threat_level(
                    obstacle_center_x, obstacle_center_y, w, h, 
                    image_center_x, image_center_y, height, base_direction
                )
                
                # 降低威胁阈值，让更多障碍物触发避让
                if threat_level > 0.2:  # 从0.3降低到0.2
                    obstacle_threats.append({
                        'center_x': obstacle_center_x,
                        'center_y': obstacle_center_y,
                        'width': w,
                        'height': h,
                        'threat': threat_level,
                        'distance_from_center': abs(obstacle_center_x - image_center_x),
                        'vertical_distance': abs(obstacle_center_y - image_center_y),
                        'raw_data': obstacle
                    })
        
        if not obstacle_threats:
            return base_direction, "none"
        
        # 根据所有障碍物的综合影响调整方向 - 增大调整幅度
        adjusted_direction, avoidance_type = self._calculate_composite_avoidance(
            base_direction, obstacle_threats, image_center_x, width
        )
        
        return adjusted_direction, avoidance_type

    def _calculate_threat_level(self, obs_x, obs_y, obs_w, obs_h, center_x, center_y, image_height, base_direction):
        """计算障碍物威胁程度 - 调整权重以增强避让"""
        threat = 0.0
        
        # 1. 水平位置威胁（距离中心越近威胁越大）- 增加权重
        horizontal_distance = abs(obs_x - center_x)
        horizontal_threat = max(0, 1.0 - horizontal_distance / (center_x * 0.6))  # 减小分母，增加威胁
        
        # 2. 垂直位置威胁（越靠近下方威胁越大）- 增加权重
        vertical_distance_from_bottom = image_height - obs_y
        vertical_threat = max(0, 1.0 - vertical_distance_from_bottom / (image_height * 0.5))  # 减小分母，增加威胁
        
        # 3. 大小威胁（障碍物越大威胁越大）- 增加权重
        size_threat = min(1.0, (obs_w * obs_h) / (center_x * image_height * 0.05))  # 减小分母，增加威胁
        
        # 4. 方向一致性威胁（障碍物在预期行进方向上威胁更大）- 增加权重
        direction_threat = 0.0
        if base_direction > 0.1:  # 右转
            if obs_x > center_x:  # 右侧障碍物
                direction_threat = 0.8  # 从0.6增加到0.8
            elif obs_x > center_x * 0.7:
                direction_threat = 0.5  # 从0.3增加到0.5
        elif base_direction < -0.1:  # 左转
            if obs_x < center_x:  # 左侧障碍物
                direction_threat = 0.8  # 从0.6增加到0.8
            elif obs_x < center_x * 1.3:
                direction_threat = 0.5  # 从0.3增加到0.5
        else:  # 直行
            if abs(obs_x - center_x) < center_x * 0.3:
                direction_threat = 1.0  # 从0.8增加到1.0
            elif abs(obs_x - center_x) < center_x * 0.5:
                direction_threat = 0.6  # 从0.4增加到0.6
        
        # 综合威胁计算（加权平均）- 调整权重增强避让
        threat = (horizontal_threat * 0.4 +     # 从0.35增加到0.4
                 vertical_threat * 0.4 +        # 从0.35增加到0.4
                 size_threat * 0.15 +           # 从0.2降低到0.15
                 direction_threat * 0.05)       # 从0.1降低到0.05
        
        return min(threat, 1.0)

    def _calculate_composite_avoidance(self, base_direction, obstacle_threats, center_x, image_width):
        """计算综合避让方向 - 大幅增大避让幅度"""
        # 按威胁程度排序
        sorted_obstacles = sorted(obstacle_threats, key=lambda x: x['threat'], reverse=True)
        
        # 初始调整方向
        adjusted_direction = base_direction
        total_adjustment = 0.0
        adjustment_count = 0
        max_threat_level = 0.0
        
        # 对每个障碍物计算避让调整 - 增大权重
        for obstacle in sorted_obstacles[:4]:  # 从3个增加到4个，考虑更多障碍物
            obstacle_x = obstacle['center_x']
            threat_level = obstacle['threat']
            max_threat_level = max(max_threat_level, threat_level)
            
            # 计算单个障碍物的避让调整
            obstacle_adjustment = self._calculate_single_obstacle_adjustment(
                base_direction, obstacle_x, threat_level, center_x
            )
            
            # 增大权重
            weight = threat_level * 1.2  # 从0.5增加到1.2
            total_adjustment += obstacle_adjustment * weight
            adjustment_count += weight
        
        # 计算平均调整量
        if adjustment_count > 0:
            average_adjustment = total_adjustment / adjustment_count
            adjusted_direction = base_direction + average_adjustment
        
        # 确定避让类型
        avoidance_type = self._get_avoidance_type(max_threat_level, abs(adjusted_direction - base_direction))
        
        # 大幅增大调整幅度限制
        max_adjustment = 0.8  # 从0.2增加到0.8，大幅增加避让幅度
        if abs(adjusted_direction - base_direction) > max_adjustment:
            if adjusted_direction > base_direction:
                adjusted_direction = base_direction + max_adjustment
            else:
                adjusted_direction = base_direction - max_adjustment
            avoidance_type = "strong_avoidance"
        
        # 确保方向值在合理范围内
        adjusted_direction = max(-1.0, min(1.0, adjusted_direction))
        
        return adjusted_direction, avoidance_type

    def _calculate_single_obstacle_adjustment(self, base_direction, obstacle_x, threat_level, center_x):
        """计算单个障碍物的避让调整量 - 大幅增大调整幅度"""
        # 障碍物相对于中心的位置（-1到1）
        obstacle_relative_pos = (obstacle_x - center_x) / center_x
        
        # 基础避让逻辑 - 大幅增大调整幅度
        if threat_level > 0.7:  # 高威胁
            # 强力避让 - 大幅增大幅度
            if obstacle_relative_pos > 0:  # 障碍物在右侧，向左避让
                adjustment = -0.5  # 从-0.15增加到-0.5
            else:  # 障碍物在左侧，向右避让
                adjustment = 0.5   # 从0.15增加到0.5
        
        elif threat_level > 0.4:  # 中等威胁
            # 适度避让 - 增大幅度
            if obstacle_relative_pos > 0:
                adjustment = -0.3  # 从-0.08增加到-0.3
            else:
                adjustment = 0.3   # 从0.08增加到0.3
        
        else:  # 低威胁
            # 轻微避让 - 增大幅度
            if obstacle_relative_pos > 0:
                adjustment = -0.15  # 从-0.04增加到-0.15
            else:
                adjustment = 0.15   # 从0.04增加到0.15
        
        # 增大方向一致性调整的权重
        if base_direction > 0.1 and obstacle_relative_pos > 0:  # 右转时遇到右侧障碍物
            adjustment *= 1.5  # 从1.1增加到1.5
        elif base_direction < -0.1 and obstacle_relative_pos < 0:  # 左转时遇到左侧障碍物
            adjustment *= 1.5  # 从1.1增加到1.5
        
        return adjustment

    def _get_avoidance_type(self, max_threat_level, direction_change):
        """确定避让类型 - 调整阈值以适应更大的避让幅度"""
        if max_threat_level > 0.7 or direction_change > 0.4:  # 调整阈值
            return "strong_avoidance"
        elif max_threat_level > 0.4 or direction_change > 0.2:
            return "moderate_avoidance"
        elif max_threat_level > 0.2 or direction_change > 0.1:
            return "light_avoidance"
        else:
            return "minimal_avoidance"

    def _get_avoidance_turn_type(self, final_direction, base_direction, avoidance_type):
        """根据避让后的方向确定转向类型 - 调整阈值"""
        direction_change = abs(final_direction - base_direction)
        
        if avoidance_type == "strong_avoidance" or direction_change > 0.5:  # 调整阈值
            return "obstacle_avoidance_sharp"
        elif avoidance_type == "moderate_avoidance" or direction_change > 0.25:
            return "obstacle_avoidance_gentle"
        elif avoidance_type == "light_avoidance" or direction_change > 0.1:
            return "obstacle_avoidance_minor"
        else:
            # 使用基础方向判断转向类型
            abs_direction = abs(final_direction)
            if abs_direction < 0.2:
                return "straight"
            elif abs_direction < 0.5:
                return "gentle_turn"
            else:
                return "sharp_turn"

    def _extreme_fast_extract_binary_mask(self, target_id):
        """极速提取二进制掩码 - 处理约2%总像素，使用中间40%区域（排除最上方35%）"""
        if self.masks is None:
            return None
            
        height, width = self.masks.shape[1], self.masks.shape[2]
        binary_mask = np.zeros((height, width), dtype=np.uint8)
        target_color = self.colors[target_id]
        
        if self.debug_mode > 0:
            print(f"=== Extreme Fast Mask Extraction (2% Sampling) ===")
            print(f"Target color RGB: {target_color[1:]}")
            print(f"Sampling stride: {self.mask_row_stride}x{self.mask_col_stride}")
            print(f"Region: Middle 40% (excluding top 35%)")
        
        road_pixels = 0
        total_sampled = 0
        tolerance = 40
        
        # 计算中间40%区域（排除最上方35%）
        exclude_height = int(height * 0.35)
        middle_height = int(height * 0.45)
        start_y = exclude_height
        end_y = start_y + middle_height
        end_y = min(end_y, height)  # 确保不超过图像边界
        
        # 使用7x7采样步长，在中间40%区域中处理约2%的像素
        for y in range(start_y, end_y, self.mask_row_stride):
            for x in range(0, width, self.mask_col_stride):
                total_sampled += 1
                
                # 修正：masks通道顺序为 [A, R, G, B]
                alpha = self.masks[0, y, x, 0]  # 通道0: Alpha透明度
                red   = self.masks[0, y, x, 1]  # 通道1: 红色
                green = self.masks[0, y, x, 2]  # 通道2: 绿色
                blue  = self.masks[0, y, x, 3]  # 通道3: 蓝色
                
                pixel_rgb = [red, green, blue]
                
                # 检查Alpha通道和颜色匹配
                if alpha > self.alpha_threshold and self._color_match(pixel_rgb, target_color[1:], tolerance):
                    # 标记采样点及其周围区域，提高连续性
                    for dy in range(-1, 2):
                        for dx in range(-1, 2):
                            ny, nx = y + dy, x + dx
                            if 0 <= ny < height and 0 <= nx < width:
                                binary_mask[ny, nx] = 255
                    road_pixels += 1
        
        if self.debug_mode > 0:
            total_pixels = height * width
            sampled_percentage = (total_sampled / total_pixels) * 100
            
            # 计算实际用于方向分析的像素比例（中间40%区域 × 2%采样）
            analysis_region_pixels = middle_height * width
            analysis_sampled_pixels = (middle_height // self.mask_row_stride) * (width // self.mask_col_stride)
            analysis_percentage = (analysis_sampled_pixels / total_pixels) * 100
            
            # 考虑邻域扩展后的实际处理比例
            actual_processed_percentage = min(analysis_percentage * 2, 2.0)  # 保守估计
            
            print(f"Total pixels: {total_pixels}")
            print(f"Middle 40% region pixels (excluding top 35%): {analysis_region_pixels}")
            print(f"Directly sampled in middle region: {total_sampled} ({sampled_percentage:.1f}%)")
            print(f"Used for direction analysis: ~{analysis_percentage:.1f}% of total pixels")
            print(f"Actual processing: ~{actual_processed_percentage:.1f}% of total pixels")
            print(f"Found {road_pixels} road regions")
            print(f"Speed improvement: ~{100 - actual_processed_percentage:.1f}% faster")
            print(f"Performance: Extreme real-time processing")
            print(f"Trade-off: Better accuracy with 2% sampling, focusing on near-field road")
        
        return binary_mask

    def _color_match(self, color1, color2, tolerance=40):
        """颜色匹配，考虑容忍度"""
        return (abs(int(color1[0]) - int(color2[0])) <= tolerance and
                abs(int(color1[1]) - int(color2[1])) <= tolerance and
                abs(int(color1[2]) - int(color2[2])) <= tolerance)

    def _get_steering_direction(self, direction):
        """获取转向方向描述"""
        if direction < -0.1:
            return "LEFT_TURN"
        elif direction > 0.1:
            return "RIGHT_TURN"
        else:
            return "STRAIGHT"

    def debug_road_detection(self, target_id=0):
        """调试道路检测"""
        if self.task_type != "segment" or self.masks is None:
            print("Error: Not in segment mode or masks not initialized")
            return 0
        
        height, width = self.masks.shape[1], self.masks.shape[2]
        
        # 计算中间40%区域（排除最上方35%）
        exclude_height = int(height * 0.35)
        middle_height = int(height * 0.45)
        analysis_region_pixels = middle_height * width
        analysis_percentage = (analysis_region_pixels / (height * width)) * 100
        
        # 计算采样比例
        sampling_rate = (1/self.mask_row_stride) * (1/self.mask_col_stride)  # ~0.143 × 0.143 = 0.0204
        total_processing_percentage = 0.45 * sampling_rate * 100  # 约0.82%
        
        print("=== Extreme Fast Road Detection (2% Sampling) ===")
        print(f"Target ID: {target_id}")
        print(f"Target color: {self.colors[target_id][1:]}")
        print(f"Mask shape: {self.masks.shape}")
        print(f"Analysis region: Middle {analysis_percentage:.1f}% of image (excluding top 35%, height: {middle_height} pixels)")
        print(f"Region range: Y={exclude_height} to Y={exclude_height + middle_height}")
        print(f"Sampling method: {self.mask_row_stride}x{self.mask_col_stride} stride")
        print(f"Sampling rate: {sampling_rate*100:.1f}% of middle region")
        print(f"Total pixel processing: ~{total_processing_percentage:.1f}% of image")
        print(f"Expected speed improvement: ~98% faster")
        print(f"Performance: High-speed real-time capability")
        print(f"Advantage: Better accuracy with 2% sampling, focusing on critical near-field road area")
        print(f"Use case: Balanced scenarios with improved accuracy and good speed")
        
        return 1

    def draw_result(self,res,img):
        with ScopedTiming("draw result",self.debug_mode > 0):
            if self.mode=="video":
                if self.task_type=="classify":
                    ids,score=res[0],res[1]
                    if ids!=-1:
                        mes="id:" + self.labels[ids]+"  score:"+str(round(score,2))
                        img.draw_string_advanced(400,20,16,mes,color=(0,255,0))
                elif self.task_type=="detect":
                    if res:
                        for det in res:
                            x1, y1, x2, y2 = map(lambda x: int(round(x, 0)), det[:4])
                            x= x1*self.display_size[0] // self.rgb888p_size[0]
                            y= y1*self.display_size[1] // self.rgb888p_size[1]
                            w = (x2 - x1) * self.display_size[0] // self.rgb888p_size[0]
                            h = (y2 - y1) * self.display_size[1] // self.rgb888p_size[1]
                            img.draw_rectangle(x,y,w,h, color=self.colors[int(det[5])],thickness=4)
                            img.draw_string_advanced( x , y-50,32," " + self.labels[int(det[5])] + " " + str(round(det[4],2)) , color=self.colors[int(det[5])])
                elif self.task_type=="segment":
                    if res[0]:
                        # img.clear()
                        # mask_img=image.Image(self.display_size[0], self.display_size[1], image.ARGB8888,alloc=image.ALLOC_REF,data=self.masks)
                        # img.copy_from(mask_img)
                        mask_rgb=self.masks[0,:,:,1:4]  # 注意：这里取的是[R, G, B]通道
                        mask_img=image.Image(self.display_size[0], self.display_size[1], image.RGB888,alloc=image.ALLOC_REF,data=mask_rgb.copy())
                        img.copy_from(mask_img)
                        dets,ids,scores = res[0],res[1],res[2]
                        for i, det in enumerate(dets):
                            x1, y1, w, h = map(lambda x: int(round(x, 0)), det)
                            img.draw_string_advanced(x1,y1-30,16, " " + self.labels[int(ids[i])] + " " + str(round(scores[i],2)) , color=self.colors[int(ids[i])])
                    else:
                        # img.clear()
                        pass
                else:
                    pass
            elif self.mode=="image":
                if self.task_type=="classify":
                    ids,score=res[0],res[1]
                    if ids!=-1:
                        mes=self.labels[ids]+" "+str(round(score,3))
                        img.draw_string_advanced(5,5,32,mes,color=(0,255,0))
                    img.compress_for_ide()
                elif self.task_type=="detect":
                    if res:
                        for det in res:
                            x1, y1, x2, y2 = map(lambda x: int(round(x, 0)), det[:4])
                            x,y=int(x1),int(y1)
                            w = int(x2 - x1)
                            h = int(y2 - y1)
                            img.draw_rectangle(x,y,w,h,color=self.colors[int(det[5])],thickness=4)
                            img.draw_string_advanced( x , y-25,20," " + self.labels[int(det[5])] + " " + str(round(det[4],2)) , color=self.colors[int(det[5])])
                    img.compress_for_ide()
                elif self.task_type=="segment":
                    if res[0]:
                        mask_rgb=self.masks[0,:,:,1:4]  # 注意：这里取的是[R, G, B]通道
                        mask_img=image.Image(self.rgb888p_size[0], self.rgb888p_size[1], image.RGB888,alloc=image.ALLOC_REF,data=mask_rgb.copy())
                        dets,ids,scores = res[0],res[1],res[2]
                        # print(res)
                        # print(self.masks.shape)
                   
                        for i, det in enumerate(dets):
                            x, y, w, h = map(lambda x: int(round(x, 0)), det)
                            mask_img.draw_string_advanced(x,y-50,16, " " + self.labels[int(ids[i])] + " " + str(round(scores[i],2)) , color=self.colors[int(ids[i])])
                        mask_img.compress_for_ide()
                else:
                    pass

    def nms(self,boxes,scores,thresh):
        """Pure Python NMS baseline."""
        x1,y1,x2,y2 = boxes[:, 0],boxes[:, 1],boxes[:, 2],boxes[:, 3]
        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = np.argsort(scores,axis = 0)[::-1]
        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            new_x1,new_y1,new_x2,new_y2,new_areas = [],[],[],[],[]
            for order_i in order:
                new_x1.append(x1[order_i])
                new_x2.append(x2[order_i])
                new_y1.append(y1[order_i])
                new_y2.append(y2[order_i])
                new_areas.append(areas[order_i])
            new_x1 = np.array(new_x1)
            new_x2 = np.array(new_x2)
            new_y1 = np.array(new_y1)
            new_y2 = np.array(new_y2)
            xx1 = np.maximum(x1[i], new_x1)
            yy1 = np.maximum(y1[i], new_y1)
            xx2 = np.minimum(x2[i], new_x2)
            yy2 = np.minimum(y2[i], new_y2)
            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h
            new_areas = np.array(new_areas)
            ovr = inter / (areas[i] + new_areas - inter)
            new_order = []
            for ovr_i,ind in enumerate(ovr):
                if ind < thresh:
                    new_order.append(order[ovr_i])
            order = np.array(new_order,dtype=np.uint8)
        return keep