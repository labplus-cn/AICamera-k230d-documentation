import time
import gc
import sys
import _thread
import machine
import json
from machine import UART
# from libs.Board import LED
from libs.Public import *
from ui.utils import *

class K230UartProcess(object):  
    def __init__(self):
        global uart, k230_flag, DEBUG
        DEBUG = False  # 增加全局debug控制变量
        if DEBUG:
            print('K230 UartProcess init')
        uart = UART(UART.UART1, baudrate=1152000, bits=UART.EIGHTBITS, parity=UART.PARITY_NONE, stop=UART.STOPBITS_ONE)
        # k230_flag = K230Flag()
        time.sleep(0.1)
        self.rx_buf = bytearray()
        self.uart = uart
    
        '''sensor config'''
        # self.framesize=[]
        # self.pixformat=sensor.RGB565
        self.w=544
        self.h=368
        
        k230_flag['middle_cb'] = self.middle_cb
        k230_flag['left_cb'] = self.left_cb
        k230_flag['right_cb'] = self.right_cb
        
        # 开始串口监听程序
        time.sleep(0.05)
        _thread.start_new_thread(self.uart_listen,())
    
    def middle_cb(self):
        global k230_flag, DEBUG
        if DEBUG:
            print('middle_cb')
        k230_flag["key_middle_status"] = True

    def left_cb(self):
        global k230_flag, DEBUG
        if DEBUG:
            print('left_cb')
        k230_flag["key_left_status"] = True

    def right_cb(self):
        global k230_flag, DEBUG
        if DEBUG:
            print('right_cb')
        k230_flag["key_right_status"] = True
        

    def CheckCode(self, tmp):
        ''' 校验和 取低8位'''
        sum = 0
        for i in range(len(tmp)):
            sum += tmp[i]
        return sum & 0xFF    

    def AI_Uart_CMD(self, cmd=0, cmd_type=0, cmd_data=[0, 0, 0, 0, 0, 0]):
        global k230_flag, DEBUG
        data_type = 0x01
        check_sum = 0
        CMD_TEMP = [0xBB, 0xAA, data_type, cmd, cmd_type]
        CMD_TEMP.extend(cmd_data)
        for i in range(6-len(cmd_data)):
            CMD_TEMP.append(0)
        for i in range(len(CMD_TEMP)):
            check_sum = check_sum+CMD_TEMP[i]
        
        CMD_TEMP.append(check_sum & 0xFF)
        if DEBUG:
            self.print_x16(CMD_TEMP)
            print(CMD_TEMP)
        self.uart.write(bytes(CMD_TEMP))
        del CMD_TEMP
        gc.collect()

        
    def AI_Uart_CMD_String(self, cmd=0x00, cmd_type=0x00, cmd_data=[0x00], str_buf=''):
        global k230_flag, DEBUG
        CMD = [0xBB, 0xAA, 0x02, cmd, cmd_type]
        CMD.extend(cmd_data)
        for i in range(15-len(cmd_data)):
            CMD.append(0)

        str_temp = bytes(str_buf, 'utf-8')
        str_len = len(str_temp)
        if str_len > 2048:
            if DEBUG:
                print("字符串长度超出2048，已截断！")
            str_temp = str_temp[:2048]
            str_len = 2048
        if DEBUG:
            print("str_len:", str_len)
        # 用两个字节存储长度（高字节在前，低字节在后）
        CMD = bytes(CMD) + bytes([(str_len >> 8) & 0xFF, str_len & 0xFF]) + str_temp + bytes([0xAB])
        self.uart.write(CMD)   
        del str_temp
        del CMD
        gc.collect()
        if DEBUG:
            self.print_x16(CMD)
  
    def print_x16(self,date):
        global DEBUG
        if DEBUG:
            for i in range(len(date)):
                print('{:2x}'.format(date[i]),end=' ')
            print('')

    def wait_mpython_init(self): 
        global k230_flag, DEBUG
        while True:
            gc.collect()
            time.sleep_ms(20)
            if(self.uart.any()):
                head=self.uart.read(2)
                if(head and head[0]==0xAA and head[1]==0xBB):
                    cmd_type = self.uart.read(1)
                    if(cmd_type[0]==0x01):
                        res=self.uart.read(9)
                        if(res and res[0]==0x01 and res[1]==0xFF):
                            k230_flag["sensor_mode"] = True
                            self.AI_Uart_CMD(0x01,0x01,0xFF)
                            time.sleep_ms(100)
                            if DEBUG:
                                print('==init end==')
                            break
                else:
                    if DEBUG:
                        print(head)
                        print('wait_mpython_init error')
                    gc.collect()

    def uart_handle(self):
        MAX_BUF_SIZE = 1024  # 缓冲区最大字节数
        global k230_flag, DEBUG
        if not hasattr(self, "rx_buf"):
            self.rx_buf = bytearray()

        # 读取 UART 数据
        if self.uart.any():
            data = self.uart.read()
            if data:
                if DEBUG:
                    print("[UART RX] " + data.hex(' ').upper())
                self.rx_buf.extend(data)

                # 缓冲区保护
                if len(self.rx_buf) > MAX_BUF_SIZE:
                    if DEBUG:
                        print("[UART] 缓冲区超限({} > {})，清空".format(len(self.rx_buf), MAX_BUF_SIZE))
                    self.rx_buf = bytearray()

        while True:
            # 至少要有包头(2字节) + 命令类型(1字节)
            if len(self.rx_buf) < 3:
                break

            # 检查包头
            if not (self.rx_buf[0] == 0xAA and self.rx_buf[1] == 0xBB):
                if DEBUG:
                    print("[UART] 丢弃无效字节: 0x{:02X}".format(self.rx_buf[0]))
                self.rx_buf = self.rx_buf[1:]
                continue

            cmd_type = self.rx_buf[2]

            # 命令 0x01: 固定长度 2(包头) + 1(命令) + 2 +8(数据) + 1(校验) = 14字节
            if cmd_type == 0x01:
                total_len = 14
                if len(self.rx_buf) < total_len:
                    if DEBUG:
                        print("[UART] 等待 0x01 包数据到齐")
                    break
                pkt = self.rx_buf[:total_len]
                checksum = self.CheckCode(pkt[:13])  # 校验包头+命令+数据(共13字节)
                if DEBUG:
                    print("[UART] 解析到 0x01 包: " + pkt.hex(' ').upper())
                if checksum == pkt[13]:
                    if DEBUG:
                        print("[UART] 校验成功")
                    self.process_cmd(pkt)
                else:
                    if DEBUG:
                        print("[UART] 校验失败 (计算={:02X}, 接收={:02X})".format(checksum, pkt[13]))
                self.rx_buf = self.rx_buf[total_len:]

            # 命令 0x02:  2(包头) + 1(命令) + 6(固定头) + N(字符串) + 1(校验)
            elif cmd_type == 0x02:
                if len(self.rx_buf) < 9:  # 至少要有包头+命令+固定头
                    if DEBUG:
                        print("[UART] 等待 0x02 头部数据到齐")
                    break
                str_len = self.rx_buf[8]  # 第9字节，索引8
                total_len = 2 + 1 + 6 + str_len + 1
                if len(self.rx_buf) < total_len:
                    if DEBUG:
                        print("[UART] 等待 0x02 字符串数据到齐 (len={})".format(str_len))
                    break
                pkt = self.rx_buf[:total_len]
                if pkt[-1] != 0xAB:
                    if DEBUG:
                        print("[UART] 0x02 包尾校验失败 (期望=AB, 接收={:02X})，丢弃第一个字节".format(pkt[-1]))
                    self.rx_buf = self.rx_buf[1:]
                    continue
                if DEBUG:
                    print("[UART] 解析到 0x02 包")
                self.process_cmd(pkt)
                self.rx_buf = self.rx_buf[total_len:]

            else:
                if DEBUG:
                    print("[UART] 未知命令 0x{:02X}，丢弃第一个字节".format(cmd_type))
                self.rx_buf = self.rx_buf[1:]



    def process_cmd(self,cmd):
        global k230_flag
    
        CMD = cmd
        if(len(CMD)>0):
            if(CMD[2]==0x01):
                if(CMD[3]==0x01 and CMD[4]==0xFF):
                    self.AI_Uart_CMD(0x01,0xFF)
                    k230_flag["sensor_mode"] = True
                    # time.sleep_ms(1)                    
                    print("=== init end ===")
                elif(CMD[3]==DEFAULT_MODE and CMD[4]==0x01):
                    print("switcherMode")
                    k230_flag["run_mode"] = SENSOR_MODE
                    change_route(url='sensor', arge=k230_flag)   
                elif(CMD[3]==FACE_DETECTION_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_DETECTION_MODE
                    change_route(url='sensor', arge=k230_flag)    
                elif(CMD[3]==OBJECT_RECOGNIZATION_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = OBJECT_RECOGNIZATION_MODE
                    change_route(url='sensor', arge=k230_flag)   
                elif(CMD[3]==FALL_DETECTION and CMD[4]==0x01):
                    k230_flag["run_mode"] = FALL_DETECTION  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==HAND_KEYPOINT_CLASS and CMD[4]==0x01):
                    k230_flag["run_mode"] = HAND_KEYPOINT_CLASS  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==LICENSE_PLATE_RECOGNITION and CMD[4]==0x01):
                    k230_flag["run_mode"] = LICENSE_PLATE_RECOGNITION  
                    change_route(url='sensor', arge=k230_flag)     
                elif(CMD[3]==PERSON_KEYPOINT_DETECT and CMD[4]==0x01):
                    k230_flag["run_mode"] = PERSON_KEYPOINT_DETECT  
                    change_route(url='sensor', arge=k230_flag)   
                elif(CMD[3]==PERSON_KEYPOINT_DETECT_PLUS and CMD[4]==0x01):
                    k230_flag["run_mode"] = PERSON_KEYPOINT_DETECT_PLUS  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==FACE_LANDMARK_LIVING_BODY and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_LANDMARK_LIVING_BODY  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==FACE_LANDMARK_EXPRESSION and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_LANDMARK_EXPRESSION  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==SELF_LEARNING_CLASSIFIER_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = SELF_LEARNING_CLASSIFIER_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==QRCODE_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = QRCODE_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==BARCODE_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = BARCODE_MODE  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==FALL_DETECTION and CMD[4]==0x01):
                    k230_flag["run_mode"] = FALL_DETECTION  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==FACE_RECOGNITION_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_RECOGNITION_MODE  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==DYNAMIC_GESTURE and CMD[4]==0x01):
                    k230_flag["run_mode"] = DYNAMIC_GESTURE  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==HAND_DETECTION and CMD[4]==0x01):
                    k230_flag["run_mode"] = HAND_DETECTION  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==PERSON_DETECTION and CMD[4]==0x01):
                    k230_flag["run_mode"] = PERSON_DETECTION  
                    change_route(url='sensor', arge=k230_flag) 
                elif(CMD[3]==COLOR_OBJECT_COUNT_MODE and CMD[4]==0x01):
                    model_dict = {}
                    model_dict["cur_mode"] = int(CMD[5])
                    k230_flag["run_mode"] = COLOR_OBJECT_COUNT_MODE  
                    k230_flag["model_dict"] = model_dict  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==FACE_REG_PLUS_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = FACE_REG_PLUS_MODE   
                    change_route(url='sensor', arge=k230_flag)        
                elif(CMD[3]==APS_MODE and CMD[4]==0x01):
                    k230_flag["run_mode"] = APS_MODE   
                    change_route(url='sensor', arge=k230_flag)      
            elif(CMD[2]==0x02):
                if(CMD[3]==CLASSIFY_MODEL_MODE and CMD[4]==0x01):
                    str_temp = bytes(CMD[9:-1])
                    model_dict = eval(str(str_temp.decode('UTF-8','ignore')))
                    k230_flag["model_dict"] = model_dict  
                    k230_flag["run_mode"] = CLASSIFY_MODEL_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==DETECT_MODEL_MODE and CMD[4]==0x01):
                    str_temp = bytes(CMD[9:-1])
                    model_dict = eval(str(str_temp.decode('UTF-8','ignore')))
                    k230_flag["model_dict"] = model_dict  
                    k230_flag["run_mode"] = DETECT_MODEL_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==LAB_COLOR_OBJECT_COUNT_MODE and CMD[4]==0x01):
                    str_temp = bytes(CMD[9:-1])
                    color = eval(str(str_temp.decode('UTF-8','ignore')))
                    model_dict = {}
                    model_dict["lab_color"] = color  
                    k230_flag["model_dict"] = model_dict  
                    k230_flag["run_mode"] = LAB_COLOR_OBJECT_COUNT_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==LINEAR_REGRESSION_MODE and CMD[4]==0x01):
                    str_temp = bytes(CMD[9:-1])
                    threshold = eval(str(str_temp.decode('UTF-8','ignore')))
                    model_dict = {}
                    model_dict["threshold"] = threshold  
                    k230_flag["model_dict"] = model_dict  
                    k230_flag["run_mode"] = LINEAR_REGRESSION_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                elif(CMD[3]==LINEAR_REGRESSION_V3_MODE and CMD[4]==0x01):
                    b = bytes(CMD[9:-1])
                    model_dict = json.loads(b.decode('UTF-8','ignore'))
                    # print(model_dict)
                    # print("LINEAR_REGRESSION_V3_MODE==========")
                    k230_flag["model_dict"] = model_dict  
                    k230_flag["run_mode"] = LINEAR_REGRESSION_V3_MODE  
                    change_route(url='sensor', arge=k230_flag)  
                                 
    def uart_listen(self):
        try:
            global k230_flag
    
            while True:
                gc.collect()
                time.sleep_ms(5)
                # print("uart_listen:"+str(time.ticks_ms()))
                self.uart_handle()
        except Exception as e:
            print(str(e))
            print("==uart_listen==")
    
         
    # def reset(self):
    #     print('==reset==')
    #     self.AI_Uart_CMD(0x01,0x01,0xFF)
    #     time.sleep_ms(10)
    #     machine.reset()
    
    # def switcherMode(self, mode):
    #     if(mode==self.flag.mode or self.flag.sw_lock):
    #         print('switcherMode return')
    #         return
